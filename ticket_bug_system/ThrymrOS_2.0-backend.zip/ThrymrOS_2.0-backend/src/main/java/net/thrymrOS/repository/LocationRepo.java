package net.thrymrOS.repository;

import net.thrymrOS.entity.md.md_corehr.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  02/03/23
 * @Time >>  4:37 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface LocationRepo extends JpaRepository<Location, String> {
    boolean existsByNameIgnoreCase(String name);

    List<Location> findAllByOrderByCreatedOnDesc();

    List<Location> findAllByOrderByNameAsc();

    List<Location> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<Location> findAllByOrderByIsActiveDescNameAsc();

    List<Location> findAllByIsActiveEquals(Boolean aTrue);

    Optional<Location> findAllByNameEqualsIgnoreCase(String locationName);

    List<Location> findAllByIsActiveOrderByNameAsc(Boolean aTrue);

    Optional<Location> findByNameIgnoreCase(String s);
}
