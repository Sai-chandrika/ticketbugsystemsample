package net.thrymrOS.repository;

import net.thrymrOS.entity.asset.AssetType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  31/03/23
 * @Time >>  10:47 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface AssetTypeRepo extends JpaRepository<AssetType,String> {
    Optional<AssetType> findByNameIgnoreCase(String name);
    List<AssetType> findAllByOrderByCreatedOnDesc();
    List<AssetType> findByAssetCategoryNameIgnoreCase(String name);
    List<AssetType> findAllByOrderByIsActiveDescNameAsc();

    List<AssetType> findAllByIsActiveOrderByNameAsc(boolean b);
}
