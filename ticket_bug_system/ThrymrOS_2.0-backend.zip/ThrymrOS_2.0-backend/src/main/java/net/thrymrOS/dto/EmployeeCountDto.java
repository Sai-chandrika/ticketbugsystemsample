package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  17/04/23
 * @Time >>  5:51 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class EmployeeCountDto {
    private Long totalEmployees;
    private Long activeEmployees;
    private Long inActiveEmployees;
}
