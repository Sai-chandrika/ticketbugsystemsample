package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  20/04/23
 * @Time >>  11:20 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class DSRReportDto {
    private String empName;
    private EmployeeDto employeeDto;
    private List<DSRTaskReportDto>  dsrTasks;
    private Double totalDsrTasks;
    private String totalWorkingHours;
    private Double countOfDsr;
    private Double workingDays;
}
