package net.thrymrOS.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AllocationType;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Giridhar
 * @Date >>  14/03/23
 * @Time >>  5:58 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AllocationRequestDto {
    @NotBlank(message = "Project can't be null/empty")
    private String projectId;
    @NotBlank(message = "Employee can't be null/empty")
    private String employeeId;
    @NotNull(message = "Allocation Type can't be null/empty")
    private AllocationType allocationType;
    @NotNull(message = "Start Date can't be null/empty")
    private LocalDate startDate;
    @NotNull(message = "End Date can't be null/empty")
    private LocalDate endDate;
}
