package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;

/**
 * @Author >> Mamatha
 * @Date >>  16/03/23
 * @Time >>  9:41 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NonNull
@Data
public class DSRTaskRequestDto {
    private String id;
    @NotBlank(message = "Task can't be Null/Empty")
    private String task;
    private double effortHours;
    private double effortMinutes;
    @NotBlank(message = "Dsr id can't be Null/Empty")
    private String dsrId;
    @NotBlank(message = "Project can't be Null/Empty")
    private String projectId;
    @NotBlank(message = "Category can't be Null/Empty")
    private String categoryId;
}
