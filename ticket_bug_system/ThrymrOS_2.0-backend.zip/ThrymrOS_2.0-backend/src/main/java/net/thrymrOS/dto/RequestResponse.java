package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 16-06-2023
 */
@Data
@NoArgsConstructor
public class RequestResponse {
    private String ticketId;
    private String response;
    private String reason;
}