package net.thrymrOS.enums;
/**
 * @Author >> Giridhar
 * @Date >>  06/03/23
 * @Time >>  02:28 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TaskSeverityType {
    S0,
    S1,
    S2,
    S3,
    S4;
}
