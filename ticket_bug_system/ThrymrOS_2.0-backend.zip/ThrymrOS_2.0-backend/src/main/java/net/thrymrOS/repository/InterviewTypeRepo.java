package net.thrymrOS.repository;

import net.thrymrOS.entity.md.recruitment.InterviewType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 27-05-2023
 */
@Repository
public interface InterviewTypeRepo extends JpaRepository<InterviewType,String> {
    boolean existsByNameIgnoreCase(String name);

    List<InterviewType> findAllByOrderByCreatedOnDesc();

   List<InterviewType> findAllByOrderByIsActiveDescNameAsc();

    List<InterviewType> findAllByIsActiveTrueOrderByNameAsc();

    Optional<InterviewType> findByNameIgnoreCase(String s);
}