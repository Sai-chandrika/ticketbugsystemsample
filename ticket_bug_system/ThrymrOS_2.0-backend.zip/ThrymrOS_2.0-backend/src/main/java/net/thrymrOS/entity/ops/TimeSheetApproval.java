package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.entity.pm.Project;
import net.thrymrOS.enums.TimeSheetStatus;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  18/04/23
 * @Time >>  10:55 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class TimeSheetApproval extends BaseEntity {
    @ManyToOne(targetEntity = Employee.class)
    private Employee manager;
    @ManyToOne(targetEntity = Employee.class)
    private Employee employee;
    @ManyToOne(targetEntity = Project.class)
    private Project project;
//    @OneToMany(targetEntity = TimeSheetUnit.class)
//    private List<TimeSheetUnit> timeSheetList=new ArrayList<>();
    private TimeSheetStatus sheetStatus;
    private LocalDate fromDate;
    private LocalDate toDate;
}

