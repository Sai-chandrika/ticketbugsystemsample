package net.thrymrOS.repository;

import net.thrymrOS.entity.employee_engagement.Photo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  29/03/23
 * @Time >>  12:00 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface PhotoRepo extends JpaRepository<Photo, String> {
    List<Photo> findAllByAlbumIdAndIsActive(String albumId, Boolean value);
    List<Photo> findAllByAlbumId(String albumId);
    Photo findFirstByAlbumIdOrderByCreatedOnAsc(String albumId);
}
