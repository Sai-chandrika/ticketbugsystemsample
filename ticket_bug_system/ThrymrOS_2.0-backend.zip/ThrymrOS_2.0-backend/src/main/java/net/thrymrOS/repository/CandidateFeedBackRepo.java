package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.CandidateFeedBack;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  20/05/23
 * @Time >>  10:40 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface CandidateFeedBackRepo extends JpaRepository<CandidateFeedBack,String> {
    List<CandidateFeedBack> findByScheduleInterviewIdOrderByCreatedOnDesc(String id);

    List<CandidateFeedBack> findAllByScheduleInterviewId(String id);
}
