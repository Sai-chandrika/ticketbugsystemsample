package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpEmergencyContactDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  25/02/23
 * @Time >>  3:27 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface EmpEmergencyContactDetailRepo extends JpaRepository<EmpEmergencyContactDetail, String> {
    List<EmpEmergencyContactDetail> findAllByEmployeeId(String empId);
    Optional<EmpEmergencyContactDetail> findByEmployeeId(String empId);
    List<EmpEmergencyContactDetail>findAllByOrderByCreatedOnDesc();
}
