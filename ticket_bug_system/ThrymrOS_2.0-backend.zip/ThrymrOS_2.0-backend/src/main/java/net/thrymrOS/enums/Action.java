package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  01/06/23
 * @Time >>  12:29 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum Action {
    POST,
    PUT,
    GET,
    DELETE
}
