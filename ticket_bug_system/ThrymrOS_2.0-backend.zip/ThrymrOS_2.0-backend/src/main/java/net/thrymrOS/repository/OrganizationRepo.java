package net.thrymrOS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import net.thrymrOS.entity.md.OrganizationUnit;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  09/02/23
 * @Time >>  3:52 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface OrganizationRepo extends JpaRepository<OrganizationUnit, String> {
    //List<OrganizationUnit> findAllByOrderByIdAsc();
    List<OrganizationUnit> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<OrganizationUnit> findByNameEqualsIgnoreCase(String organisationName);

    List<OrganizationUnit> findAllByOrderByIsActiveDescNameAsc();

    List<OrganizationUnit> findAllByIsActiveEquals(Boolean aTrue);

    List<OrganizationUnit> findAllByIsActiveOrderByNameAsc(Boolean aTrue);

    List<OrganizationUnit> findAllByName(String name);

}
