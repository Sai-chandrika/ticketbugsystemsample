package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  29/03/23
 * @Time >>  12:02 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@NoArgsConstructor
@Data
public class PhotoDto {
    private String photoId;
    private String fileId;
    private String albumId;
    private Boolean isActive;
}
