package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.TimeSheetApproval;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  18/04/23
 * @Time >>  11:01 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface TimeSheetApprovalRepo extends JpaRepository<TimeSheetApproval,String> {

    Optional<TimeSheetApproval> findByEmployeeIdAndProjectIdAndFromDateGreaterThanEqualAndToDateLessThanEqual(String empId, String projectId, LocalDate formDate, LocalDate toDate);
}
