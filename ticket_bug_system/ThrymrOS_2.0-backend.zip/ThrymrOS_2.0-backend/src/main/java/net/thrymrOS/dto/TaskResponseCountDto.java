package net.thrymrOS.dto;

import lombok.Data;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 19/05/23
 * @Time >> 4:37 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
public class TaskResponseCountDto {
    private String monthName;
    private Long newCount;
    private Long onHoldCount;
    private Long inProgressCount;
    private Long completeCount;
    private Long totalTask;
}
