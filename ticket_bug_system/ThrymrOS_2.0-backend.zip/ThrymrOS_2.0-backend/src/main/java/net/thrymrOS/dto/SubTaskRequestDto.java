package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 03/05/23
 * @Time >> 3:10 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SubTaskRequestDto {
    private String task;
    private String parentTaskId;
}
