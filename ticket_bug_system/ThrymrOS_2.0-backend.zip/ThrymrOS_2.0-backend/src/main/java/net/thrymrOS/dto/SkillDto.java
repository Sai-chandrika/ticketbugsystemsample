package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Mamatha
 * @Date >>  03/03/23
 * @Time >>  2:20 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SkillDto {
      private String id;
      private String name;
      private String description;
      private boolean isActive;
}
