package net.thrymrOS.enums;

public enum Role {
    USER,//0
    ADMIN,//1
    HR,//2

}
