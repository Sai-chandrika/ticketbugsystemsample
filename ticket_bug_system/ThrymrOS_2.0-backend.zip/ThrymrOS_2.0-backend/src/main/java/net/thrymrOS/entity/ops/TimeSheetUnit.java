package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.entity.pm.Project;
import net.thrymrOS.enums.TimeSheetStatus;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  15/04/23
 * @Time >>  2:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class TimeSheetUnit extends BaseEntity {
    @ManyToOne(targetEntity = Project.class)
    private Project project;
    @Column(columnDefinition = "int check(working_hours between 0 and 24)")
    private int workingHours;
    @Column(columnDefinition = "int check(working_minutes between 0 and 59)")
    private int workingMinutes;
    private LocalDate forDate;
    @ManyToOne(targetEntity = Employee.class, cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST })
    private Employee employee;
    private TimeSheetStatus timeSheetStatus;

}
