package net.thrymrOS.enums;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  05/08/23
 * @Time >>  11:30 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum SessionStatus {
    UPCOMING,
    RESCHEDULE,
    CANCELED,
    COMPLETED
}
