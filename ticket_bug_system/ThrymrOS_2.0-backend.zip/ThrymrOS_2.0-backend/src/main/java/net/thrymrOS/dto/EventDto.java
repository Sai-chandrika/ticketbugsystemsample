package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.EventStatus;
import net.thrymrOS.enums.ModeOfInterview;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 08/08/23
 * @Time ➤➤➤ 2:58 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EventDto {
    private String id;
    private FileUploadDto eventThumbnail;
    private String name;
    private ModeOfInterview eventType;
    private int participant;
    private LocalDate date;
    private LocalTime time;
    private String description;
    private EventStatus eventStatus;
    private float budget;
    private List<String> inclusions= new ArrayList<>();
    private LocationDto location;
    private CurrencyDto budgetInCurrency;
    private EmployeeDto poc;
    private Boolean isActive;
    private AlbumDto albumDto;
    private String createdBy;
}
