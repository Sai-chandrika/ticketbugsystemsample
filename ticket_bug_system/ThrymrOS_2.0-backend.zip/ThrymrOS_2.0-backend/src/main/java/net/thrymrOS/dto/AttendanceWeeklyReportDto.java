package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  14/04/23
 * @Time >>  3:00 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class AttendanceWeeklyReportDto {
    private Long totalHoursInOffice;
    private Long totalBreak;
    private Long actualWorkingHours;
}
