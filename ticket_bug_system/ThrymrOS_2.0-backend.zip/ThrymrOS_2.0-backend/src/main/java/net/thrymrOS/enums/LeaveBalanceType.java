package net.thrymrOS.enums;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 22-07-2023
 */
public enum LeaveBalanceType {
      PRIVILEGE_LEAVE,
      SICK_LEAVE,
      COMPENSATORY_LEAVE,
      MATERNITY_LEAVE,
      PATERNITY_LEAVE,
      LOSS_OF_PAY,
}