package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.EventStatus;
import net.thrymrOS.enums.ModeOfInterview;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 08/08/23
 * @Time ➤➤➤ 3:01 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EventRequestDto {
    private String id;
    @NotBlank(message = "Name should not be null/Empty")
    private String name;
    @NotNull(message = "Event Type Should not be null")
    private ModeOfInterview eventType;
    @NotNull(message = "participants should not be null")
    private Integer participant;
    @NotNull(message = "Date should not be null")
    private LocalDate date;
    @NotNull(message = "Time Should not be null")
    private LocalTime time;
    private String description;
    @NotNull(message = "Event status should not be null")
    private EventStatus eventStatus;
    private float budget;
    private List<String> inclusions;
  //  @NotBlank(message = "Event Thumbnail should not be null")
    private String eventThumbnail;
    private String currencyId;
    private String locationId;
    @NotBlank(message = "Poc Should Not be null/Empty")
    private String pocId;
}
