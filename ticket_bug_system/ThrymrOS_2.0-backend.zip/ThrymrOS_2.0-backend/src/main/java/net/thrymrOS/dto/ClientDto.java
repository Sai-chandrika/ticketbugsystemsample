package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.City;
import net.thrymrOS.entity.md.finance.Currency;
import net.thrymrOS.enums.*;



/**
 * @Author >> Swetha
 * @Date >>  03/03/23
 * @Time >>  2:55 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ClientDto {
    private String id;
    //private String name;
   // private String description;
    private CityDto placeOfSupply;
    private Boolean isActive;
    private String clientCode;
    private ClientType clientType;
    private String companyName;
    private String clientDisplayName;
    private BusinessVerticalDto businessVertical;
    private LocationType locationType;
    private Salutation salutation;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    private GstTreatment gstTreatment;
    private String pan;
    private CurrencyDto currency;
    private Double openingBalance;
    private int paymentTerms;
    private TaxPreference taxPreference;
    private AddressDto billingAddress;
    private AddressDto shippingAddress;
   // private boolean copyBillingAddress;
   private String gstNumber;
    private String businessLegalName;


}
