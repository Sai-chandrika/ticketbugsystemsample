package net.thrymrOS.dto;

import lombok.*;

import javax.validation.constraints.NotNull;

/**
 * @Author >> Mamatha
 * @Date >>  22/02/23
 * @Time >>  3:16 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CityRequestDto {
    private String id;
    private String stateId;
    @NotNull(message = "city name can't be null!!")
    private String name;
    private boolean isActive;
}
