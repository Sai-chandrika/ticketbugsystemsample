package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  22/06/23
 * @Time >>  12:25 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum RaisedFor {
    MILESTONE,
    CHANGE_REQUEST,
}
