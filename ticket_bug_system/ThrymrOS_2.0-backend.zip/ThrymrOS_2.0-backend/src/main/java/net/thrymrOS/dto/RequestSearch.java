package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  19/07/23
 * @Time >>  5:58 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestSearch {
    private String projectId;
    private String searchKey;
    private Boolean showComplete;
}
