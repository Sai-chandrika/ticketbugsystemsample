package net.thrymrOS.enums;

public enum LeaveStatus {
    PENDING,//0
    APPROVED,//1
    REJECTED,//2
    CANCELLED,//3
    PENDING_CANCELLATION//4
}
