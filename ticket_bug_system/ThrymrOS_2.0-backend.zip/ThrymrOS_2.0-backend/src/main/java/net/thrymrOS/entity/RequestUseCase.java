package net.thrymrOS.entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 06/06/23
 * @Time >> 6:39 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestUseCase extends BaseEntity{
    private String name;
}
