package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.DSRTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  5:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface DSRTaskRepo extends JpaRepository<DSRTask, String> {
    List<DSRTask> findAllByDsrDSROfId(String empId);

    List<DSRTask> findByProjectIdOrderByCreatedOnDesc(String projectId);
    List<DSRTask> findAllByDsrDSROfIdOrderByCreatedOnDesc(String empId);
    List<DSRTask> findAllByDsrDSROfIdAndDsrForDateBetween(String id, LocalDate firstDayOfMonth, LocalDate lastDayOfMonth);

    List<DSRTask> findAllByDsrSubmittedByIdAndDsrForDate(String id, LocalDate date);


    List<DSRTask> findAllByProjectIdAndDsrForDateBetweenOrderByDsrForDateDesc(String id, LocalDate firstDayOfMonth, LocalDate lastDayOfMonth);


    List<DSRTask> findByDsrDSROfIdAndDsrForDate(String id, LocalDate date);

    List<DSRTask> findByDsrDSROfIdAndProjectIdAndDsrForDate(String id, String projectId, LocalDate localDate);

    List<DSRTask> findByDsrDSROfIdAndProjectId(String id, String projectId);

    List<DSRTask> findByProjectIdAndDsrForDate(String projectId, LocalDate date);
    List<DSRTask> findByDsrDSROfIdAndProjectIdAndCategoryIdAndDsrForDate(String empId, String projectId, String category,LocalDate localDate);

    List<DSRTask> findAllByProjectId(String id);

    List<DSRTask> findAllByProjectIdAndDsrForDate(String id, LocalDate localDate);

    List<DSRTask> findByDsrDSROfIdAndCategoryIdAndDsrForDate(String empId, String id, LocalDate localDate);

    List<DSRTask> findByDsrForDate(LocalDate localDate);

    List<DSRTask> findByDsrDSROfIdAndDsrForDateAndTaskNotNull(String empId, LocalDate localDate);

}
