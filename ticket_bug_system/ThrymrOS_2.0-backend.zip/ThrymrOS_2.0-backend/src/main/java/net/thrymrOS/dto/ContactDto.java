package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;


/**
 * @Author >> Mamatha
 * @Date >>  20/02/23
 * @Time >>  11:32 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContactDto {
    private String id;
    private String sequenceNo;
    @NotNull(message = "contact name can't be null!!")
    private String name;
    @Email(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "Invalid email...")
    private String email;
    @Email(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "Invalid email...")
    private String alternativeEmail;
    private String phoneNumber;
    private String alternativePhoneNumber1;
    private String alternativePhoneNumber2;
    private String notes;
    private String activeAccount;
    private String monthOfBirth;
    private String accountId;
    private String accountName;
    private CityDto cityDto;
    private boolean isActive;
}
