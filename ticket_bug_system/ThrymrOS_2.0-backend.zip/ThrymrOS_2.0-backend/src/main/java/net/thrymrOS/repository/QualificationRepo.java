package net.thrymrOS.repository;

import net.thrymrOS.entity.md.md_corehr.Qualification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  24/02/23
 * @Time >>  3:35 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface QualificationRepo extends JpaRepository<Qualification, String> {
    boolean existsByNameIgnoreCase(String name);

    List<Qualification> findAllByOrderByCreatedOnDesc();

    Qualification findByName(String name);

    List<Qualification> findAllByOrderByIsActiveDescNameAsc();

    List<Qualification> findAllByIsActiveEquals(Boolean aTrue);

    List<Qualification> findAllByIsActiveOrderByNameAsc(Boolean aTrue);

    Optional<Qualification> findByNameIgnoreCase(String s);
}
