package net.thrymrOS.entity.employee_engagement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.time.LocalDate;

/**
 * @Author >> Swetha
 * @Date >>  29/03/23
 * @Time >>  11:44 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Album extends BaseEntity {
    private String id;
    private String name;
    @Column(columnDefinition = "TEXT")
    private String description;
    private LocalDate eventDate;
    private LocalDate forDate;
}
