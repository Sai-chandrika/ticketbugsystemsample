package net.thrymrOS.enums;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  03/05/23
 * @Time >>  11:09 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TicketStatus {
    OPEN,//0
    IN_PROGRESS,//1
    ON_HOLD,//2
    DONE,//3
    REJECTED,//4
    APPROVED,//5
    ASSIGNED,//6

}
