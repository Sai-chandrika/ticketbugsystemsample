package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  09/03/23
 * @Time >>  2:51 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum EmployeeType {
    FTE,
    INTERN,
    CONTRACTOR;
}
