package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  06/03/23
 * @Time >>  3:19 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum Day {
    MON,
	TUE,
	WEB,
	THU,
	FRI,
	SAT,
	SUN;
}
