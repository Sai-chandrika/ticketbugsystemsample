package net.thrymrOS.repository;



import net.thrymrOS.entity.asset.AssetStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  31/03/23
 * @Time >>  11:37 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface AssetStatusRepo extends JpaRepository<AssetStatus,String> {
    Optional<AssetStatus> findByNameIgnoreCase(String name);
    List<AssetStatus> findAllByOrderByCreatedOnDesc();

    List<AssetStatus> findAllByOrderByIsActiveDescNameAsc();

    List<AssetStatus> findAllByIsActiveOrderByNameAsc(boolean b);
}
