package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 02-06-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class InterviewReasonHistory extends BaseEntity {
    @ManyToOne(targetEntity = ScheduleInterview.class, cascade = {CascadeType.MERGE})
    private ScheduleInterview scheduleInterview;
    private String reason;
}
