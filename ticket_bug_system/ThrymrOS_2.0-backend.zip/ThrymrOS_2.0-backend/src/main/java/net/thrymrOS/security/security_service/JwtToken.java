package net.thrymrOS.security.security_service;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.DirectEncrypter;
import com.nimbusds.jose.jwk.source.ImmutableSecret;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.JWEDecryptionKeySelector;
import com.nimbusds.jose.proc.JWEKeySelector;
import com.nimbusds.jose.proc.SimpleSecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.entity.token.SessionTime;
import net.thrymrOS.repository.SessionTimeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class JwtToken {

    @Autowired
    SessionTimeRepo sessionTimeRepo;

    @Value("${session.time}")
    private Integer sessionTime;
    public static String secretKey = "841D8A6C80CBA4FCAD32D5367C18C53B";

    /*  public String getToken(AppUser appuser) throws JOSEException {

          //Payload
          JWTClaimsSet.Builder ValidUntil = new JWTClaimsSet.Builder();
          Calendar currentTime = Calendar.getInstance();
          currentTime.add(Calendar.MINUTE, 59);
          Date expirationTime = currentTime.getTime();
          ValidUntil.expirationTime(expirationTime);
          ValidUntil.claim("email", appuser.getEmail())
                  .claim("lastName", appuser.getLastName())
                  .build();



          Payload payload = new Payload(ValidUntil.build().toJSONObject());

          JWEHeader header = new JWEHeader(JWEAlgorithm.DIR, EncryptionMethod.A128CBC_HS256);

          DirectEncrypter encrypter = new DirectEncrypter(secretKey.getBytes(StandardCharsets.UTF_8));

          JWEObject jweObject = new JWEObject(header, payload);
          jweObject.encrypt(encrypter);
          String token=jweObject.serialize();

          if (DynamicToken.userEmail==null || !DynamicToken.userEmail.equals(appuser.getEmail()) || !DynamicToken.fromFilter){
              DynamicToken.originalToken=token;
              DynamicToken.userEmail=appuser.getEmail();
              DynamicToken.copyToken=token;
          }
          if (DynamicToken.fromFilter){
              DynamicToken.userEmail=appuser.getEmail();
              DynamicToken.copyToken=token;
              DynamicToken.fromFilter=false;
          }

          return token;
      }*/
    public String getToken(AppUser appuser) throws JOSEException {

        //Payload
        JWTClaimsSet.Builder ValidUntil = new JWTClaimsSet.Builder();
        ValidUntil.expirationTime(new Date(new Date().getTime() + 8 * 24 * 60 * 60 * 1000));
        ValidUntil.claim("email", appuser.getEmail())
                .claim("lastName", appuser.getLastName())
                .build();

        Payload payload = new Payload(ValidUntil.build().toJSONObject());

        JWEHeader header = new JWEHeader(JWEAlgorithm.DIR, EncryptionMethod.A128CBC_HS256);

        DirectEncrypter encrypter = new DirectEncrypter(secretKey.getBytes(StandardCharsets.UTF_8));

        JWEObject jweObject = new JWEObject(header, payload);
        jweObject.encrypt(encrypter);
        String token = jweObject.serialize();

        List<SessionTime> sessionTimes = sessionTimeRepo.findAll().stream().filter(a -> Duration.between(a.getLastActiveTime(), LocalDateTime.now()).toSeconds() > sessionTime * 60).toList();
        sessionTimeRepo.deleteAll(sessionTimes);
        SessionTime time = new SessionTime();
        time.setId(token);
        time.setLastActiveTime(LocalDateTime.now());
        sessionTimeRepo.save(time);
        return token;
    }

    public Map<String, String> parseToken(String token) throws BadJOSEException, ParseException, JOSEException {
        ConfigurableJWTProcessor<SimpleSecurityContext> jwtProcessor = new DefaultJWTProcessor<SimpleSecurityContext>();
        JWKSource<SimpleSecurityContext> jweKeySource = new ImmutableSecret<SimpleSecurityContext>(secretKey.getBytes());
        JWEKeySelector<SimpleSecurityContext> jweKeySelector =
                new JWEDecryptionKeySelector<SimpleSecurityContext>(JWEAlgorithm.DIR, EncryptionMethod.A128CBC_HS256, jweKeySource);
        jwtProcessor.setJWEKeySelector(jweKeySelector);

        JWTClaimsSet claims = jwtProcessor.process(token, null);


        Map<String, String> stringMap = new HashMap<>();
        stringMap.put("email", (String) claims.getClaim("email"));
        stringMap.put("name", (String) claims.getClaim("name"));
        return stringMap;
    }
}