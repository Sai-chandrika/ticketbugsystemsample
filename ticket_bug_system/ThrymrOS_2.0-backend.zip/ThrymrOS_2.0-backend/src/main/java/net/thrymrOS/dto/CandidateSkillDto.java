package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.corehr.ExpertiseLevel;
import net.thrymrOS.entity.corehr.Skill;
import net.thrymrOS.entity.recruitment.Candidate;

import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 23/05/23
 * @Time ➤➤➤ 11:41 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CandidateSkillDto {
    private String id;
    private SkillDto skill;
    private ExpertiseLevelDto expertiseLevelDto;
    private CandidateDto candidate;
}
