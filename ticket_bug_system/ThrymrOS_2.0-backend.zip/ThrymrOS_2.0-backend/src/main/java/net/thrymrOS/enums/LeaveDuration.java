package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum LeaveDuration {
    FULL_DAY,
    HALF_DAY,
    SHORT_LEAVE
}
