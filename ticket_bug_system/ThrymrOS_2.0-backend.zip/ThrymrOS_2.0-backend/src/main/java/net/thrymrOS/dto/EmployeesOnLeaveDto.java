package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  17/04/23
 * @Time >>  6:36 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class EmployeesOnLeaveDto {
    private List<EmployeeDto> onLeave;
    private List<EmployeeDto> rejected;
    private List<EmployeeDto> pending;
}
