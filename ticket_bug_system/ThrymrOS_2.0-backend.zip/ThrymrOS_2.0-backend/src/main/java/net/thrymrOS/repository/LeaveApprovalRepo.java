package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.LeaveApproval;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  11/04/23
 * @Time >>  1:09 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface LeaveApprovalRepo extends JpaRepository<LeaveApproval, String> {
    List<LeaveApproval> findAllByLeaveId(String leaveId);
}
