package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AssetTransactionStatus;
import net.thrymrOS.enums.CandidateStatus;
import net.thrymrOS.enums.CandidateType;

/**
 * @Author >> Mamatha
 * @Date >>  23/05/23
 * @Time >>  11:05 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class StatusChangeDto {
    private String id;
    private String reason;
    private CandidateStatus status;
    private CandidateType candidateType;
}
