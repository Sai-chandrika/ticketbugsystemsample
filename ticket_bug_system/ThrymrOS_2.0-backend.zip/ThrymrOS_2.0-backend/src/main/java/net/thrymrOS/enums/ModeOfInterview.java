package net.thrymrOS.enums;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 17-05-2023
 */
public enum ModeOfInterview {
    ONLINE,
    OFFLINE

}