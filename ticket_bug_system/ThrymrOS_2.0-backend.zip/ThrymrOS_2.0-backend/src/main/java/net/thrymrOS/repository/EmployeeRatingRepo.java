package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.EmployeeRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/07/23
 * @Time ➤➤➤ 3:42 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface EmployeeRatingRepo extends JpaRepository<EmployeeRating,String> {


    Optional<EmployeeRating> findByCreatedByAndEmployeeId(String id, String employeeId);


    List<EmployeeRating> findByEmployeeIdAndCreatedBy(String empId, String id);

    List<EmployeeRating> findByEmployeeId(String empId);
//    List<EmployeeRating> findByCreatedByAndOrderByCreatedOnDesc(String id);

    List<EmployeeRating> findByCreatedByOrderByCreatedOnDesc(String id);

    List<EmployeeRating> findByCreatedByAndEmployeeIdOrderByCreatedOnDesc(String id, String empId);

    EmployeeRating findByCreatedOn(LocalTime convertedTime);

    List<EmployeeRating> findByCreatedBy(String id);

    Optional<EmployeeRating> findByCreatedOnAndCreatedByAndEmployeeId(Timestamp timestamp, String id, String empId);

    List<EmployeeRating> findByEmployeeIdOrderByCreatedOnDesc(String empId);
}
