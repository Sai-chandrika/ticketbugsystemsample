package net.thrymrOS.repository;

import net.thrymrOS.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.swing.text.html.Option;
import java.util.List;
import java.util.Optional;


@Repository
public interface AppUserRepo extends JpaRepository<AppUser, String> {
  Optional<AppUser> findByEmail(String email);
  List<AppUser> findAllByOrderByIdAsc();
List<AppUser> findAllByOrderByIsActiveDescFirstNameAsc();

    List<AppUser> findAllByIsActive(Boolean value);
    Optional<AppUser> findByContact(String number);

}
