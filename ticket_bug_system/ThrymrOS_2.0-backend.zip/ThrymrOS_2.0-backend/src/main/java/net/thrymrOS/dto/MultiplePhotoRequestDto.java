package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  12/04/23
 * @Time >>  12:33 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@NoArgsConstructor
@Data
public class MultiplePhotoRequestDto {
    private List<String> photoId;
    private String targetAlbumId;
}
