package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.HolidayType;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * @Author >> Mamatha
 * @Date >>  25/05/23
 * @Time >>  12:04 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RegisterCurrentMonthDto {
    private LocalTime avgWorkingHours;
    private LocalDate forDate;
    private Boolean isHoliday;
    private HolidayType holidayType;
}
