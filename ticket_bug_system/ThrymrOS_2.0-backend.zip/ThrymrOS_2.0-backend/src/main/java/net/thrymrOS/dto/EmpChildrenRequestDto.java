package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.Gender;

/**
 * @Author >> Swetha
 * @Date >>  16/03/23
 * @Time >>  4:50 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmpChildrenRequestDto {
    private String id;
    private String name;
    private String age;
    private Gender gender;
    private String employeeId;
}
