package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.LeaveBalanceType;
import net.thrymrOS.enums.LeaveDuration;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  24/08/23
 * @Time >>  3:30 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LeaveMultiSaveDto {
    private String id;
    @NotNull(message = "Leave duration can't be Null/Empty")
    private LeaveDuration leaveDuration;
    @NotNull(message = "from date can't be Null/Empty")
    private LocalDate fromDate;
    @NotNull(message = "to date  can't be Null/Empty")
    private LocalDate toDate;
    @NotNull(message = "Leave Type can't be Null/Empty")
    private LeaveBalanceType leaveBalanceType;
}
