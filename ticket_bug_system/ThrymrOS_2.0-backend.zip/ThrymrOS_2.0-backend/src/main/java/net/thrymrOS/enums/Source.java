package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  4:12 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum Source {
    NAUKRI, //2
    LINKEDIN, //1
    REFERRAL,//2
    OTHERS, //3
}
