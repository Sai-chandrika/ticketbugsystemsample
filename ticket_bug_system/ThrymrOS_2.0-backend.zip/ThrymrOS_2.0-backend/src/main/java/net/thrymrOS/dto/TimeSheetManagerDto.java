package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  15/05/23
 * @Time >>  4:09 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TimeSheetManagerDto {
   private double totalEmployee;
    private List<EmployeeDto> pendingList=new ArrayList<>();
    private  double totalPendingCount;
    private List<EmployeeDto> receivedList =new ArrayList<>();
    private double totalReceivedCount;
    private List<EmployeeDto> approvedList=new ArrayList<>();
    private double totalApprovedCount;
    private List<EmployeeDto> disApprovedList=new ArrayList<>();
    private double totalDisApprovedCount;

//    List<TimeSheetResponseDto> pendingList=new ArrayList<>();
//    double totalPendingList;
//    List<TimeSheetResponseDto> receivedList =new ArrayList<>();
//    double totalReceivedList;
//    List<TimeSheetResponseDto> approvedList=new ArrayList<>();
//    double totalApprovedList;
//    List<TimeSheetResponseDto> disApprovedList=new ArrayList<>();
//    double totalDisApprovedList;

}
