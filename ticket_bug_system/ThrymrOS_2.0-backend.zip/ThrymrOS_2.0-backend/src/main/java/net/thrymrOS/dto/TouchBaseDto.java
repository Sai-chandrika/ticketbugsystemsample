package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CandidateStatus;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  27/05/23
 * @Time >>  12:19 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TouchBaseDto {
    private String candidateId;
    private String candidateName;
    private LocalDate selectedDate;
    private CandidateStatus status;
    private Long noOfInterview;
    private String location;
    private List<EmployeeDto> recruiterList ;
    private List<TouchPointDto> touchPoints;
}
