package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  24/02/23
 * @Time >>  3:54 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum MaritalStatus {
    MARRIED,
    UNMARRIED,
    WIDOWED,
    DIVORCED
}
