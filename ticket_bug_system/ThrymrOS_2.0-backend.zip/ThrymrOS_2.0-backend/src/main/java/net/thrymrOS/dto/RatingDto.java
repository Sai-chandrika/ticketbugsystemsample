package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.RatingType;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/07/23
 * @Time ➤➤➤ 3:30 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RatingDto {
    private String id;
    private RatingType ratingType;
    private Float rating;
    private Boolean isActive;
}
