package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  14/04/23
 * @Time >>  12:44 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class ReportRequestDto {
    private String empId;
    private LocalDate fromDate;
    private LocalDate toDate;
    private List<String> location;
}
