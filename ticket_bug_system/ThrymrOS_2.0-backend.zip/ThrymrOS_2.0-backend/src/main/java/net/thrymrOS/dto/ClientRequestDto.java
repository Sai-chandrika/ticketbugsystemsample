package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Author >> Swetha
 * @Date >>  03/03/23
 * @Time >>  2:53 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ClientRequestDto {
    private String id;
    //   private String name;
    // private String description;
    @NotBlank(message = "Vertical id can't be Null/Empty")
    private String businessVerticalId;
    private String placeOfSupplyId;
    @NotBlank(message = "Client Code can't be Null/Empty")
    private String clientCode;
    @NotNull(message = "Client Type can't be Null")
    private ClientType clientType;
    @NotBlank(message = "Company Name  can't be Null/Empty")
    private String companyName;
    @NotBlank(message = "Client Display Name can't be Null/Empty")
    private String clientDisplayName;
    @NotNull(message = "Location Type can't be Null")
    private LocationType locationType;
    private Salutation salutation;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
   // @NotNull(message = "Gst Treatment can't be Null")
    private GstTreatment gstTreatment;
    private String pan;
    private String currencyId;
    private Double openingBalance;
    private int paymentTerms;
    private TaxPreference taxPreference;
    private AddressRequestDto billingAddress;
    private AddressRequestDto shippingAddress;
    // private boolean copyBillingAddress;

    private String gstNumber;
    private String businessLegalName;
}
