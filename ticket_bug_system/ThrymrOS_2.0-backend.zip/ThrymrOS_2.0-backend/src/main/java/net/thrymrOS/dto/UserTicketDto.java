package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.ticketing_system.RequestPurpose;
import net.thrymrOS.enums.TicketPriority;

import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 06/06/23
 * @Time ➤➤➤ 4:44 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserTicketDto {
    private String id;
    private String typeOfRequest;
    private String ticketName;
    private TicketPriority priority;
    private String location;
    private List<String> fileIds;
    private String description;
}
