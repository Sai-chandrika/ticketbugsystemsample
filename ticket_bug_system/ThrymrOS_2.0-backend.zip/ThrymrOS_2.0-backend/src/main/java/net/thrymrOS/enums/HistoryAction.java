package net.thrymrOS.enums;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  13/07/23
 * @Time >>  12:57 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum HistoryAction {
    ASSIGNED,
    UNASSIGNED
}
