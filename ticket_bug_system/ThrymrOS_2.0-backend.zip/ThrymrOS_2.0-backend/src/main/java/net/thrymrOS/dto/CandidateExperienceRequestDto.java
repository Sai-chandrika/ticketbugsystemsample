package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.NoticePeriod;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  3:57 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CandidateExperienceRequestDto {
    private String id;
    @NotBlank(message = "Education Level can't be Null/Empty")
    private String employer;
    @NotNull(message = "From Date can't be Null/Empty")
    private LocalDate fromDate;
    @NotNull(message = "To Date can't be Null/Empty")
    private LocalDate toDate;
    @NotBlank(message = "Role can't be Null/Empty")
    private String role;
    @NotBlank(message = "Last Working Day can't be Null/Empty")
    private String lastWorkingDay;
    @NotNull(message = "Notice Period Time can't be Null/Empty")
    private NoticePeriod noticePeriodTime;
    @NotBlank(message = "Currency ExpectedCtc  can't be Null/Empty")
    private String currencyExpectedCtcId;
    private double expectedCtc;
    @NotBlank(message = "Currency CurrentCtcId  can't be Null/Empty")
    private String currencyCurrentCtcId;
    private double currentCtc;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;
}
