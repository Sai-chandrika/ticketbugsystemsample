package net.thrymrOS.enums;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 12/06/23
 * @Time >> 11:52 am
 * @Project >> ThrymrOS_2.0-backend
 **/
public enum ReportType {
    REGISTER("via CheckIn and CheckOut"),
    ATTENDANCE("via Register Entries");
    private final String reportName;

    @Override
    public String toString() {
        return reportName;
    }

    ReportType(String reportName) {
        this.reportName = reportName;
    }
}
