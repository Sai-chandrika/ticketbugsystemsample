package net.thrymrOS.dto;

import lombok.*;
import net.thrymrOS.enums.ImportanceType;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 12-06-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class KraDto {
    private String id;
    private String name;
    private String description;
    private ImportanceType importance;
    private Boolean isActive;


}