package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  19/04/23
 * @Time >>  3:21 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LeaveReportDto {
    private String leaveId;
    private String empId;
    private String empName;
    private String employmentId;
    private String date;
    private List<LeaveCalculateDto> leaveCalculateList;
    private int totalLeaveDays;
    private CountBalanceDto leaveCount;
    private float openingBalance;
    private float closingBalance;
}
