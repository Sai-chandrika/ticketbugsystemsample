package net.thrymrOS.custom_exception;


import lombok.Data;

/**
 * @Author >> Mamatha
 * @Date >>  11/03/23
 * @Time >>  11:39 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
public class AccessDeniedException extends RuntimeException{


    public AccessDeniedException(){
        super();
    }
    public AccessDeniedException(String error){
        super(error);

    }

}
