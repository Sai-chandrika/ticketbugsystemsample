package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.corehr.ManagerMapping;

import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 09/05/23
 * @Time >> 4:36 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagerResponseDto {
    List<ProjectTeamResponse> reportedBy;  // MY TEAM MEMBERS
    List<EmployeeDto> reportedTo;          // MY MANAGER
}
