package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.PositionStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  23/03/23
 * @Time >>  11:46 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PositionDto {
    private String id;
    private String name;
    private PositionStatus positionStatus;
    private int positionCount;
    private String positionCode;
    private LocalDate createdDate;
    private LocalDate kickOffDate;
    private LocalDate closureDate;
    private OrganizationUnitDto organizationUnitDto;
    private ClientDto clientDto;
    private LocationDto LocationDto;
    private EmployeeDto hiringManager;
    private List<EmployeeDto> recruiterList =new ArrayList<>();
    private List<FileUploadDto> referenceDocument=new ArrayList<FileUploadDto>();
    private Integer minExperience;
    private Integer maxExperience;
    private CurrencyDto currency;
    private Long budget;
    private String jobDescription;
    private String reason;
    private boolean isActive;
    private List<CandidateDto>candidateDtos;
    private long candidateCount;

}
