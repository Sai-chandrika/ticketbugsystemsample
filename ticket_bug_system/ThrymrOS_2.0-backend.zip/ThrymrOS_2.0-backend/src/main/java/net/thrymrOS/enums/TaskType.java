package net.thrymrOS.enums;

/**
 * @Author >> Giridhar
 * @Date >>  06/03/23
 * @Time >>  02:35 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TaskType {
    TASK,
    BUG,
    TICKET;
}
