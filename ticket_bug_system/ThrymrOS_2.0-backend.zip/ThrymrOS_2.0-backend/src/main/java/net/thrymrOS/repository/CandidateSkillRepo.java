package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.CandidateSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 23/05/23
 * @Time ➤➤➤ 12:08 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface CandidateSkillRepo extends JpaRepository<CandidateSkill,String> {
    List<CandidateSkill> findAllByCandidateId(String id);
    Optional<CandidateSkill> findByCandidateIdAndSkillId(String candidateId, String skillId);
}
