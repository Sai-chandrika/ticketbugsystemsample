package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TaskStatus;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  19/04/23
 * @Time >>  4:51 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class TaskReportDto {
    private String id;
    private String projectName;
    private String task;
    private String assignedTo;
    private int effort;
    private Boolean isComplete;
    private String pTaskCode;
    private LocalDate createdDate;
    private TaskStatus status;
    private MilestoneDto milestoneDto;
    private List<TaskDto> subTask;
    private List<FileUploadDto> fileUploadDtos;
}
