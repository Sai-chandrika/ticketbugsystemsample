package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.Type;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  18/04/23
 * @Time >>  6:01 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class AverageAttendanceReportDto {
    private int leaves;
    private String avgCheckInTime;
    private String avgCheckOutTime;
    private String avgTotalDuration;
    private String avgBreakTime;
    private String avgTotalWorkingHours;
    private String totalWorkingHours;
    private Double actualWorkingDays;
    private Double totalWorkingDays;
    private String empName;
    private EmployeeDto employeeDto;
    private Type recentType;
    private CountBalanceDto leaveCount;
    List<AttendanceDto> attendanceDtoList;
}
