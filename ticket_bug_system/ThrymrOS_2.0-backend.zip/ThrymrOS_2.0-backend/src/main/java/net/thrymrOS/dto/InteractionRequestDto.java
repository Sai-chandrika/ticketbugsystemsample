package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.enums.MeetingStatus;

import java.time.LocalDate;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 05-09-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InteractionRequestDto {
    private String id;
    private LocalDate date;
    private String time;
    private String duration;
    private MeetingStatus status;
    private String agenda;
    private  String reasonForReschedule;
    private String momText;
    private String employeeId;
}
