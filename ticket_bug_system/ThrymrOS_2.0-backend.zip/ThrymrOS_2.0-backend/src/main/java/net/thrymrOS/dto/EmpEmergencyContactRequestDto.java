package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  16/03/23
 * @Time >>  4:21 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmpEmergencyContactRequestDto {
    private String id;
    private String contactNumber;
    private String name;
    private String relationship;

    private String employeeId;
}
