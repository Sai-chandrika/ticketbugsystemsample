package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:44 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class LeaveRequestDto {
    private String id;
    //    private LeaveType leaveType;
    @NotBlank(message = "description Type can't be Null/Empty")
    private String description;
    @NotEmpty(message = "appliedToId Type can't be Null/Empty")
    private List<String> appliedToId;
    @NotEmpty(message = "ccId T can't be Null/Empty")
    private List<String> ccId;
    private String employeeId;
    private Status status;
    private Boolean cancelLeave = Boolean.FALSE;
    private List<String> fileIds;
    private List<LeaveMultiSaveDto> multiSaveList;
    // private NotificationType notificationType;
}
