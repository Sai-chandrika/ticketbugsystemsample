package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.Comment;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.enums.LeaveStatus;

import javax.persistence.*;

/**
 * @Author >> Swetha
 * @Date >>  11/04/23
 * @Time >>  12:40 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LeaveApproval extends BaseEntity {
    private LeaveStatus status;
    private String approvedBy;
    @ManyToOne(cascade = CascadeType.ALL)
    private Leave leave;
    @OneToOne(cascade = CascadeType.ALL)
    private Comment comment;
}
