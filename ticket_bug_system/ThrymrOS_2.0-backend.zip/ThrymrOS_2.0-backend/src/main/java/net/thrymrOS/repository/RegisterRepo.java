package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.Register;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 20/04/23
 * @Time >> 3:01 pm
 * @Project >> ThrymrOS_2.0-backend
 **/

@Repository
public interface RegisterRepo extends JpaRepository<Register, String> {
    List<Register> findAllByOrderByIsActiveDesc();

    List<Register> findAllByIsActiveEquals(Boolean aTrue);

    Optional<Register> findAllByEmployeeIdAndForDate(String empId, LocalDate date);

    List<Register> findAllByEmployeeId(String empId);

    List<Register> findAllByForDate(LocalDate date);

    List<Register> findAllByForDateGreaterThanEqualAndForDateLessThanEqual(LocalDate startDate, LocalDate endDate);

    List<Register> findByEmployeeIdAndForDateOrderByCreatedOnAsc(String id, LocalDate date);

    Optional<Register> findByIdAndForDate(String id, LocalDate forDate);
    /* void deleteAllByForDate(LocalDate date);

    List<Register> findAllByEmployeeIdAndForDateBetween(String id, LocalDate of, LocalDate now);*/
}
