package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.HolidayType;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  05/06/23
 * @Time >>  4:14 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LeaveCalculateDto {
    private LocalDate forDate;
    private Boolean onLeave=Boolean.FALSE;
    private String leaveType;
    private Boolean isHoliday=Boolean.FALSE;
    private String holidayType;
}
