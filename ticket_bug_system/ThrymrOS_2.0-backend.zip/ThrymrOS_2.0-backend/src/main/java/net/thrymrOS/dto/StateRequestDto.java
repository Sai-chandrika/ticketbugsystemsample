package net.thrymrOS.dto;

import lombok.*;

import javax.validation.constraints.NotNull;

/**
 * @Author >> Mamatha
 * @Date >>  22/02/23
 * @Time >>  1:42 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class StateRequestDto {

    private String id;
    @NotNull(message = "state name can't be null!!")
    private String name;
    private String countryId;
    private boolean isActive;
}
