package net.thrymrOS.enums;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  05/08/23
 * @Time >>  11:26 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum SessionType {
    GENERAL_SESSION,
    MORNING_SESSION,
    WORKSHOP,

}
