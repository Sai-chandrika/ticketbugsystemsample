package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.EducationLevel;


import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  5:34 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CandidateEducationDto {
    private String id;
    private EducationLevel educationLevel;
    private QualificationDto qualification;
    private String collage;
    private String fromYear;
    private String toYear;
    private String percentage;
    private CandidateDto candidate;

}
