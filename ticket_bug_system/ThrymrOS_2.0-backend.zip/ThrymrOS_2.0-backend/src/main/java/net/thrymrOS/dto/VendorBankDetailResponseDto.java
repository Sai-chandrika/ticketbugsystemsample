package net.thrymrOS.dto;

import lombok.Data;
import net.thrymrOS.dto.masterdata.dashboard.BankDetailDto;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 29/07/23
 * @Time ➤➤➤ 10:40 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
public class VendorBankDetailResponseDto {
    private VendorDto vendorDto;
    private BankDetailDto bankDetailDto;
}
