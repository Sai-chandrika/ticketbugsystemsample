package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  09/05/23
 * @Time >>  10:19 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TimeSheetPayloadDto {
    private String projectId;
    List<TimeSheetRequestDto> requestDtos=new ArrayList<>();
}
