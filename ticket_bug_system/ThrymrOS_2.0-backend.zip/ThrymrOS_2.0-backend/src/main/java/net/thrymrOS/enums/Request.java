package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  24/04/23
 * @Time >>  11:46 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum Request {
    TODAY,
    THIS_WEEK,
    LAST_WEEK,
    THIS_MONTH,
    ALL_TIME,
    CUSTOM
}
