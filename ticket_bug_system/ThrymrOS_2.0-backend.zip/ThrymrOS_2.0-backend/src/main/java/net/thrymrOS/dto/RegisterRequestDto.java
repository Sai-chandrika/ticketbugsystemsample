package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.sql.Time;
import java.time.LocalDate;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 05/05/23
 * @Time >> 4:17 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequestDto {
    private String id;
    private LocalDate forDate;
    private String employeeId;
    private String checkIn;
    private String checkOut;
    private String workingHours;
    private boolean isActive;
}
