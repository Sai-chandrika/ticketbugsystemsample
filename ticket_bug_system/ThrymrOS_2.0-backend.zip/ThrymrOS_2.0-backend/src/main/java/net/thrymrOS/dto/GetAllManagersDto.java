package net.thrymrOS.dto;

import lombok.Data;


/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 19/05/23
 * @Time ➤➤➤ 11:21 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
public class GetAllManagersDto {
    private EmployeeDto manager;
    private Long projectCount;
}
