package net.thrymrOS.repository;

import net.thrymrOS.entity.md.Level;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;


@Repository
public interface LevelRepo extends JpaRepository<Level,String> {
    //List<Level> findAllByOrderByIdAsc();
    List<Level> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<Level> findByName(String levelName);

    List<Level> findAllByOrderByIsActiveDescNameAsc();
    List<Level> findAllByIsActive(boolean b);

    List<Level> findAllByIsActiveOrderByNameAsc(boolean b);
}
