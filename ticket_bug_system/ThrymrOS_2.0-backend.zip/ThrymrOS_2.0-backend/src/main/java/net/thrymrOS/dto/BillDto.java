package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AmountType;
import net.thrymrOS.enums.PaymentTerms;
import net.thrymrOS.enums.TaxType;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  31/07/23
 * @Time >>  12:04 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillDto {
    private String id;
    private VendorDto vendorDto;
    private String billNumber;
    private String orderNumber;
    private LocalDate billDate;
    private LocalDate dueDate;
    private PaymentTerms paymentTerms;
    private Boolean reverseCharge;

    // BILL ITEAMS
    private List<BillItemDto> billItemDtoList=new ArrayList<>();

    private String note;

    // subtotal-calculation
    private double subTotal;
    private TaxType taxType;
    private AmountType amountType;
    private String discount;
    private String tdsValue;

    private double total;
    private String typeOfAdjust;
    private double amountOfAdjust;
    private boolean isActive;
    private double paid;
    private double balance;


    // FILES
    private List<FileUploadDto> uploadFiles=new ArrayList<FileUploadDto>();
}
