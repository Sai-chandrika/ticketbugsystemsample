package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 30/06/23
 * @Time ➤➤➤ 4:25 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum VendorType {
    BUSINESS,INDIVIDUAL;
}
