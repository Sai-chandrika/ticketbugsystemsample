package net.thrymrOS.enums;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 22-05-2023
 */
public enum InterviewStatus {
    SCHEDULED,
    RE_SCHEDULED,
    COMPLETED,
    CANCELLED;
}