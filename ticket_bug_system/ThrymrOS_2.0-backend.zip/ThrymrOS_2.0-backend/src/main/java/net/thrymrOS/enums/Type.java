package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  2:14 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum Type {
    CHECK_IN,//0
    CHECK_OUT,//1
    START_BREAK,//2
    END_BREAK//3
}
