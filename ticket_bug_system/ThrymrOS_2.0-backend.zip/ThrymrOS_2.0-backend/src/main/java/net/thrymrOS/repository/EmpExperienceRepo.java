package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpExperience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  01/03/23
 * @Time >>  12:41 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface EmpExperienceRepo extends JpaRepository<EmpExperience,String> {
    List<EmpExperience> findAllByEmployeeId(String referenceId);
    List<EmpExperience>findAllByOrderByCreatedOnDesc();
}
