package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @Author >> Mamatha
 * @Date >>  03/03/23
 * @Time >>  2:54 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class SkillMappingRequestDto {
    private String id;
    private String employeeId;
    private String skillId;
    private String expertiseLevelId;
    private boolean isActive;
}
