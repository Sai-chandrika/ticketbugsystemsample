package net.thrymrOS.dto;

import lombok.*;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  24/02/23
 * @Time >>  3:31 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpQualificationDto {

    private String id;
    private QualificationDto qualificationDto;
    private String specialization;
    private String collageName;
    private String university;
    private LocalDate yearOfPassing;
    private String percentage;
    private String referenceEmpId;
    private String empFullName;

}
