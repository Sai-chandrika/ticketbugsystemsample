package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpPersonalData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  24/02/23
 * @Time >>  4:13 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface EmpPersonalDataRepo extends JpaRepository<EmpPersonalData, String> {
    List<EmpPersonalData>findAllByOrderByCreatedOnDesc();
    Optional<EmpPersonalData> findByEmployeeId(String empId);
}
