package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.DSRStatus;



import java.util.Date;

/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  5:38 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class DSRDto {

    private String id;
    private String submittedById;
    private EmployeeDto DSROf;
    private String ForDate;
    private DSRStatus dsrStatus;
}
