package net.thrymrOS.repository;

import net.thrymrOS.entity.crm.Account;
import net.thrymrOS.entity.md.finance.Currency;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.w3c.dom.ls.LSInput;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  17/03/23
 * @Time >>  10:08 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface CurrencyRepo extends JpaRepository<Currency, String > {
    List<Currency> findAllByOrderByIsActiveDescNameAsc();
    List<Currency> findAllByOrderByIsActiveDescCreatedOnDesc();
    List<Currency> findAllByIsActive(boolean b);

    List<Currency> findAllByIsActiveOrderByNameAsc(boolean b);

    Optional<Currency> findByNameIgnoreCase(String s);
}
