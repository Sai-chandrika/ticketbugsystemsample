package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  02/06/23
 * @Time >>  12:17 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum AssetTransactionStatus {
    ASSIGNED,
    UN_ASSIGNED,

}
