package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.FileUpload;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  30/03/23
 * @Time >>  12:57 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class AlbumPhotoResponse {
    private String albumId;
    private String albumName;
    private List<FileUploadDto> list;

}
