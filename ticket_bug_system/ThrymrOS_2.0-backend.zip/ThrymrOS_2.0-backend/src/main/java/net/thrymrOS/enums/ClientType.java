package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 3:56 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum ClientType {
    BUSINESS,
    INDIVIDUAL;
}
