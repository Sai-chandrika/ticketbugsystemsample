package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.pm.Project;

import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 24/04/23
 * @Time >> 5:51 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MyAllocationResponse {
    private ProjectDto project;
    private EmployeeDto employee;
    private List<AllocationDto> allocationList;
    private Double totalDays;

}
