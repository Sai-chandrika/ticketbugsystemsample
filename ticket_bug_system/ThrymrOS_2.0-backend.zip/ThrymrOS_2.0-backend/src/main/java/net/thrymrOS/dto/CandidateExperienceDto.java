package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.NoticePeriod;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  10:41 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateExperienceDto {
    private String id;
    private String employer;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String role;
    private String lastWorkingDay;
    private CandidateDto candidate;
    private NoticePeriod noticePeriodTime;
    private CurrencyDto currencyExpectedCtc;
    private double expectedCtc=0;
    private CurrencyDto currencyCurrentCtc;
    private double currentCtc=0;
}

