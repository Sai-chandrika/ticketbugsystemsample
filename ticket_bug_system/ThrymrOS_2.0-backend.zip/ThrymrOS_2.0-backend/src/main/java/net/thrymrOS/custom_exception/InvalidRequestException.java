package net.thrymrOS.custom_exception;

/**
 * @Author >> Swetha
 * @Date >>  23/02/23
 * @Time >>  3:39 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public class InvalidRequestException extends RuntimeException {

      public InvalidRequestException(String msg) {
        super(msg);
    }
}
