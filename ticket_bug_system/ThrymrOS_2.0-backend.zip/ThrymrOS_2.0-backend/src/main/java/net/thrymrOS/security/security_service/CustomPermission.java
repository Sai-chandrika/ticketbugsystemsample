package net.thrymrOS.security.security_service;

import net.thrymrOS.custom_exception.AccessDeniedException;
import net.thrymrOS.custom_exception.InvalidRequestException;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.entity.Permission;
import net.thrymrOS.entity.md.RoleType;
import net.thrymrOS.enums.AccessType;
import net.thrymrOS.enums.Action;
import net.thrymrOS.enums.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


/**
 * @Author >> Mamatha
 * @Date >>  30/05/23
 * @Time >>  3:13 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Service
public class CustomPermission {


    public static final Logger logger = LoggerFactory.getLogger(CustomPermission.class);

    public Boolean getAuthoriseUser(List<Screen> screenList, AccessType accessType) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        AppUser loggedInUser = (AppUser) authentication.getPrincipal();
        List<Permission> permissionList = new ArrayList<>();
        for (Permission permission : loggedInUser.getRoleType().getPermissions()) {
            for (Screen apiScreen : screenList) {
                if (permission.getScreen().equals(apiScreen)) {
                    if (permission.getReadAccess() || permission.getDeleteAccess() || permission.getWriteAccess()) {
                        permissionList.add(permission);
                    }
                }
            }
        }
        if (!permissionList.isEmpty()) {
            for (Permission havePermission : permissionList) {
                if (accessType.equals(AccessType.READ)) {
                    if (havePermission.getReadAccess()) {
                        return Boolean.TRUE;
                    } else {
                        throw new AccessDeniedException("You don't have read access");
                    }
                } else if (accessType.equals(AccessType.WRITE)) {
                    if (havePermission.getWriteAccess()) {
                        return Boolean.TRUE;
                    } else {
                        throw new AccessDeniedException("You don't have write access");
                    }
                } else if (accessType.equals(AccessType.DELETE)) {
                    if (havePermission.getDeleteAccess()) {
                        return Boolean.TRUE;
                    } else {
                        throw new AccessDeniedException("You don't have Delete access");
                    }
                }
            }
            return null;
        } else {
            throw new AccessDeniedException("You don't have access for this screen");
        }
    }


    public boolean getAuthoriseUsers(Screen screen, RoleType roleType, Action action) {
        for (Permission permission : roleType.getPermissions()) {
            if (screen.equals(permission.getScreen())) {
                if (action.equals(Action.POST) || action.equals(Action.PUT)) {
                    return permission.getWriteAccess();
                }
                if (action.equals(Action.GET)) {
                    return permission.getReadAccess();
                }
                if (action.equals(Action.DELETE)) {
                    return permission.getDeleteAccess();
                }
            }

        }
        return false;
    }







    /*     List<Permission> permissionList=new ArrayList<>();
        for(Screen screen:screenList){
            for (Permission permission:loggedInUser.getRoleType().getPermissions()){
                if (permission.getScreen().equals(screen)){
                    permissionList.add(permission);
                }
            }
        }
        if (permissionList.isEmpty()){
            throw new AccessDeniedException("You don't have access for this screen");
        }
        for (Permission permission:permissionList){
            if (accessType.equals(AccessType.READ) && permission.getReadAccess().equals(Boolean.FALSE)) {
                throw new AccessDeniedException("You don't have Read access");
            } else if (accessType.equals(AccessType.WRITE) && permission.getWriteAccess().equals(Boolean.FALSE)) {
                throw new AccessDeniedException("You don't have Write access");
            } else if (accessType.equals(AccessType.DELETE) && permission.getDeleteAccess().equals(Boolean.FALSE)) {
                throw new AccessDeniedException("You don't have Delete access");
            }
        }
        return true;
        for (Screen screen:screenList) {
            if (loggedInUser.getRoleType().getPermissions().stream().noneMatch(permission -> permission.getScreen().equals(screen))) {
                throw new AccessDeniedException("You don't have access for this screen");
            }
            for (Permission permission : loggedInUser.getRoleType().getPermissions()) {
                if (screen.equals(permission.getScreen())) {
                    if (accessType.equals(AccessType.READ) && permission.getReadAccess().equals(Boolean.FALSE)) {
                        throw new AccessDeniedException("You don't have Read access");
                    } else if (accessType.equals(AccessType.WRITE) && permission.getWriteAccess().equals(Boolean.FALSE)) {
                        throw new AccessDeniedException("You don't have Write access");
                    } else if (accessType.equals(AccessType.DELETE) && permission.getDeleteAccess().equals(Boolean.FALSE)) {
                        throw new AccessDeniedException("You don't have Delete access");
                    }
                }
            }
        }
        return true;
    public boolean getAuthoriseUser(List<Screen> screenList, AccessType accessType) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        AppUser loggedInUser = (AppUser) authentication.getPrincipal();
        for (Screen screen:screenList) {
            if (loggedInUser.getRoleType().getPermissions().stream().noneMatch(permission -> permission.getScreen().equals(screen))) {
                throw new AccessDeniedException("You don't have access for this screen");
            }
            for (Permission permission : loggedInUser.getRoleType().getPermissions()) {
                if (screen.equals(permission.getScreen())) {
                    if (accessType.equals(AccessType.READ) && permission.getReadAccess().equals(Boolean.FALSE)) {
                        throw new AccessDeniedException("You don't have Read access");
                    } else if (accessType.equals(AccessType.WRITE) && permission.getWriteAccess().equals(Boolean.FALSE)) {
                        throw new AccessDeniedException("You don't have Write access");
                    } else if (accessType.equals(AccessType.DELETE) && permission.getDeleteAccess().equals(Boolean.FALSE)) {
                        throw new AccessDeniedException("You don't have Delete access");
                    }
                }
            }
        }
        return true;
    }*/


}


