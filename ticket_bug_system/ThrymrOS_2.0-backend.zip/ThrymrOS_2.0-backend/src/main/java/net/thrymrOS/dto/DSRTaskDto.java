package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.DSRStatus;

import java.util.List;


/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  5:45 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class DSRTaskDto {
    private String id;
    private Long dsrTaskNo;
    private String effort;
    private String task;
    private DSRDto dsr;
    private String projectId;
    private String projectName;
    private String categoryId;
    private String categoryName;
    private String totalEfforts;
    private EmployeeDto employeeDto;
    private List<String> listOfTask;



}
