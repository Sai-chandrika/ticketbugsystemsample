package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 24/08/23
 * @Time ➤➤➤ 10:14 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssetTypeCountDto {
    private String type;
    private long typeCount;
    //private Map<String, Long> locationsCount;
    private  List<CountOfDto> locationsCount;
}
