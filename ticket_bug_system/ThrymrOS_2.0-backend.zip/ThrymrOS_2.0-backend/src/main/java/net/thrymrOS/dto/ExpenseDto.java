package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.masterdata.dashboard.BankDetailDto;
import net.thrymrOS.entity.md.finance.BankDetail;
import net.thrymrOS.enums.AmountType;
import net.thrymrOS.enums.PaymentTerms;
import net.thrymrOS.enums.PaymentType;
import net.thrymrOS.enums.TaxType;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 02/08/23
 * @Time ➤➤➤ 2:43 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ExpenseDto {
    private String id;
    private VendorDto vendorDto;
    private String billNumber;
    private String orderNumber;
    private LocalDate billDate;
    private LocalDate paidDate;
    private PaymentTerms paymentTerms;
    private Boolean reverseCharge;

    // BILL ITEAMS
    private List<BillItemDto> billItemDtoList=new ArrayList<>();

    private String note;

    // subtotal-calculation
    private double subTotal;
    private TaxType taxType;
    private AmountType amountType;
    private double total;
    private String typeOfAdjust;
    private double amountOfAdjust;
    private BankDetailDto bankDetail;
    private PaymentType paymentType;
    private String discount;
    private double partialAmount;
    private String tdsValue;
    private String category;
    private boolean isActive;
    private double balance;
    private Boolean isDraft;

    // FILES
    private List<FileUploadDto> uploadFiles=new ArrayList<>();

}
