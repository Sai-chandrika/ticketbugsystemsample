package net.thrymrOS.dto.masterdata.dashboard;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 06/06/23
 * @Time >> 6:43 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestUseCaseDto {
    private String id;
    private String name;
    private boolean isActive;
}
