package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.Set;

/**
 * @Author >> Giridhar
 * @Date >>  20/02/23
 * @Time >>  12:20 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StateDto {
    private Integer sequenceNo;
    private String id;
    @NotNull(message = "state name can't be null!!")
    private String name;
    private Set<CityDto> cityDtos;
    private CountryDto country;
    private boolean isActive;

}
