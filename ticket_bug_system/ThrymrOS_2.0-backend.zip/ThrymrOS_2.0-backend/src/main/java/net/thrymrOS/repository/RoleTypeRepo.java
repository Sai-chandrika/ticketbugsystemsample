package net.thrymrOS.repository;

import net.thrymrOS.entity.md.RoleType;
import net.thrymrOS.enums.Screen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  04/04/23
 * @Time >>  11:41 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface RoleTypeRepo extends JpaRepository<RoleType, String> {
    boolean existsByNameIgnoreCase(String name);

    List<RoleType> findAllByOrderByIsActiveDescNameAsc();

    List<RoleType> findAllByIsActiveOrderByNameAsc(Boolean b);

    List<RoleType> findAllByIsActiveEquals(Boolean aTrue);

    List<RoleType> findByIdAndIsActiveTrue(String roleId);

    Optional<RoleType> findByNameIgnoreCase(String name);

}
