package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpQualification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  24/02/23
 * @Time >>  3:38 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface EmpQualificationRepo extends JpaRepository<EmpQualification,String> {
    List<EmpQualification> findAllByEmployeeId(String referenceEmpId);
    List<EmpQualification>findAllByOrderByCreatedOnDesc();
    Optional<EmpQualification> findByEmployeeIdAndQualificationId(String referenceEmpId, String id);


}
