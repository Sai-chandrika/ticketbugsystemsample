package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:51 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LeaveResponseDto {
    private String id;
    private LocalDate fromDate;
    private LocalDate toDate;
    private LocalDate dateApplied = LocalDate.now();
    private LeaveType leaveType;
    private float totalLeaves;
    private LeaveBalanceType leaveBalanceType;
    private String shortLeaveType;
    private LeaveStatus status;
    private LeaveDuration leaveDuration;
    private List<FileUploadDto> fileIds = new ArrayList<>();
    private List<LeaveApprovalDto> approvedBy = new ArrayList<LeaveApprovalDto>();
    private List<LeaveApprovalDto> rejectedBy = new ArrayList<LeaveApprovalDto>();
    private List<LeaveApprovalDto> pendingList = new ArrayList<LeaveApprovalDto>();
    private List<EmployeeDto> appliedTo = new ArrayList<EmployeeDto>();
    private List<LeaveApprovalDto> cancelledBy = new ArrayList<>();
    private List<EmployeeDto> cc = new ArrayList<EmployeeDto>();
    private String description;
    private EmployeeDto employee;
    private Boolean cancelLeave = Boolean.FALSE;
    private Boolean appliedBehalf = Boolean.FALSE;
    private String appliedBehalfBy;
    private String cancelReason;
    private List<LeaveMultiSaveDto> saveDtoList;
}
