package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.WorkLocation;
import net.thrymrOS.enums.HolidayType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  17/04/23
 * @Time >>  9:55 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class AttendanceDto {
    private WorkLocationDto workLocation;
    private List<WorkLocationDto> workLocationList;
    private String user;
    private String dateAndDay;
    private List<String> checkInTime;
    private List<String> checkOutTime;
    private String totalDuration;
    private List<String> breakTime;
    private String totalBreakTime;
    private  String totalWorkingHours;
    private Boolean onLeave=Boolean.FALSE;
    private Boolean isHoliday=Boolean.FALSE;
    private String holidayName;
    private Boolean systemLogOut;
}
