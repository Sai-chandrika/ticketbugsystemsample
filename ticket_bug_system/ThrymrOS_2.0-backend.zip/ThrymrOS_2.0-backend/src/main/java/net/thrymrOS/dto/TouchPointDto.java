package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 27/05/23
 * @Time ➤➤➤ 12:13 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TouchPointDto {
    private String id;
    @NotNull(message = "Date can't be Null/Empty")
    private LocalDate date;
    @NotBlank(message = "Description can't be Null/Empty")
    private String description;
    private Boolean isFlag;
    private String redFlag;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;
}
