package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.SkillMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  03/03/23
 * @Time >>  2:59 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface SkillMappingRepo extends JpaRepository<SkillMapping, String> {
    List<SkillMapping> findAllByOrderByIdAsc();

//    List<SkillMapping> findAllByOrderByIsActiveDesc();

    SkillMapping findByEmployeeIdAndSkillId(String empId, String skillId);

    List<SkillMapping> findAllByEmployeeId(String employeeId);

    List<SkillMapping> findAllByIsActiveEquals(Boolean aTrue);

    List<SkillMapping> findAllByOrderByIsActiveDescCreatedOnDesc();
}
