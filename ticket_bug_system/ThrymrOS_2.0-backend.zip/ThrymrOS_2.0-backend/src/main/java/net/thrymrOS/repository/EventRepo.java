package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 08/08/23
 * @Time ➤➤➤ 3:15 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface EventRepo extends JpaRepository<Event ,String> {
    List<Event> findAllByOrderByNameAsc();

    Event findByAlbumId(String id);

    List<Event> findAllByOrderByCreatedOnDesc();

    Optional<Event> findByNameIgnoreCaseAndDateAndLocationIdIsNotNull(String name, LocalDate date);

    List<Event>  findAllByAlbumIdIsNotNull();
}
