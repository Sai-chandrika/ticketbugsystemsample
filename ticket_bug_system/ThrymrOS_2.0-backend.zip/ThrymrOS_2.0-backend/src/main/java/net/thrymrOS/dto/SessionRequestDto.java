package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.ServiceType;
import net.thrymrOS.enums.SessionFrequency;
import net.thrymrOS.enums.SessionType;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  05/08/23
 * @Time >>  11:52 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SessionRequestDto {
    private String id;
    private String topic;
    private String thumbnail;
    private Long duration;
    private LocalDate sessionDate;
    private LocalTime sessionTime;
    private String categoryId;
    private SessionType sessionType;
    private SessionFrequency frequency;
    private ServiceType serviceType;
    private List<String> locationIds;
    private List<String> trainedBy;
    private Boolean isActive;
}
