package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  3:54 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CandidateCertificateRequestDto {
    private String id;
    @NotBlank(message = "Name can't be Null/Empty")
    private String name;
    @NotBlank(message = "Issue Organization can't be Null/Empty")
    private String issueOrganization;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;
}
