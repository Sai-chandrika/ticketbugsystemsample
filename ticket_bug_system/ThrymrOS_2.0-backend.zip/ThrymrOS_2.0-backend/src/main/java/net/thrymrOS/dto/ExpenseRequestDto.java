package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AmountType;
import net.thrymrOS.enums.PaymentTerms;
import net.thrymrOS.enums.PaymentType;
import net.thrymrOS.enums.TaxType;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 02/08/23
 * @Time ➤➤➤ 2:46 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ExpenseRequestDto {
    private String id;
    @NotBlank(message = "vendor Id should not be blank/Empty")
    private String vendorId;
    @NotBlank(message = "bill number should not be blank/Empty")
    private String billNumber;
    private String orderNumber;
    @NotNull(message = "Bill Date Should not be null")
    private LocalDate billDate;
    @NotNull(message = "paid Date Should not be null")
    private LocalDate paidDate;
    private PaymentTerms paymentTerms;
    private Boolean reverseCharge;

    // BILL ITEAMS
    private List<BillItemRequestDto> billItemDtoList=new ArrayList<>();

    private String note;

    // subtotal-calculation
    private double subTotal;
    private TaxType taxType;
    private AmountType amountType;
    private double total;
    private String typeOfAdjust;
    private double amountOfAdjust;
    private String tdsValue;
    @NotNull(message = "payment Type should not be Null")
    private PaymentType paymentType;
    private String discount;
    private double partialAmount;
    @NotBlank(message = "bank Id should not be blank/Empty")
    private String bankId;
    private Boolean isDraft=Boolean.FALSE;
    private double balance;

    // FILES
    private List<String> uploadFileids=new ArrayList<>();

}
