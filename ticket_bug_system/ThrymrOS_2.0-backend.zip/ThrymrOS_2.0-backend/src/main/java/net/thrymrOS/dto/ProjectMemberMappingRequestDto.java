package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TeamRole;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Author >> Mamatha
 * @Date >>  27/03/23
 * @Time >>  12:02 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ProjectMemberMappingRequestDto {
    private String id;
    @NotBlank(message = "Project can't be null/empty")
    private String projectId;
    @NotBlank(message = "Employee can't be null/empty")
    private String employeeId;
    @NotEmpty(message = "Roles can't be null/empty")
    private Set<TeamRole> roleList = new HashSet<>();
    private boolean isActive;
}

