package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  04/03/23
 * @Time >>  9:49 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface ProjectRepo extends JpaRepository<Project, String> {
    List<Project> findAllByOrderByCreatedOnDesc();

    List<Project> findAllByClientId(String clientId);

    List<Project> findAllByIsActiveTrue();

    List<Project> findAllByClientIdOrderByCreatedOnDesc(String clientId);

    List<Project> findAllByOrderByIsActiveDescProjectCodeAsc();

    List<Project> findAllByOrderByIsActiveDescNameAsc();

    List<Project> findByIsPrivateOrderByIsActiveDescNameAsc(Boolean value);

    List<Project> findByIsPrivateFalse();

    Optional<Project> findByNameEqualsIgnoreCase(String name);


    List<Project> findAllByIsActiveEquals(Boolean aTrue);

    List<Project> findAllByIsActiveOrderByNameAsc(boolean b);

    List<Project> findAllByIsActiveAndCreatedOnBetween(Boolean active,Timestamp startDay, Timestamp endDay);
    List<Project> findByManagerIdIsNotNull();
    List<Project> findByManagerId(String managerId);

}
