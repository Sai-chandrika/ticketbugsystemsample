package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  5:35 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateCertificateDto {

    private String id;
    private String name;
    private String issueOrganization;
    private CandidateDto candidate;

}
