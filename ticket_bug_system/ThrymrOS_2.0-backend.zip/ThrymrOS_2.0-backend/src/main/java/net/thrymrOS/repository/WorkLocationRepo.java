package net.thrymrOS.repository;

import net.thrymrOS.entity.md.City;
import net.thrymrOS.entity.md.WorkLocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  09/03/23
 * @Time >>  11:54 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface WorkLocationRepo extends JpaRepository<WorkLocation, String> {
    List<WorkLocation> findAllByOrderByCreatedOnDesc();

    List<WorkLocation> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<WorkLocation> findAllByOrderByIsActiveDescNameAsc();

    List<WorkLocation> findAllByIsActiveEquals(Boolean aTrue);

    List<WorkLocation> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}
