package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.Position;
import net.thrymrOS.enums.PositionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  23/03/23
 * @Time >>  1:07 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface PositionRepo extends JpaRepository<Position, String> {
    List<Position> findAllByOrderByCreatedOnDesc();

    Optional<Position> findByNameIgnoreCase(String name);

    List<Position> findAllByIsActive(boolean b);

    List<Position> findAllByOrderByIsActiveDescNameAsc();

    List<Position> findAllByIsActiveOrderByNameAsc(boolean b);

    List<Position> findByLocationName(String name);

    List<Position> findByOrganizationUnitNameAndKickOffDateBetween(String name, LocalDate startDate, LocalDate endDate);

    Optional<Position> findByNameAndKickOffDate(String name, LocalDate startDate);
    List<Position>findByPositionStatusNotIn(List<PositionStatus> positionStatuses);

    Optional<Position> findByNameAndKickOffDateGreaterThanEqualAndClosureDateLessThanEqual(String name, LocalDate startDate, LocalDate endDate);
}
