package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AllocationType;

import java.time.LocalDate;

/**
 * @Author >> Giridhar
 * @Date >>  14/03/23
 * @Time >>  5:45 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AllocationDto {
    private String id;
    private ProjectDto project;
    private EmployeeDto employee;
    private AllocationType allocationType;
    private LocalDate forDate;
    private boolean isHoliday;
    private String holidayName;
    private boolean onLeave;
    private String leaveType;
}
