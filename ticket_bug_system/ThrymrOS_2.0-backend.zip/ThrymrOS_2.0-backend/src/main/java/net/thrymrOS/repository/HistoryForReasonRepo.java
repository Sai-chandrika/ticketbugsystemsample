package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.InterviewReasonHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 02-06-2023
 */
@Repository
public interface HistoryForReasonRepo extends JpaRepository<InterviewReasonHistory, String> {
    List<InterviewReasonHistory> findByScheduleInterviewIdOrderByCreatedOnDesc(String id);
}