package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.BloodGroup;
import net.thrymrOS.enums.MaritalStatus;

import java.time.LocalDate;

/**
 * @Author >> Swetha
 * @Date >>  24/02/23
 * @Time >>  6:01 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmpPersonalDataDto {

    private String id;
    private String personalEmail;
    private MaritalStatus maritalStatus;
    private BloodGroup bloodGroup;
    private String alternateContactNumber;
    private String aadhaarNumber;
    private String panNumber;
    private String pfNumber;
    private String uanNumber;
    private String esiNumber;
   private LocalDate originalDateOfBirth;
   private EmployeeDto employeeDto;
}
