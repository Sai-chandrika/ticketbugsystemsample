package net.thrymrOS.repository;

import net.thrymrOS.entity.finance.Vendor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 24/06/23
 * @Time >> 11:00 am
 * @Project >> ThrymrOS_2.0-backend
 **/
@Repository
public interface VendorRepo extends JpaRepository<Vendor,String> {
    List<Vendor> findAllByIsActiveTrue();

    List<Vendor> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<Vendor> findByBankDetailBankAccountNumber(String accountNumber);

    Optional<Vendor> findByVendorEmail(String vendorEmail);

    Optional<Vendor> findByVendorCode(String vendorCode);

    List<Vendor> findAllByIsActive(boolean b);
    Optional<Vendor> findByPhoneNumber(String phoneNumber);
    List<Vendor> findAllByBankDetailNotNullOrderByIsActiveDescCreatedOnDesc();



    List<Vendor> findAllByBankDetailNotNullAndBankDetailIsActiveTrue();

    Vendor findByBankDetailId(String bankId);
}
