package net.thrymrOS.repository;

import net.thrymrOS.entity.asset.ChangeAssetStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  02/06/23
 * @Time >>  12:28 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ChangeAssetStatusRepo extends JpaRepository<ChangeAssetStatus,String> {

    List<ChangeAssetStatus> findAllByAssetId(String id);
}
