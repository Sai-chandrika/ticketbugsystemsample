package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 22-07-2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CountBalanceDto {
    private String privilegeLeave;
    private String sickLeave;
    private String compensatoryLeave;
    private String maternityLeave;
    private String paternityLeave;
    private String lossOfPay;
    private String total;
    private EmployeeDto employeeId;
    private String balanceId;
    private boolean isActive;
}

