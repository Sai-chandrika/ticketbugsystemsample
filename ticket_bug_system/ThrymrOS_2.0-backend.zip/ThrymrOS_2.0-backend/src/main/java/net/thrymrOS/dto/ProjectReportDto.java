package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.ProjectStatus;
import net.thrymrOS.enums.ProjectType;

/**
 * @Author >> Swetha
 * @Date >>  19/04/23
 * @Time >>  3:09 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class ProjectReportDto {
    private String projectId;
    private String projectName;
    private EmployeeDto manager;
    private EmployeeDto lead;
    private ProjectType type;
    private String projectCode;
    private ProjectStatus status;
    private Long noOfMileStone;

}
