package net.thrymrOS.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 24/05/23
 * @Time ➤➤➤ 12:26 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Getter
@Setter
public class SetPermissionToRoleDto {
    private String roleId;
    private List<PermissionDto> permissions;
}
