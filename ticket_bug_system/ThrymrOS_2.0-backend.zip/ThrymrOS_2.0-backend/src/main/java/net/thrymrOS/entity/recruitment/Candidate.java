package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Skill;
import net.thrymrOS.entity.md.finance.Currency;
import net.thrymrOS.entity.md.md_corehr.Location;
import net.thrymrOS.enums.CandidateStatus;
import net.thrymrOS.enums.CandidateType;
import net.thrymrOS.enums.NoticePeriod;
import net.thrymrOS.enums.Source;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  9:31 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Candidate extends BaseEntity {
    private String name;
    private CandidateStatus candidateStatus;
    private LocalDate createdDate;
    @ManyToOne(targetEntity = Position.class, cascade = {CascadeType.MERGE })
    private Position position;
    private LocalDate dateOfContact;
    private Source source;
    private String emailId;
    private String phoneNumber;
    private String linkedId;
    private String currentLocation;
    private String nativeLocation;
    private CandidateType candidateType;
    @ManyToOne(targetEntity = Location.class, cascade = {CascadeType.MERGE })
    private Location preferredLocation;

    @ManyToOne(targetEntity = Currency.class, cascade = {CascadeType.MERGE })
    private Currency currencyExpectedCtc;
    @Column(precision = 0)
    private double expectedCtc;
    @ManyToOne(targetEntity = Currency.class, cascade = {CascadeType.MERGE })
    private Currency currencyCurrentCtc;
    @Column(precision = 0)
    private double currentCtc;
    private String candidateImage;
    private String resume;
    private String aadhaarNumber;
    private String aadhaarFile;
    @ElementCollection
    private List<String> otherAttachments=new ArrayList<String>();

    private String candidateCode;



        //  NEW FIELDS
  /*  private String currentCompany;
    private String currentJobTitle;
    private String totalExperience;
    private String relevantExperience;
    private LocalDate lastWorkingDate;
    private NoticePeriod noticePeriod;
    private String nativeNoticePeriod;
    @ManyToOne(targetEntity = Currency.class, cascade = {CascadeType.MERGE })
    private Currency nativeExpectedCtc;
    @Column(precision = 0)
    private Double nativeCtc;
*/



}
