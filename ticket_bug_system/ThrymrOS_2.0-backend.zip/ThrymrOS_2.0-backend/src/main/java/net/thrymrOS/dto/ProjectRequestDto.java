package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.ProjectStatus;
import net.thrymrOS.enums.ProjectType;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * @Author >> Swetha
 * @Date >>  03/03/23
 * @Time >>  2:51 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProjectRequestDto {
    private String id;
    @NotBlank(message = "Project name can't be null/Empty")
    private String name;
    private String description;
    private Boolean isActive;
    @NotNull(message = "Project Status can't be null/Empty")
    private ProjectStatus projectStatus;
    @NotNull(message = "Project Type can't be null/Empty")
    private ProjectType projectType;
    private LocalDate closureDate;
    private LocalDate KickOffDate;
    private String managerId;
    private String leadId;
    @NotBlank(message = "Client Id can't be null/Empty")
    private String clientId;
    @NotBlank(message = "Vertical Id can't be null/Empty")
    private String businessVerticalId;
    private Boolean isPrivate;
}
