package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 18/05/23
 * @Time >> 2:29 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RemainingLeaveCount {
    private float remainingLeaves;
    private float takenLeave;
    private float totalLeaves;
}
