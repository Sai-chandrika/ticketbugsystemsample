package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TeamRole;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Author >> Mamatha
 * @Date >>  27/03/23
 * @Time >>  12:00 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectMemberMappingDto {
    private String id;
    private ProjectDto projectDto;
    private EmployeeDto teamMember;
    private Set<TeamRole> roleList = new HashSet<>();
    private List<ProjectDto> projectDtoList;
    private boolean isActive;

}
