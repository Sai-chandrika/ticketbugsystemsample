package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.md.Category;
import net.thrymrOS.entity.pm.Project;

import javax.persistence.*;

/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  4:53 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class DSRTask extends BaseEntity {
    private double effortHours;
    private double effortMinutes;
    private String task;
    @ManyToOne(cascade = {CascadeType.MERGE })
    private DSR dsr;
    @ManyToOne(targetEntity = Project.class)
    private Project project;
    @ManyToOne(targetEntity = Category.class)
    private Category category;

}
