package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


/**
 * @Author >> Mamatha
 * @Date >>  31/03/23
 * @Time >>  10:45 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssetTypeDto {
    private String id;
    @NotBlank(message = "Asset Type can't be null/Empty")
    private String name;
    @NotNull(message = "Asset Category can't be null/Empty")
    private AssetCategoryDto assetCategory;
    private boolean isActive;

}
