package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Giridhar
 * @Date >>  11/04/23
 * @Time >>  11:03 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagerMappingDto {
    private String id;
    private EmployeeDto employeeDto;
    private EmployeeDto ManagerDto;
    private LocalDate fromDate;
    private LocalDate toDate;
    private boolean isActive;
}
