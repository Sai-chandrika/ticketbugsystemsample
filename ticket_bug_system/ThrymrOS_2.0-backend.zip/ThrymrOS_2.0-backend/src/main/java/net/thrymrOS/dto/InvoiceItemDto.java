package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Mamatha
 * @Date >>  23/06/23
 * @Time >>  12:24 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InvoiceItemDto {
    private String id;
    private String description;
    private String hsnOrSac;
    private long quantity;
    private double rate;
    private double amount;

}
