package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.md.md_corehr.Qualification;
import net.thrymrOS.enums.EducationLevel;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  4:21 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class CandidateEducation extends BaseEntity {
    private EducationLevel educationLevel;
    private String collage;
    private String fromYear;
    private String toYear;
    private String percentage;
    @ManyToOne(targetEntity = Qualification.class, cascade = {CascadeType.MERGE })
    private Qualification qualification;
    @ManyToOne(targetEntity = Candidate.class, cascade = {CascadeType.MERGE })
    private Candidate candidate;


}
