package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  01/04/23
 * @Time >>  11:29 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssetAllocationRequestDto {
    private String id;
    @NotNull(message = "Transaction Date can't be null/Empty")
    private LocalDate transactionDate;
    @NotBlank(message = "Asset can't be null/Empty")
    private String assetId;
    @NotBlank(message = "Issued By can't be null/Empty")
    private String issuedById;
    @NotBlank(message = "Employee can't be null/Empty")
    private String employeeId;
    @NotBlank(message = "Asset Transaction  can't be null/Empty")
    private String transactionTypeId;
    @NotBlank(message = "Description can't be null/Empty")
    private String description;
    private boolean isActive;

}
