package net.thrymrOS.repository;

import net.thrymrOS.entity.RequestUseCase;
import net.thrymrOS.entity.md.ticketing_system.RequestPurpose;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 07/06/23
 * @Time ➤➤➤ 11:34 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface RequestUseCaseRepo extends JpaRepository<RequestUseCase,String> {
    List<RequestUseCase> findAllByIdIn(List<String> useCaseListIds);

    Optional<RequestUseCase> findByNameEqualsIgnoreCase(String name);


    List<RequestUseCase> findAllByIsActiveTrue();

    List<RequestUseCase> findByOrderByIsActiveDescCreatedOnDesc();

//    @Query(value = "SELECT * FROM request_use_case WHERE request_purpose_id='?1'",nativeQuery = true)
//    List<RequestUseCase> findAllByRequestPurposeId(String id);
    //@Modifying
   // @Transactional*/
//    @Query(value = "delete from  request_use_case where request_purpose_id=?1",nativeQuery = true)
//   // @Query("DELETE FROM request_use_case WHERE request_purpose_id=:id")
//    Boolean findByRequestPurposeId(String id);

}
