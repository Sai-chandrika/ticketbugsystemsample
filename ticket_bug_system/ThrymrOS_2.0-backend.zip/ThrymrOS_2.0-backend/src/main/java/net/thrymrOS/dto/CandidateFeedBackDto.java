package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  20/05/23
 * @Time >>  10:33 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateFeedBackDto {
    private String id;
    private String feedBack;
    private String createdTime;
    private String createdBy;
    private String createdByImage;
    private List<FileUploadDto> uploadFiles=new ArrayList<FileUploadDto>();
    private ScheduleInterviewDto scheduleInterviewDto;
}
