package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.ScheduleInterview;
import net.thrymrOS.enums.InterviewStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 18-05-2023
 */
@Repository
public interface ScheduleInterviewRepo extends JpaRepository<ScheduleInterview,String> {



    List<ScheduleInterview> findAllByOrderByIsActiveDescCreatedOnDesc();
    List<ScheduleInterview> findAllByOrderByIsActiveDescInterviewRoundAsc();

    List<ScheduleInterview> findByCandidateIdOrderByCreatedOnDesc(String candidateId);

    List<ScheduleInterview> findByCandidatePositionId(String positionId);

    List<ScheduleInterview> findAllByInterviewDateBetween(LocalDate monday, LocalDate sunday);

    List<ScheduleInterview> findAllByInterviewStatusAndInterviewDateBetween(InterviewStatus interviewStatus, LocalDate monday, LocalDate sunday);

    List<ScheduleInterview> findByCandidateId(String candidateId);
}