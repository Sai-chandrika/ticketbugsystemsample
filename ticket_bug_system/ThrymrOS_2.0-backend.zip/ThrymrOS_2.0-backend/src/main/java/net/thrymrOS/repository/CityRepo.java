package net.thrymrOS.repository;

import org.openxmlformats.schemas.wordprocessingml.x2006.main.STEdGrp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import net.thrymrOS.entity.md.City;

import java.util.List;
import java.util.Optional;

@Repository
public interface CityRepo extends JpaRepository<City,String> {

    Optional<City> findByStateIdAndNameEqualsIgnoreCase(String stateId, String cityName);
    List<City> findAllByOrderByIsActiveDescCreatedOnDesc();
    List<City> findAllByOrderByIsActiveDescNameAsc();
    List<City> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
    List<City> findAllByStateIdAndIsActiveIsTrue(String stateId);
}
