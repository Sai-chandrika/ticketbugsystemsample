package net.thrymrOS.repository;

import net.thrymrOS.entity.finance.BillAccount;
import net.thrymrOS.entity.finance.BillItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 01/08/23
 * @Time ➤➤➤ 2:15 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface BillItemRepo extends JpaRepository<BillItem,String> {

}
