package net.thrymrOS.repository;

import net.thrymrOS.entity.BusinessVertical;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface BusinessVerticalRepo extends JpaRepository<BusinessVertical, String> {

    List<BusinessVertical> findAllByOrderByIdAsc();
    List<BusinessVertical> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<BusinessVertical> findByNameIgnoreCase(String name);

    List<BusinessVertical> findAllByOrderByIsActiveDescNameAsc();

    List<BusinessVertical> findAllByIsActiveOrderByNameAsc(boolean b);
}