package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.masterdata.dashboard.BankDetailDto;
import net.thrymrOS.enums.InvoiceStatus;
import net.thrymrOS.enums.InvoiceType;
import net.thrymrOS.enums.RaisedFor;
import net.thrymrOS.enums.TaxType;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  23/06/23
 * @Time >>  12:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class InvoiceDto {
    private String id;

    private InvoiceStatus invoiceStatus;

    // details
    private String subject;
    private InvoiceType invoiceType;
    private RaisedFor raisedFor;
    private List<MilestoneDto> milestoneList=new ArrayList<MilestoneDto>();

    // invoice-details
    private String invoiceNumber;
    private String poNumber;
    private Integer netDays;
    private LocalDate invoiceDate;
    private LocalDate dueDate;
    private LocalDate poDate;
    private EmployeeDto raisedBy;
    private EmployeeDto sentBy;
    private LocationDto sentFrom;
    private StateDto sentFromState;

    // invoice-items
    private List<InvoiceItemDto> invoiceItemList=new ArrayList<InvoiceItemDto>();

    // bank-transfer-details
    private BankDetailDto bankDetail;
    private String note;

    // subtotal-calculation
    private double subTotal;
    private int iGst;
    private int cGst;
    private int sGst;
    private int discount;
    private String discountType;
    private TaxType taxType;
    private String enterTax;
    private double roundOff;
    private double total;
    private String totalInWords;
    private ProjectDto project;
    private Boolean saveAsDraft;

}
