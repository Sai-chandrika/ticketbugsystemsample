package net.thrymrOS.enums;

public enum CommentType {
    USER,//0
    SYSTEM,//1

}
