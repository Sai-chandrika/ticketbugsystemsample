package net.thrymrOS.dto;

import lombok.Data;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 22-05-2023
 */
@Data
public class ScheduleInterviewCount {
    private Long scheduled;
    private Long completed;
    private Long reScheduled;
    private Long cancelled;
}