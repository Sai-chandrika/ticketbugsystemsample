package net.thrymrOS.custom_exception;

public class SignInException extends RuntimeException{
    public SignInException(String msg){
        super(msg);
    }
}
