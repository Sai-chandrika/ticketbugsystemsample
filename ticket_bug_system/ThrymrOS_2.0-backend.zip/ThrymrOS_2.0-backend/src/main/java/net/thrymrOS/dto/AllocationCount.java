package net.thrymrOS.dto;

import lombok.Data;
import lombok.Setter;

import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 18/05/23
 * @Time ➤➤➤ 12:37 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
public class AllocationCount {
    private Long totalAllocation;
    private List<EmployeeDto> unAssignedEmployee;
    private Long assignedCount;
    private Long unAssignedCount;
}
