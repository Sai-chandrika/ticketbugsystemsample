package net.thrymrOS.enums;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 04-07-2023
 */
public enum MeetingStatus {

    UP_COMING,
    IN_PROGRESS,
    ON_HOLD,
    COMPLETED;


}