package net.thrymrOS.dto.masterdata.dashboard;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 20/05/23
 * @Time >> 12:30 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FinanceDto {
    private Integer currency;
    private Integer paymentType;
}
