package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AllocationType;

import java.time.LocalDate;
 /* @Author >> Giridhar
        * @Date >>  14/03/23
        * @Time >>  5:58 pm
        * @Project >>  ThrymrOS_2.0-backend
        */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class AllocationResponse {
    private String projectId;
    private String employeeId;
    private AllocationType allocationType;
    private LocalDate forDate;
}
