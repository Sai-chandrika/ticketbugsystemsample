package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.MonthlyAppraisal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;


/**
 * @Author >> Mamatha
 * @Date >>  14/03/23
 * @Time >>  6:04 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface MonthlyAppraisalRepo extends JpaRepository<MonthlyAppraisal,String> {
    List<MonthlyAppraisal> findAllByOrderByCreatedOnDesc();
    List<MonthlyAppraisal> findByFromDateGreaterThanEqualAndToDateLessThanEqual(LocalDate startDate, LocalDate endDate);
}
