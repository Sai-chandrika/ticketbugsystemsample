package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TicketPriority;
import net.thrymrOS.enums.TicketStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  28/04/23
 * @Time >>  1:08 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class TicketRequestDto {
    private String id;
    private String ticketName;
    private String description;
    private TicketPriority priority;
    private LocalDate dueDate;
    private String ticketNumber;
    private String response;
    private String reason;
    private TicketStatus status;
    private String location;
    private List<String> assignTo = new ArrayList<String>();
    private List<String> fileIds = new ArrayList<String>();
    private String  requestPermissionTo ;
    private String requestPurposeId;
}
