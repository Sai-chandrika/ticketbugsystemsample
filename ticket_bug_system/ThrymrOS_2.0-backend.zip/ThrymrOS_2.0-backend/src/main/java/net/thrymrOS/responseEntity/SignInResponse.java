package net.thrymrOS.responseEntity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.EmployeeDto;
import net.thrymrOS.dto.RoleTypeDto;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.entity.md.RoleType;


@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SignInResponse {
    private String id;
    private String email;
    private String name;
   // private Role role;
    private RoleTypeDto roleTypeDto;
    private String token;
    private Boolean isEmployee;
    private EmployeeDto employee;
    private Boolean firstLogin;

    public SignInResponse(AppUser user, Boolean value) {
        this.id = user.getId();
        this.name = user.getFirstName()+" "+user.getLastName();
        this.email = user.getEmail();
        this.roleTypeDto=entityToDto(user.getRoleType());
        this.isEmployee=value;
    }

    public SignInResponse(AppUser user, Boolean value,EmployeeDto employeeDto) {
        this.id = user.getId();
        this.name = user.getFirstName()+" "+user.getLastName();
        this.email = user.getEmail();
        this.roleTypeDto=entityToDto(user.getRoleType());
        this.employee = employeeDto;
        this.isEmployee=value;
    }

    public SignInResponse(AppUser user) {
        this.id = user.getId();
        this.name = user.getLastName();
        this.email = user.getEmail();
        this.roleTypeDto=entityToDto(user.getRoleType());

    }
    private RoleTypeDto entityToDto(RoleType roleType) {
        RoleTypeDto dto = new RoleTypeDto();
            dto.setId(roleType.getId());

        dto.setName(roleType.getName());
        dto.setActive(roleType.isActive());
        return dto;
    }
}
