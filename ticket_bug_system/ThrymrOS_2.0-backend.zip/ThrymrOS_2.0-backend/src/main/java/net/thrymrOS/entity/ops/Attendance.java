package net.thrymrOS.entity.ops;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.entity.md.WorkLocation;
import net.thrymrOS.enums.Type;
import org.hibernate.annotations.CreationTimestamp;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import java.sql.Timestamp;
import java.time.Instant;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  12:49 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Attendance extends BaseEntity {

    private Type type;
    /*@CreationTimestamp
    @JsonIgnore*/
    private Timestamp dateTime;
    @ManyToOne(cascade = {CascadeType.MERGE })
    private WorkLocation workLocation;
    @ManyToOne(cascade = {CascadeType.MERGE })
    private Employee employee;
    private Boolean systemCheckOut=Boolean.FALSE;
}
