package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 13/06/23
 * @Time ➤➤➤ 10:17 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class KpiAndKraMappingRequestDto {
    private String id;
    private String kpiId;
    private String kraId;
    private String designationId;
    private String departmentId;
    private String levelId;
    private Boolean isActive;
}
