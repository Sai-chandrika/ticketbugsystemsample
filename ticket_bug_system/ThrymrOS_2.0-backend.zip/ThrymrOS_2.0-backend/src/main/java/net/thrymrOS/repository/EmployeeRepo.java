package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.enums.EmployeeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  24/02/23
 * @Time >>  12:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface EmployeeRepo extends JpaRepository<Employee, String> {
    List<Employee> findAllByOrderByIdAsc();

    List<Employee> findAllByOrderByIsActiveDescFirstNameAsc();

    List<Employee> findAllByIsActiveOrderByFirstNameAsc(boolean b);

    List<Employee> findAllByIsActiveTrueOrderByFirstNameAsc();

    Optional<Employee> findByEmailId(String email);

    Optional<Employee> findByEmailIdAndIsActive(String email, boolean status);

    List<Employee> findAllByIsActiveEquals(Boolean aTrue);

    List<Employee> findAllByLocationName(String location);

    List<Employee> findAllByDepartmentName(String dep);

    List<Employee> findAllByEmployeeTypeAndIsActiveTrue(EmployeeType employeeType);

    long countByIsActive(Boolean value);

    Optional<Employee> findByEmployeeId(String employeeId);

    List<Employee> findAllByOrderByDateOfJoiningDesc();

    List<Employee> findAllByIdNot(String id);


    List<Employee> findAllByRoleNotAndIsActiveOrderByFirstNameAsc(String role, Boolean aTrue);

    List<Employee> findAllByIdNotIn(List<String> list);

    List<Employee> findAllByOrganizationUnitIdAndIsActiveTrueOrderByFirstName(String id);

    List<Employee> findAllByDepartmentId(String deptId);

    List<Employee> findAllByLocationNameAndIsActiveTrueOrderByFirstNameAsc(String location);

    Optional<Employee> findByInternId(String internId);

    List<Employee> findAllByOrderByFirstNameAsc();

    Optional<Employee> findByIdAndIsActive(String assigneeId, boolean b);

    List<Employee> findAllByLocationIdInAndIsActiveTrue(List<String> locationIds);

    /*List<Employee> findByDateOfJoiningBetween(LocalDate startDate, LocalDate endDate);
    Optional<Employee> findByFirstNameAndLastNameAndMiddleName(String firstName, String lastName, String middileName);
    List<Employee> findAllByIsActiveOrderByFirstNameAsc(Boolean aTrue);
    List<Employee> findAllByEmployeeType(EmployeeType employeeType);*/
}
