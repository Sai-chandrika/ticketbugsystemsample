package net.thrymrOS.repository;

import net.thrymrOS.entity.md.md_corehr.Quote;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 29-08-2023
 */
@Repository
public interface QuoteRepo extends JpaRepository<Quote,String> {


    List<Quote> findAllByOrderByCreatedOnDesc();
}

