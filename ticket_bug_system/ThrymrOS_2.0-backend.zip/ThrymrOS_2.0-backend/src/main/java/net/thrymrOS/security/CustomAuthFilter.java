/*
package net.thrymrOS.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.responseEntity.GenericResponse;
import net.thrymrOS.responseEntity.SignIn;
import net.thrymrOS.service.AppUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

public class CustomAuthFilter extends OncePerRequestFilter {

    private AppUserService userService;

    CustomAuthFilter(AppUserService userService) {
        this.userService = userService;
    }

    private static Logger logger = LoggerFactory.getLogger(CustomAuthFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain filter)
            throws IOException {
        try {
            String authToken = req.getHeader("Authorization");
            if (authToken != null) {
                AppUser user = userService.verifyUser(generateLoginDto(authToken.split(":")[0], authToken.split(":")[1]));

//                AppUser user = userService.verifyUser(generateLoginDto(authToken.split(":")[0], authToken.split(":")[0]));
                System.out.println("AppUser === " + user);
                if (user != null) {
                    UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(user, null, Arrays.asList(
                            new SimpleGrantedAuthority(user.getRoleType().getName())));
                    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(req));
                    logger.info("authenticated user " + authToken.split(":")[0] + ", setting security context");
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    filter.doFilter(req, res);
                } else {
                    generateUnauthorisedAccess(res);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            generateUnauthorisedAccess(res);
        }
    }

    public SignIn generateLoginDto(String email, String password) {
        SignIn dto = new SignIn();
        dto.setEmail(email);
        dto.setPassword(password);
        return dto;
    }

    public void generateUnauthorisedAccess(HttpServletResponse res) throws JsonProcessingException, IOException {
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        GenericResponse resp = new GenericResponse(HttpStatus.UNAUTHORIZED.value(), "UNAUTORISED");
        String jsonRespString = ow.writeValueAsString(resp);
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        PrintWriter writer = res.getWriter();
        writer.write(jsonRespString);
        System.out.println("===============================");
        writer.close();
    }

}
*/
