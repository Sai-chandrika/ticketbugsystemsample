package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 4:03 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum TaxPreference {
    TAXABLE,
    TAX_EXEMPT;
}
