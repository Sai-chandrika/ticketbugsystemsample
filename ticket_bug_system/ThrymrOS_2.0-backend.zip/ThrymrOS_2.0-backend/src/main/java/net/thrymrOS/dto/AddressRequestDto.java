package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 5:45 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AddressRequestDto {
    private String id;
    private String address;
    private String countryId;
    private String stateId;
    private String cityId;
    private String zipCode;
    //private String fax;
    private boolean isActive;
}
