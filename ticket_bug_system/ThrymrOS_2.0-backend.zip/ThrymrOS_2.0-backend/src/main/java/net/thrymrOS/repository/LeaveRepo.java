package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.Leave;
import net.thrymrOS.enums.LeaveBalanceType;
import net.thrymrOS.enums.LeaveDuration;
import net.thrymrOS.enums.LeaveStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


/**
 * @Author >> Swetha
 * @Date >>  07/03/23
 * @Time >>  10:51 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface LeaveRepo extends JpaRepository<Leave, String> {


    List<Leave> findAllByOrderByCreatedOnDesc();

    List<Leave> findAllByEmployeeEmailIdOrderByCreatedOnDesc(String email);

    List<Leave> findAllByStatusAndFromDateGreaterThanEqualAndToDateLessThanEqual(LeaveStatus status, LocalDate date1, LocalDate date2);

    List<Leave> findAllByStatusAndMultiLeaveOptionsFromDateLessThanEqualAndMultiLeaveOptionsToDateGreaterThanEqual(LeaveStatus status, LocalDate date1, LocalDate date2);

    List<Leave> findAllByMultiLeaveOptionsLeaveBalanceTypeAndMultiLeaveOptionsFromDateGreaterThanEqualAndMultiLeaveOptionsToDateLessThanEqual(LeaveBalanceType type, LocalDate date1, LocalDate date2);

    List<Leave> findByAppliedToIdOrderByCreatedOnDesc(String empId);

    List<Leave> findAllByIsActiveEquals(Boolean aTrue);

    List<Leave> findByFromDateLessThanEqualAndToDateGreaterThanEqual(LocalDate date1, LocalDate date2);

    List<Leave> findByFromDateGreaterThanEqualAndToDateLessThanEqualOrderByCreatedOnDesc(LocalDate date1, LocalDate date2);

    Optional<Leave> findByEmployeeIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(String empId, LocalDate fromDate, LocalDate toDate);

    List<Leave> findAllByEmployeeIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(String empId, LocalDate fromDate, LocalDate toDate);

    List<Leave> findAllByEmployeeIdOrderByCreatedOnDesc(String id);

    List<Leave> findAllByEmployeeIdAndLeaveBalanceTypeIsNotNullAndMultiLeaveOptionsLeaveBalanceTypeIsNotNullOrderByCreatedOnDesc(String id);

    List<Leave> findByAppliedToIdAndFromDateGreaterThanEqualAndToDateLessThanEqualOrderByCreatedOnDesc(String id, LocalDate startDate, LocalDate endDate);
    List<Leave> findAllByAppliedToIdAndMultiLeaveOptionsFromDateGreaterThanEqualAndMultiLeaveOptionsToDateLessThanEqualOrderByCreatedOnDesc(String id, LocalDate startDate, LocalDate endDate);

    List<Leave> findByCcIdAndFromDateGreaterThanEqualAndToDateLessThanEqualOrderByCreatedOnDesc(String id, LocalDate startDate, LocalDate endDate);
    List<Leave> findByCcIdAndMultiLeaveOptionsFromDateGreaterThanEqualAndMultiLeaveOptionsToDateLessThanEqualOrderByCreatedOnDesc(String id, LocalDate startDate, LocalDate endDate);

    List<Leave> findByEmployeeId(String employeeId);

    Optional<Leave> findByEmployeeIdAndStatusAndFromDateGreaterThanEqualAndToDateLessThanEqualAndCancelLeaveFalse(String empId, LeaveStatus leaveStatus, LocalDate date, LocalDate date1);

    List<Leave> findAllByStatusAndCancelLeaveFalse(LeaveStatus leaveStatus);

    Optional<Leave> findByEmployeeIdAndStatusAndMultiLeaveOptionsFromDateGreaterThanEqualAndMultiLeaveOptionsToDateLessThanEqualAndCancelLeaveFalse(String employeeId, LeaveStatus leaveStatus, LocalDate date, LocalDate date1);
    List<Leave> findAllByEmployeeIdAndStatusAndMultiLeaveOptionsFromDateLessThanEqualAndMultiLeaveOptionsToDateGreaterThanEqualAndCancelLeaveFalse(String employeeId, LeaveStatus leaveStatus, LocalDate date, LocalDate date1);

//    List<Leave> findAllByEmployeeIdAndStatusCancelLeaveFalse(String employeeId, LeaveStatus leaveStatus);
//
//    List<Leave> findAllByEmployeeIdAndStatusAndLeaveBalanceTypeCancelLeaveFalse(String employeeId, LeaveStatus leaveStatus, LeaveBalanceType leaveBalanceType);


    List<Leave> findAllByEmployeeIdAndStatusAndMultiLeaveOptionsLeaveBalanceTypeAndCancelLeaveFalse(String employeeId, LeaveStatus leaveStatus, LeaveBalanceType leaveBalanceType);

    Leave findByEmployeeIdAndIdAndLeaveBalanceType(String id, String leaveId, LeaveBalanceType leaveBalanceType);

    List<Leave> findAllByEmployeeIdAndStatusAndLeaveBalanceTypeAndLeaveDurationAndCancelLeaveFalse(String employeeId, LeaveStatus leaveStatus, LeaveBalanceType leaveBalanceType, LeaveDuration leaveDuration);

    List<Leave> findAllByAppliedToIdOrderByCreatedOnDesc(String id);

    List<Leave> findAllByCcIdOrderByCreatedOnDesc(String id);

    List<Leave> findAllByEmployeeIdAndStatusAndMultiLeaveOptionsFromDateGreaterThanEqualAndMultiLeaveOptionsToDateLessThanEqualAndCancelLeaveFalse(String id, LeaveStatus leaveStatus, LocalDate firstDayOfYear, LocalDate lastDayOfYear);

    List<Leave> findByEmployeeIdAndStatus(String empId, LeaveStatus leaveStatus);

  //  List<Leave> findAllByMultiLeaveOptionsFromDateLessThanEqualAndMultiLeaveOptionsToDateGreaterThanEqual(LocalDate now, LocalDate now1);
    List<Leave> findAllByMultiLeaveOptionsFromDateGreaterThanEqualAndMultiLeaveOptionsToDateLessThanEqual(LocalDate now, LocalDate now1);


    //   List<Leave> findAllByEmployeeEmailIdAndAttachmentIdIsNotNull(String email);
}
