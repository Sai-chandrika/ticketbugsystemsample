package net.thrymrOS.repository;

import net.thrymrOS.entity.asset.AssetStatus;
import net.thrymrOS.entity.crm.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @Author >> Mamatha
 * @Date >>  16/02/23
 * @Time >>  2:27 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface AccountRepo extends JpaRepository<Account,String> {
    List<Account> findAllByOrderByIdAsc();
    List<Account> findAllByOrderByNameAsc();
    List<Account> findAllByOrderByCreatedOnDesc();
    List<Account> findAllByOrderByIsActiveDescCreatedOnDesc();
    boolean existsByNameIgnoreCase(String name);

    List<Account> findAllByOrderByIsActiveDescNameAsc();
    List<Account> findAllByVerticalName(String name);

    List<Account> findAllByIsActiveOrderByNameAsc(boolean b);

    Optional<Account> findByNameIgnoreCase(String s);
}

