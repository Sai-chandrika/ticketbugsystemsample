                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.Type;


/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:27 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AttendanceRequestDto {
    private String id;
    private Type type;
    private String workLocationId;
}
