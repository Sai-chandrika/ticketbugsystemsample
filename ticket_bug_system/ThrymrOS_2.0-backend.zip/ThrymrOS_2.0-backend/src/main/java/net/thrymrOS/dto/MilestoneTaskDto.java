package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  20/04/23
 * @Time >>  3:02 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MilestoneTaskDto {
    private String milestoneId;
    private List<String> taskId=new ArrayList<>();
}
