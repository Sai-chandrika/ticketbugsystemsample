package net.thrymrOS.entity.employee_engagement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;

import javax.persistence.Entity;

/**
 * @Author >> Swetha
 * @Date >>  29/03/23
 * @Time >>  11:45 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Photo extends BaseEntity {
    private String id;
    private String fileId;
    private String albumId;
}
