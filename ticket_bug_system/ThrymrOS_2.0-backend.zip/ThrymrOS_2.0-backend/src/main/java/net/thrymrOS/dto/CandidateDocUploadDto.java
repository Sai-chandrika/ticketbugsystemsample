package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  06/05/23
 * @Time >>  12:06 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class CandidateDocUploadDto {
    private String candidateId;
    private String number;
    private String fileId;
    List<String> listOfFileId=new ArrayList<>();}
