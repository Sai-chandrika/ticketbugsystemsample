package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDate;

/**
 * @Author >> Swetha
 * @Date >>  29/03/23
 * @Time >>  12:15 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AlbumDto {
    private String id;
    private String name;
    private String description;
    private LocalDate eventDate;
    private LocalDate forDate;
    private Boolean isActive;
    private String firstPhotoDownloadUrl;
    private String createdOn;
    private String createdBy;

}
