package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 13/06/23
 * @Time ➤➤➤ 10:16 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class KpiAndKraMappingResponseDto {
    private String id;
    private KPIDto kpi;
    private KraDto kra;
    private DesignationDto designation;
    private DepartmentDto department;
    private LevelDto level;
    private Boolean isActive;
}
