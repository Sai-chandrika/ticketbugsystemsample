package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.ServiceType;
import net.thrymrOS.enums.SessionFrequency;
import net.thrymrOS.enums.SessionStatus;
import net.thrymrOS.enums.SessionType;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  05/08/23
 * @Time >>  11:50 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SessionDto {
    private String id;
    private String topic;
    private FileUploadDto thumbnail;
    private Long duration;
    private LocalDate sessionDate;
    private LocalTime sessionTime;
    private CategoryDto categoryDto;
    private SessionType sessionType;
    private SessionStatus status;
    private SessionFrequency frequency;
    private ServiceType serviceType;
    private List<LocationDto> location;
    private List<EmployeeDto> targetAudience;
    private List<EmployeeDto> trainedBy;
    private Boolean isActive;
}
