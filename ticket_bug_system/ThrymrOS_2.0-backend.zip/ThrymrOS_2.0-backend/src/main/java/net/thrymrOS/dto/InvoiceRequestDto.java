package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;;
import net.thrymrOS.enums.InvoiceStatus;
import net.thrymrOS.enums.InvoiceType;
import net.thrymrOS.enums.RaisedFor;
import net.thrymrOS.enums.TaxType;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  23/06/23
 * @Time >>  12:32 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvoiceRequestDto {
    private String id;
    @NotBlank(message = "Project id can't be Null/Empty")
    private String projectId;
    private InvoiceStatus invoiceStatus;
    // details
    private String subject;
    private InvoiceType invoiceType;
    private RaisedFor raisedFor;
    private List<String> milestoneListOfId;

    // invoice-details
    @NotBlank(message = "Invoice Number can't be Null/Empty")
    private String invoiceNumber;
    private String poNumber;
    private String raisedById;
    private String sentById;
    //private String sentFromId;
    private String sentFromStateId;
    private Integer netDays;
    @NotNull(message = "Invoice Date can't be Null/Empty")
    private LocalDate invoiceDate;
    private LocalDate dueDate;
    private LocalDate poDate;

    // invoice-details-list
    private List<InvoiceItemDto> invoiceItemList;

    @NotBlank(message = "Bank Details can't be Null/Empty")
    // bank details
    private String bankDetailId;
    private String note;

    // sub total-calculations
    private double subTotal;
    private int iGst;
    private int cGst;
    private int sGst;
    private int discount;
    private String discountType;
    private TaxType taxType;
    private String enterTax;
    private double roundOff;
    private double total;
    private Boolean saveAsDraft;
    private Boolean isCancel;

    //.....

//    private Double discountInRupee;
//    private Double discountInPercentage;
}
