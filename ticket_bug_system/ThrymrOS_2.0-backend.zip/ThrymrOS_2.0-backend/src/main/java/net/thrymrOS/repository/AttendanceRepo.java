package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.Attendance;
import net.thrymrOS.enums.Type;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  07/03/23
 * @Time >>  10:11 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface AttendanceRepo extends JpaRepository<Attendance, String> {
    List<Attendance> findAllByEmployeeIdOrderByCreatedOnAsc(String id);

    Attendance findFirstByEmployeeIdAndTypeAndDateTimeBetweenOrderByCreatedOnDesc(String empId, Type type, Timestamp startOfDay, Timestamp endOfDay);

    List<Attendance> findByEmployeeIdAndDateTimeBetweenOrderByCreatedOnAsc(String empId, Timestamp startDate, Timestamp endDate);

    Attendance findFirstByEmployeeIdAndTypeAndDateTimeBetweenOrderByCreatedOnAsc(String empId, Type type, Timestamp startOfDay, Timestamp endOfDay);

    Attendance findFirstByEmployeeIdOrderByCreatedOnAsc(String empId);

    Attendance findFirstByEmployeeIdOrderByCreatedOnDesc(String empId);

    List<Attendance> findLastByEmployeeIdAndType(String empId, Type type);

    Optional<Attendance> findFirstByEmployeeIdOrderByDateTimeDesc(String id);
    List<Attendance> findFirstByEmployeeIdAndTypeOrderByDateTimeDesc(String id,Type type);

//    List<Attendance> findAllByEmployeeIdOrderByDateTimeDesc(String id);
//    List<Attendance> findByDateTimeGreaterThanEqualAndDateTimeLessThanEqual(Timestamp startDate, Timestamp endDate);
//    List<Attendance> findByEmployeeIdAndDateTimeGreaterThanEqualAndDateTimeLessThanEqual(String empId, Timestamp startDate, Timestamp endDate);
//    Attendance findFirstByEmployeeIdAndDateTimeOrderByCreatedOnDesc(String empId, Timestamp date);
//    Attendance findFirstByEmployeeIdAndTypeAndDateTimeEquals(String empId, Type type, Timestamp timestamp);
//    Optional<Attendance> findFirstByEmployeeIdAndTypeInOrderByDateTimeDesc(String id,List<Type> typeList);
//    Optional<Attendance> findByEmployeeIdAndTypeAndDateTimeBetween(String empId, Type type,Timestamp startOfDay,Timestamp endOfDay );
//    List<Attendance> findByEmployeeIdAndDateTimeBetweenOrderByCreatedOnDesc(String empId, Timestamp startOfDay, Timestamp endOfDay);


}