package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.TouchPoint;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 27/05/23
 * @Time ➤➤➤ 12:18 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface TouchPointRepo extends JpaRepository<TouchPoint,String> {
    List<TouchPoint> findAllByOrderByCreatedOnDesc();

    List<TouchPoint> findByCandidateIdOrderByCreatedOnDesc(String id);
}
