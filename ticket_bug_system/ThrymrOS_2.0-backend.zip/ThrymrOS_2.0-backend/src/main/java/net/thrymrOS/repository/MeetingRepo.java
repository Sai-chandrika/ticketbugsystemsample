package net.thrymrOS.repository;

import net.thrymrOS.entity.appraisals.AppraisalMeeting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 04-07-2023
 */
@Repository
public interface MeetingRepo extends JpaRepository<AppraisalMeeting,String> {
    List<AppraisalMeeting> findByOrderByIsActiveDescCreatedOnDesc();
    List<AppraisalMeeting> findAllByEmployeeId(String empId);

    List<AppraisalMeeting> findAllByEmployeeIdOrderByCreatedOnDesc(String empId);
    Optional<AppraisalMeeting> findByEmployeeId(String empId);


    List<AppraisalMeeting> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<AppraisalMeeting> findAllByEmployeeIdOrderByDateDescTimeDesc(String empId);

    Optional<AppraisalMeeting> findByEmployee(String employeeId);

    Optional<AppraisalMeeting> findByTime(String time);

    Optional<AppraisalMeeting> findByDate(LocalDate date);

    List<AppraisalMeeting> findAllByOrderByDateDescTimeDesc();

    Optional<AppraisalMeeting> findByEmployeeEquals(String employeeId);

    Optional<AppraisalMeeting> findByDateEquals(LocalDate date);

    Optional<AppraisalMeeting> findByTimeEquals(String s);

    Optional<AppraisalMeeting> findByEmployeeIdEquals(String employeeId);

    Optional<AppraisalMeeting> findByEmployeeIdAndDateAndTime(String employeeId, LocalDate date, LocalTime time);

    Optional<AppraisalMeeting> findByDateAndTime(LocalDate date, LocalTime localTime);
}