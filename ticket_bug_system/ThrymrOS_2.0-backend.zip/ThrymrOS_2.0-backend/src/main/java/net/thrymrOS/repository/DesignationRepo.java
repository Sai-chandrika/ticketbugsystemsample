package net.thrymrOS.repository;

import net.thrymrOS.entity.md.Designation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface DesignationRepo extends JpaRepository<Designation, String> {
    //List<Designation> findAllByOrderByIdAsc();

    List<Designation> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<Designation> findByNameEqualsIgnoreCase(String designation);


    List<Designation> findAllByOrderByIsActiveDescNameAsc();

    List<Designation> findAllByIsActiveEquals(Boolean aTrue);

    List<Designation> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}
