package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TimeSheetStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  15/04/23
 * @Time >>  2:24 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TimeSheetDto {
    private EmployeeDto employeeDto;
    private ProjectDto projectDto;
    private TimeSheetStatus sheetStatus;
    private List<TimeSheetResponseDto> timeSheetResponseList=new ArrayList<>();
    private double total;
    private String totalHours;

}
