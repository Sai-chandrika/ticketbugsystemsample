package net.thrymrOS.repository;

import com.mongodb.RequestContext;
import net.thrymrOS.entity.ticketing_system.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  28/04/23
 * @Time >>  12:02 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface TicketRepo extends JpaRepository<Ticket, String> {
    Optional<Ticket> findByTicketNameEqualsIgnoreCase(String ticketName);

    boolean existsByTicketNameIgnoreCase(String ticketName);

    List<Ticket> findAllByAssignToId(String id);

    List<Ticket> findByOrderByIsActiveDescCreatedOnDesc();


    List<Ticket> findAllByRequestPermissionToId(String id);

   /* List<Ticket> findByOrderByIsActiveDescCreatedOnDescUpdatedOnDesc();
    List<Ticket> findAllByIsActiveFalseOrderByUpdatedOnDesc();
    List<Ticket> findAllByIsActiveTrueOrderByCreatedOnDescUpdatedOnDesc();
    List<Ticket> findAllByIsActiveTrueOrderByCreatedOnDesc();*/

    List<Ticket> findAllByOrderByIsActiveDescCreatedOnDescUpdatedOnDesc();

    List<Ticket> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<Ticket> findAllByIsActiveTrueOrderByCreatedOnDescUpdatedOnDesc();

    List<Ticket> findAllByIsActiveFalseOrderByCreatedOnDescUpdatedOnDesc();

    List<Ticket> findAllByIsActiveFalseOrderByUpdatedOnAsc();

    List<Ticket> findAllByIsActiveTrueOrderByCreatedOnDesc();

    List<Ticket> findAllByIsActiveFalseOrderByUpdatedOnDesc();


    List<Ticket> findAllByOrderByCreatedOnDesc();

    List<Ticket> findAllByRequestPermissionToIdOrderByIsActiveDesc(String id);

    List<Ticket> findAllByAssignToIdOrderByIsActiveDesc(String id);

    List<Ticket> findAllByRequestPermissionToIdOrderByIsActiveDescCreatedOnDesc(String id);

    List<Ticket> findAllByAssignToIdOrderByIsActiveDescCreatedOnDesc(String id);

    List<Ticket> findByCreatedByOrderByIsActiveDescCreatedOnDesc(String id);
}
