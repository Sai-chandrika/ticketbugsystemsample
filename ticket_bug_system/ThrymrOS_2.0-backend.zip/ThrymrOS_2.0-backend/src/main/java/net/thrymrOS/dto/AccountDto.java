package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;
import net.thrymrOS.entity.crm.Contact;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;


/**
 * @Author >> Mamatha
 * @Date >>  20/02/23
 * @Time >>  11:30 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AccountDto {

    private String id;
    private String sequenceNo;
    @NotEmpty(message = "account name can't be null!!")
    private String name;
    private CityDto cityDto;
    private BusinessVerticalDto verticalDto;
    private List<ContactDto> contactList;
    private boolean isActive;

}
