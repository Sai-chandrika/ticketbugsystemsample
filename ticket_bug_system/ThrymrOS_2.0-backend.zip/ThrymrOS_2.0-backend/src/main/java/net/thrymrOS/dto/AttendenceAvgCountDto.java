package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 26-05-2023
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendenceAvgCountDto {
    private  Double count;
    private LocalDate date;

}