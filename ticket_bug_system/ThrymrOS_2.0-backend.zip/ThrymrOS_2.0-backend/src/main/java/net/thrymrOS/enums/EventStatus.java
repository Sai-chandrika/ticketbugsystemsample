package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 08/08/23
 * @Time ➤➤➤ 2:56 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum EventStatus {

    UPCOMING,
    CANCELLED,
    RESCHEDULED,
    COMPLETED

}
