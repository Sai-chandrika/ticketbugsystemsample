package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  15/03/23
 * @Time >>  4:52 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChangePasswordDto {
    private String appUserId;
    private String defaultPassword;
    private String newPassword;
    private String reTypeNewPassword;
}
