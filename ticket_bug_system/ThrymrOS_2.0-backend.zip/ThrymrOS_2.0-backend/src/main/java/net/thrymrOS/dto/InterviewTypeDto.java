package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 27-05-2023
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class InterviewTypeDto {
    private String id;
    private String name;
    private boolean isActive;

}