package net.thrymrOS.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.RoleType;
import net.thrymrOS.enums.Screen;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 * @Author >> Swetha
 * @Date >>  12/04/23
 * @Time >>  5:43 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Permission extends BaseEntity {
    private Screen screen;
    private Boolean readAccess;
    private Boolean writeAccess;
    private Boolean deleteAccess;

}
