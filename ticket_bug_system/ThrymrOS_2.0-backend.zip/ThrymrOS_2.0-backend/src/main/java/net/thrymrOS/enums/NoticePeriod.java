package net.thrymrOS.enums;

import lombok.ToString;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  6:05 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum NoticePeriod {

   IMMEDIATE("Immediate"),//0
    ONE_WEEK("1 Week"),//1
    TEN_DAYS("10 Days"),//2
    FIFTEEN_DAYS("15 Days"),//3
    THIRTY_DAYS("30 Days"),//4
    FORTY_DAYS("40 Days"),//5
    TWO_MONTHS("2 Months"),//6
    THREE_MONTHS("3 Months");
   final String noticePeriod;
  NoticePeriod(String noticePeriod){
      this.noticePeriod=noticePeriod;
  }

    @Override
    public String toString() {
        return noticePeriod ;
    }
}
