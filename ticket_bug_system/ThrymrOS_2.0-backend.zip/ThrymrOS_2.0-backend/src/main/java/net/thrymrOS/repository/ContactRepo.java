package net.thrymrOS.repository;

import net.thrymrOS.entity.crm.Contact;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  16/02/23
 * @Time >>  11:18 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ContactRepo extends JpaRepository<Contact, String> {
    List<Contact> findAllByOrderByIdAsc();

    List<Contact> findAllByOrderByNameAsc();

    List<Contact> findAllByOrderByIsActiveDescCreatedOnDesc();

    boolean existsByNameIgnoreCase(String name);

    boolean existsByEmailIgnoreCase(String email);
    Optional<Contact> findByEmail(String email);

    List<Contact> findAllByOrderByIsActiveDescNameAsc();

    List<Contact> findAllByIsActiveEquals(Boolean aTrue);

    List<Contact> findAllByIsActiveOrderByNameAsc(Boolean aTrue);

    Optional<Contact> findByPhoneNumber(String phoneNumber);

    List<Contact> findAllByAccountId(String accountId);
}
