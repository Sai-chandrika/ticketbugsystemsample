package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.InvoiceItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @Author >> Mamatha
 * @Date >>  23/06/23
 * @Time >>  3:01 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface InvoiceItemRepo extends JpaRepository<InvoiceItem,String> {
}
