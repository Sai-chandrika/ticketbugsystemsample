package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 19/05/23
 * @Time ➤➤➤ 6:15 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CountOfRole {
    private long qaCount;
    private long baCount;
    private long beDevCount;
    private long designerCount;
    private long feDevCount;
    private long managerCount;
    private long androidDevCount;
    private long iosDevCount;
    private long consultantCount;
    private long architectCount;
    private long totalMemberCount;
    private long teamLead;
    private long wellBeingCoach;
    private long contentWriter;
}
