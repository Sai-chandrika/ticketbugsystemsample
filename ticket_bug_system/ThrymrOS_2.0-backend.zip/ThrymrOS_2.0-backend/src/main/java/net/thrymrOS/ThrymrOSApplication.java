package net.thrymrOS;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.lang.reflect.Array;
import java.util.Arrays;

@SpringBootApplication
@EnableAsync
@EnableScheduling
public class ThrymrOSApplication{

	@Bean
	public BCryptPasswordEncoder getEncoder(){
		return new BCryptPasswordEncoder();
	}

	public static void main(String[] args) {
		SpringApplication.run(ThrymrOSApplication.class, args);
		final Logger logger = LoggerFactory.getLogger( ThrymrOSApplication.class );
		logger.info("***************************************************");
		logger.info("			* ThrymrOS SERVER STARTED *			 	");
		logger.info("***************************************************");
	}

}