package net.thrymrOS.repository;

import net.thrymrOS.entity.token.SessionTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/09/23
 * @Time ➤➤➤ 5:22 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface SessionTimeRepo extends JpaRepository<SessionTime,String> {
}
