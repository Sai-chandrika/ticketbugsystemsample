package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  16/05/23
 * @Time >>  2:11 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TimeSheetApprovalDto {
    private String empId;
    private LocalDate fromDate;
    private LocalDate toDate;
    private List<TimeSheetUnitRequestDto> dtoList = new ArrayList<>();
}
