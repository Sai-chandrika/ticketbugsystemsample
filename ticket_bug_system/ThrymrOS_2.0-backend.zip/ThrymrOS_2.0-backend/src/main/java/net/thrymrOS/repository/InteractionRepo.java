package net.thrymrOS.repository;

import net.thrymrOS.entity.learnignAndDevelopmet.Interaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 05-09-2023
 */
@Repository
public interface InteractionRepo extends JpaRepository<Interaction, String> {
    Optional<Interaction> findByEmployeeIdAndDateAndTime(String employeeId, LocalDate date, LocalTime localTime);

    Optional<Interaction> findByDateAndTime(LocalDate date, LocalTime localTime);

    List<Interaction> findAllByEmployeeIdOrderByDateDescTimeDesc(String empId);

    List<Interaction> findAllByOrderByDateDescTimeDesc();
}
