package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.MeetingStatus;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 06-07-2023
 */
@NoArgsConstructor
@Data
@AllArgsConstructor
public class MeetingStatusDto {
    private String meetingId;
    private MeetingStatus status;
}