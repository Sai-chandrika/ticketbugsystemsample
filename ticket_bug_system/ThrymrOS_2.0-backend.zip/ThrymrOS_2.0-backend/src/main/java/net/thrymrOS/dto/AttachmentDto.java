package net.thrymrOS.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  06/05/23
 * @Time >>  12:12 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public class AttachmentDto {
    String id;
    List<String> list=new ArrayList<>();
}
