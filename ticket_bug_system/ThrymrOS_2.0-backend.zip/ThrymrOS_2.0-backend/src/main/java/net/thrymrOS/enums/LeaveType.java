package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:23 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum LeaveType {
    PLANNED,
    UNPLANNED,
    COMPENSATION,
    LEAVE_WITHOUT_PAY,
    MATERNITY,
    PATERNITY
}
