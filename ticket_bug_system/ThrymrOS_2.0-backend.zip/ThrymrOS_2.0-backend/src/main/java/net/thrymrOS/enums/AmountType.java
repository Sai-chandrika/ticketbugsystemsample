package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  31/07/23
 * @Time >>  11:46 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum AmountType {
    AMOUNT,
    PERCENTAGE,
}
