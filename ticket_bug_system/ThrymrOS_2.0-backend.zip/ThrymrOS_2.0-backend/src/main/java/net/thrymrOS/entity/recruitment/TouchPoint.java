package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import org.hibernate.annotations.ColumnDefault;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import java.time.LocalDate;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 27/05/23
 * @Time ➤➤➤ 12:06 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class TouchPoint extends BaseEntity {
    private LocalDate date;
    @Column(columnDefinition = "TEXT")
    private String description;
    private Boolean isFlag=Boolean.FALSE;
    private String redFlag;
    @ManyToOne(targetEntity = Candidate.class, cascade = {CascadeType.MERGE })
    private Candidate candidate;
}
