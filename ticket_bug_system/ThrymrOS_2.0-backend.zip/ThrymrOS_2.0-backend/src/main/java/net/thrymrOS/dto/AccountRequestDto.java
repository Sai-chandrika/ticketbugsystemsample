package net.thrymrOS.dto;

import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
 * @Author >> Mamatha
 * @Date >>  22/02/23
 * @Time >>  12:32 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AccountRequestDto {
    private String id;
    @NotBlank(message = "Account name can't be null!!")
    private String name;
    @NotBlank(message = "City Idcan't be null!!")
    private String cityId;
    @NotBlank(message = "Vertical can't be null!!")
    private String verticalId;
    private boolean isActive;
}
