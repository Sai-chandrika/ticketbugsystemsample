package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TimeSheetStatus;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  25/04/23
 * @Time >>  10:02 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CalculationDto {
    private LocalDate forDate;
    private String totalWorkingHours;
    private String totalHours;
    private Boolean onLeave;
    private String leaveType;
    private Boolean isHoliday;
    private String holidayName;
    private TimeSheetStatus sheetStatus;
}
