package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.ProjectStatus;
import net.thrymrOS.enums.ProjectType;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  03/03/23
 * @Time >>  2:58 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectDto {
    private String id;
    private String name;
    private String projectCode;
    private String description;
    private Boolean isActive;
    private ProjectStatus projectStatus;
    private ProjectType projectType;
    private LocalDate kickOffDate;
    private LocalDate closureDate;
    private EmployeeDto manager;
    private EmployeeDto lead;
    private BusinessVerticalDto businessVertical;
    private Boolean isPrivate;
    private ClientDto client;
    private List<EmployeeDto> teamList;

}
