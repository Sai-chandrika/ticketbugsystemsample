package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
@NoArgsConstructor
@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TicketAssignDto {
    private String ticketId;
    private String descriptionForRequest;
    private LocalDate dueDate;
    private String requestPermissionTo ;
    private List<String> assignTo = new ArrayList<String>();
}
