package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  01/04/23
 * @Time >>  11:15 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AssetAllocationDto {
    private String id;
    private LocalDate transactionDate;
    private AssetDto asset;
    private EmployeeDto issuedBy;
    private EmployeeDto employee;
    private AssetTransactionTypeDto transactionType;
    private String description;
    private boolean isActive;


}
