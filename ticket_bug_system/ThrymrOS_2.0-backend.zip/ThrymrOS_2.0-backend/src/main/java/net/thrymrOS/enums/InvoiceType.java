package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  22/06/23
 * @Time >>  12:24 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum InvoiceType {
    PRO_FORMA,
    ACTUAL,
}
