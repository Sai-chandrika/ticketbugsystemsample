package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.enums.DSRStatus;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import java.time.LocalDate;
import java.util.Date;

/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  4:50 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class DSR extends BaseEntity {
    private String submittedById;
    @ManyToOne(targetEntity = Employee.class, cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST })
    private Employee DSROf;
    private LocalDate forDate=LocalDate.now();
    private DSRStatus dsrStatus = DSRStatus.DRAFT;
}
