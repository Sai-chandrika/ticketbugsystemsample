package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.EmployeeType;
import net.thrymrOS.enums.Gender;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Giridhar
 * @Date >>  24/02/23
 * @Time >>  12:45 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRequestDto {
    private String id;
    @NotBlank(message = "First Name can't be null")
    private String firstName;
    private String middleName;
    @NotBlank(message = "Last Name can't be null")
    private String lastName;
    private String employeeId;
    private String internId;
    @NotBlank(message = "Email Id can't be null")
    private String emailId;
    @NotNull(message = "Gender can't be null")
    private Gender gender;
    private LocalDate lastWorkingDay;
    @NotNull(message = "Employee Type can't be null")
    private EmployeeType employeeType;
    @NotBlank(message = "Contact Number can't be null")
    private String contactNumber;
    private LocalDate dateOfJoining;
    private LocalDate dateOfJoiningIntern;
    @NotNull(message = "Date Of Birth can't be null")
    private LocalDate dateOfBirth;
    private boolean isActive;
    @NotBlank(message = "Department Id can't be null")
    private String departmentId;
    @NotBlank(message = "Designation Id can't be null")
    private String designationId;
    @NotBlank(message = "Level Id can't be null")
    private String levelId;
    @NotBlank(message = "Organization Unit Id can't be Null")
    private String organizationUnitId;
    @NotBlank(message = "Location id can't be null")
    private String locationId;

}
