package net.thrymrOS.enums;

public enum CommentOf {
    LEAD,//0
    ACCOUNT,//1
    CONTACT,//3
    LEAVE,//4
    PHOTO,//5
    TASK,//6
    MILESTONE,//7
    CANDIDATE,//8
    TICKET,// 9
   APPRAISALMEETING,//10
    INTERACTION,//11

}
