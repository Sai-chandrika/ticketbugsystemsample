package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @Author >> Swetha
 * @Date >>  17/03/23
 * @Time >>  2:09 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FileUploadDto {

        private String fileId;
        private String photoId;
        private String filename;
        private String fileType;
        private String fileSize;
        private byte[] file;
        private String  base64;
        private String downloadUrl;
        private String userName;
        private String createdOn;
        private AboutPhoto aboutPhoto;
        private String viewFile;

}
