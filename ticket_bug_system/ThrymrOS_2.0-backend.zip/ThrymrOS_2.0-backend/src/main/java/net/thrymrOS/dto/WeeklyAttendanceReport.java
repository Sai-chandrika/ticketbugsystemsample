package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  15/04/23
 * @Time >>  4:16 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class WeeklyAttendanceReport {
    private String between;
    private String totalHoursInOffice;
    private String totalBreakHours;
    private String ActualWorkingHours;
}
