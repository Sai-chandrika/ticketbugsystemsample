package net.thrymrOS.repository;

import net.thrymrOS.entity.md.crm.LeadSourceType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  14/02/23
 * @Time >>  3:52 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface LeadSourceRepo extends JpaRepository<LeadSourceType, String> {
    // List<LeadSourceType> findAllByOrderByIdAsc();
    List<LeadSourceType> findAllByOrderByIsActiveDescCreatedOnDesc();


    Optional<LeadSourceType> findByNameIgnoreCase(String name);

    List<LeadSourceType> findAllByOrderByIsActiveDescNameAsc();

    List<LeadSourceType> findAllByIsActiveEquals(Boolean aTrue);

    List<LeadSourceType> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}
