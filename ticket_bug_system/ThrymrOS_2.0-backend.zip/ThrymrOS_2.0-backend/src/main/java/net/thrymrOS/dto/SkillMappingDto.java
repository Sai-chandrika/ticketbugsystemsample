package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * @Author >> Mamatha
 * @Date >>  03/03/23
 * @Time >>  2:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SkillMappingDto {
    private String id;
    private EmployeeDto employeeDto;
    private SkillDto skillDto;
    private ExpertiseLevelDto expertiseLevelDto;
    private boolean isActive;

}
