package net.thrymrOS.repository;

import net.thrymrOS.entity.learnignAndDevelopmet.InteractionReasonHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 05-09-2023
 */
@Repository
public interface InteractionReasonRepo extends JpaRepository<InteractionReasonHistory, String> {
}
