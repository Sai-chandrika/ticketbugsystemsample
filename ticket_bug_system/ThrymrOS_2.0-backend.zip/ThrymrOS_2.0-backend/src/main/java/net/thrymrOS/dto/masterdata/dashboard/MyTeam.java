package net.thrymrOS.dto.masterdata.dashboard;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.EmployeeDto;
import net.thrymrOS.dto.ProjectDto;
import net.thrymrOS.dto.ProjectMemberMappingDto;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  28/07/23
 * @Time >>  3:16 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MyTeam {
    private ProjectDto projectDto;
    private List<ProjectMemberMappingDto> teamList;
}
