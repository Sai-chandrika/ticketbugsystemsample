package net.thrymrOS.enums;


/**
 * @Author >> Mamatha
 * @Date >>  04/04/23
 * @Time >>  11:42 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum FollowUpType {
    THROUGH_CALL,
    THROUGH_CHAT,
    THROUGH_EMAIL,
    PERSONAL_MEETING,
    ONLINE_MEETING,
}
