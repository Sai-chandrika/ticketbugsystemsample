package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CommentOf;
import net.thrymrOS.enums.HistoryAction;

import java.sql.Timestamp;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  13/07/23
 * @Time >>  12:50 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class HistoryDto {
    private String id;
    private String historyOfId;
    private EmployeeDto assignedTo;
    private EmployeeDto assignedBy;
    private HistoryAction HistoryAction;
    private CommentOf historyOf;
    private Timestamp historyOn;
}
