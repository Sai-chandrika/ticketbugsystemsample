package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CandidateStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  27/05/23
 * @Time >>  3:47 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateHistory {
   private ScheduleInterviewDto interviewDto;
   private CommentResponseDto commentResponseDto;
   private CandidateStatusChangeDto statusDto;
   private List<CandidateStatusChangeDto> statusDtoList=new ArrayList<>();
   private List<ScheduleInterviewDto> interviewDtoList=new ArrayList<>();
   private List<CommentResponseDto> commentResponseDtoList=new ArrayList<>();

   public CandidateHistory(ScheduleInterviewDto interviewDto, CommentResponseDto commentResponseDto) {
      this.interviewDto = interviewDto;
      this.commentResponseDto = commentResponseDto;
   }
   public CandidateHistory(ScheduleInterviewDto interviewDto) {
      this.interviewDto = interviewDto;
   }
}
