package net.thrymrOS.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @Author >> Swetha
 * @Date >>  20/02/23
 * @Time >>  11:05 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class LeadSourceTypeDto {
    private String id;
    private boolean isActive;
    @NotNull(message = "lead source name can't be null!!")
    private String name;
    private Integer sequenceNo;

}
