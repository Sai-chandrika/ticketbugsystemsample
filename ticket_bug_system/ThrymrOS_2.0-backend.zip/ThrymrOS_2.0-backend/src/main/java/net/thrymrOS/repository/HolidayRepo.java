package net.thrymrOS.repository;

import net.thrymrOS.entity.md.md_corehr.Holiday;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  14/04/23
 * @Time >>  03:37 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface HolidayRepo extends JpaRepository<Holiday,String> {
    List<Holiday> findAllByOrderByIsActiveDescNameAsc();
    List<Holiday> findAllByLocationId(String locationId);
    Optional<Holiday> findByNameEqualsIgnoreCase(String name);
    Optional<Holiday> findByNameEqualsIgnoreCaseAndLocationId(String name,String locationId);
    List<Holiday> findAllByIsActiveEquals(Boolean aTrue);
    Optional<Holiday> findByFromDate(LocalDate date);

    List<Holiday> findAllByIsActiveOrderByNameAsc(Boolean aTrue);

    Optional<Holiday> findByLocationIdAndFromDate(String id, LocalDate date);
    Optional<Holiday> findByLocationIdAndFromDateOrToDate(String id, LocalDate fromDate,LocalDate toDate);

    Optional<Holiday> findByNameEqualsIgnoreCaseAndLocationIdIn(String s, List<String> locationId);

    List<Holiday> findAllByName(String name);
}
