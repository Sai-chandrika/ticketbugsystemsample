package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

/**
 * @Author >> Swetha
 * @Date >>  30/03/23
 * @Time >>  2:27 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class AboutPhoto {
    private String name;
    private String type;
    private String size;
    private Date createdDate;
    private String albumName;

}
