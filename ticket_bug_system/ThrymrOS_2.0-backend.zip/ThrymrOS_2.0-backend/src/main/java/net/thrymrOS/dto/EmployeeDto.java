package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.EmployeeType;
import net.thrymrOS.enums.Gender;

import java.time.LocalDate;

/**
 * @Author >> Giridhar
 * @Date >>  24/02/23
 * @Time >>  12:46 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeDto {
    private String id;
    private String firstName;
    private String middleName;
    private String lastName;
    private String fullName;
    private String shortName;
    private String employeeId;
    private String internId;
    private String emailId;
    private String contactNumber;
    private LocalDate dateOfJoining;
    private LocalDate dateOfJoiningIntern;
    private LocalDate dateOfBirth;
    private boolean isActive;
    private Gender gender;
    private LocalDate lastWorkingDay;
    private String role;
    private EmployeeType employeeType;
    private DepartmentDto departmentDto;
    private DesignationDto designationDto;
    private LevelDto levelDto;
    private OrganizationUnitDto organizationUnitDto;
    private LocationDto locationDto;
    private String empImage;
    private EmpImageDto empImageDto;
    private AppUserDto createdBy;



}
