package net.thrymrOS.repository;

import net.thrymrOS.entity.History;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  13/07/23
 * @Time >>  12:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface HistoryRepo extends JpaRepository<History,String> {
    List<History> findAllByHistoryOfIdOrderByHistoryOnDesc(String leadId);
}
