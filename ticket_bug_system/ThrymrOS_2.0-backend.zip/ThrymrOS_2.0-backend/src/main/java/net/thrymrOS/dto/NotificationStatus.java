package net.thrymrOS.dto;

import lombok.Data;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 22/05/23
 * @Time >> 12:16 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
public class NotificationStatus {
    private String id;
    private Boolean isRead;
}
