package net.thrymrOS.custom_exception;

public class IdNotFoundException extends RuntimeException {
    private String message;

    public IdNotFoundException(String message) {
        super(message);
    }
}
