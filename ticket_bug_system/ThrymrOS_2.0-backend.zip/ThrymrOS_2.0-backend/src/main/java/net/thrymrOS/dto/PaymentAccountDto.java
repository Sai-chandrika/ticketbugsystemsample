package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.PaymentType;

import java.time.LocalDate;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 03/08/23
 * @Time ➤➤➤ 10:51 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PaymentAccountDto {
    private String billId;
    private PaymentType paymentType;
    private double partialAmount;
    private String bankId;
    private LocalDate paidOn;
}
