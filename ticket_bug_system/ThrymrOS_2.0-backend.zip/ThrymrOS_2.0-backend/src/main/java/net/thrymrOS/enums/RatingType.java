package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/07/23
 * @Time ➤➤➤ 3:20 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum RatingType {
    ATTENDANCE_AND_PUNCTUALITY,
    PRODUCTIVITY_AND_QUALITY_OF_WORK,
    DAILY_STATUS,
    ACCOUNTABILITY,
    TECHNICAL_SKILLS,
}
