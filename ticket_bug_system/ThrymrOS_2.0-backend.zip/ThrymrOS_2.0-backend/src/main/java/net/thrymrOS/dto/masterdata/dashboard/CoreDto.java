package net.thrymrOS.dto.masterdata.dashboard;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 20/05/23
 * @Time >> 12:25 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CoreDto {
    private Integer city;
    private Integer state;
    private Integer country;
    private Integer department;
    private Integer designation;
    private Integer level;
    private Integer organization;
    private Integer roleType;
    private Integer category;
}
