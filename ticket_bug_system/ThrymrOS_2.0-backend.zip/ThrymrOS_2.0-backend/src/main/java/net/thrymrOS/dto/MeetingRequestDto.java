package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.MeetingStatus;

import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 04-07-2023
 */
@NoArgsConstructor
@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MeetingRequestDto {
    private String id;
    private LocalDate date;
    private String time;
    private String duration;
    private MeetingStatus status;
    private String agenda;
    private  String reasonForReschedule;
    private String momText;
    private String employeeId;
}