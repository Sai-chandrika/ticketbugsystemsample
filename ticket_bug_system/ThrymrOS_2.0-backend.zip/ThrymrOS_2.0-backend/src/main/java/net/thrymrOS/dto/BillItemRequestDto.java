package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Mamatha
 * @Date >>  31/07/23
 * @Time >>  12:06 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BillItemRequestDto {
    private String id;
    private String itemDetail;
    private int quantity;
    private double rate;
    private String taxId;
    private double amount;
    private String billAccountId;
}
