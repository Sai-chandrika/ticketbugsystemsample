package net.thrymrOS.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CommentType;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  02/03/23
 * @Time >>  4:07 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CommentResponseDto {
    private String id;
    private String commentedBy;
    private Timestamp commentedOn;
    private String createdOn;
    private String createdTime;
    private String description;
    private CommentType type;
    private EmpImageDto image;
    private String createdByImage;
    private List<FileUploadDto> fileIds=new ArrayList<FileUploadDto>();

}
