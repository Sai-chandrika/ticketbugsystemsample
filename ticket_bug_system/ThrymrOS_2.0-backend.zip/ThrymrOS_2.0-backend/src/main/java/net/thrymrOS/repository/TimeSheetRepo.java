package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.TimeSheetUnit;
import net.thrymrOS.enums.TimeSheetStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Time;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  15/04/23
 * @Time >>  2:28 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface TimeSheetRepo extends JpaRepository<TimeSheetUnit,String> {
    List<TimeSheetUnit> findByEmployeeIdAndForDateBetween(String empId, LocalDate startDate , LocalDate endDate);
    Optional<TimeSheetUnit> findAllByEmployeeIdAndProjectIdAndForDate(String empId, String projectId, LocalDate forDate);
    List<TimeSheetUnit> findAllByEmployeeIdAndProjectIdAndForDateBetween(String empId, String projectId, LocalDate startDate, LocalDate endDate);
    List<TimeSheetUnit> findAllByEmployeeId(String empId);
    List<TimeSheetUnit> findByEmployeeIdAndForDate(String empId, LocalDate forDate);

    List<TimeSheetUnit> findByEmployeeIdAndForDateAndTimeSheetStatusNot(String id, LocalDate forDate, TimeSheetStatus timeSheetStatus);
}
