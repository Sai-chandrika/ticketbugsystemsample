package net.thrymrOS.repository;

import net.thrymrOS.entity.finance.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 01/08/23
 * @Time ➤➤➤ 2:17 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface BillRepo extends JpaRepository<Bill,String> {

    List<Bill> findAllByOrderByCreatedOnDescIsActiveDesc();

    List<Bill> findByVendorId(String vendorId);

    Optional<Bill> findByBillNumber(String billNumber);

    List<Bill> findAllByOrderByIsActiveDescCreatedOnDesc();
}
