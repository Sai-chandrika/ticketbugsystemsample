package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  13/06/23
 * @Time >>  11:04 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum InvoiceStatus {
    PLANNED,
    TO_BE_RAISED,
    RAISED,
    SENT,
    DUE,
    PAID,
    OVER_DUE,
    WRITTEN_OFF,
}
