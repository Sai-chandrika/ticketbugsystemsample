package net.thrymrOS.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha
 * @Date >>  17/03/23
 * @Time >>  10:06 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CurrencyDto {
    private String id;
    private String name;
    private String symbol;
    private boolean isActive;
}
