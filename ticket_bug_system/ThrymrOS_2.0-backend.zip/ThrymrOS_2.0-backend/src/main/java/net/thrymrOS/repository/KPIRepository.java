package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.KPI;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 12/06/23
 * @Time ➤➤➤ 1:23 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface KPIRepository extends JpaRepository<KPI,String> {
    List<KPI> findAllByIsActiveTrueOrderByNameAsc();

    Optional<KPI> findByNameEqualsIgnoreCase(String name);
    List<KPI> findAllByOrderByIsActiveDescNameAsc();
}
