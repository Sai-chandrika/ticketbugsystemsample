package net.thrymrOS.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Giridhar
 * @Date >>  04/04/23
 * @Time >>  11:38 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class RoleTypeDto {
    private String id;
    private String name;
    private boolean isActive;
    private List<PermissionDto> permissions;
}
