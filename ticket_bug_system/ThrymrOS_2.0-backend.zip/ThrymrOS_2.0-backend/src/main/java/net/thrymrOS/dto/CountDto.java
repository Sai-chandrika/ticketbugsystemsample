package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Mamatha
 * @Date >>  06/04/23
 * @Time >>  5:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CountDto {
    private long completed;
    private long pending;
    private long total;
}
