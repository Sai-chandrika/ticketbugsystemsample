package net.thrymrOS.repository;

import net.thrymrOS.entity.md.md_corehr.Emoji;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 04-09-2023
 */
@Repository
public interface EmojiRepo extends JpaRepository<Emoji, String> {

    List<Emoji> findAllByOrderByCreatedOnDesc();
}

