package net.thrymrOS.dto;


import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TeamRole;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  28/03/23
 * @Time >>  1:07 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@NoArgsConstructor
@Data
public class ProjectEmpDto {
    private String id;
    private String empId;
    private String name;
    private String projectCode;
    private List<TeamRole> roleList=new ArrayList<>();
}
