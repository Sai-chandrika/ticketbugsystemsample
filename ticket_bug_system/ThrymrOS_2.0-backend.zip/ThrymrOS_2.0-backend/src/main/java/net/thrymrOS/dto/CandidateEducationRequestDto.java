package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.EducationLevel;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  3:56 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CandidateEducationRequestDto {
    private String id;
    @NotNull(message = "Education Level can't be Null/Empty")
    private EducationLevel educationLevel;
    @NotBlank(message = "Qualification id can't be Null/Empty")
    private String qualificationId;
    @NotBlank(message = "Collage be Null/Empty")
    private String collage;
    @NotBlank(message = "Form Year can't be Null/Empty")
    private String fromYear;
    @NotBlank(message = "To Year can't be Null/Empty")
    private String toYear;
    @NotBlank(message = "Percentage can't be Null/Empty")
    private String percentage;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;

}
