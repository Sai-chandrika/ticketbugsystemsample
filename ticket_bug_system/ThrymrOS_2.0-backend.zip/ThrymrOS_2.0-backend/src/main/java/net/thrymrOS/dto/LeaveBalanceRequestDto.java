package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 22-07-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LeaveBalanceRequestDto {
      private String id;
      private float privilegeLeave;
      private float sickLeave;
      private float compensatoryLeave;
      private float maternityLeave;
      private float paternityLeave;
      private float lossOfPay;
      private boolean isActive;
      private String employeeId;
}