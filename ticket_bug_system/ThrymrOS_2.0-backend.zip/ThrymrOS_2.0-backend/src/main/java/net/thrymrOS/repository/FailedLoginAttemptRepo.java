package net.thrymrOS.repository;

import net.thrymrOS.entity.FailedLoginAttempt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  16/08/23
 * @Time >>  11:41 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface FailedLoginAttemptRepo extends JpaRepository<FailedLoginAttempt, Long> {
    Optional<FailedLoginAttempt> findByUserEmail(String userEmail);
}
