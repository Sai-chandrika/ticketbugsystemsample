package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  30/03/23
 * @Time >>  11:57 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssetRequestDto {
    private String id;
    @NotBlank(message = "Brand Name can't be Null/Empty")
    private String brandName;
    @NotBlank(message = "Organization Unit Id can't be Null/Empty")
    private String organizationUnitId;
    @NotBlank(message = "Location Id can't be Null/Empty")
    private String locationId;
    @NotBlank(message = "Asset Type Id can't be Null/Empty")
    private String assetTypeId;
    @NotBlank(message = "Asset Status Id can't be Null/Empty")
    private String assetStatusId;
    @NotBlank(message = "Currency Id can't be Null/Empty")
    private String currencyId;
    @NotBlank(message = "Vendor Id can't be Null/Empty")
    private String vendorId;
    @NotBlank(message = "Invoice can't be Null/Empty")
    private String invoice;
    @NotNull(message = "Purchase Date can't be Null/Empty")
    private LocalDate purchaseDate;
    private float prize;
    private double quantity ;
    private boolean isActive;
}
