package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  07/08/23
 * @Time >>  4:34 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LocationDepartmentDto {
    private List<String> locationIds;
    private List<String> departmentIds;
}
