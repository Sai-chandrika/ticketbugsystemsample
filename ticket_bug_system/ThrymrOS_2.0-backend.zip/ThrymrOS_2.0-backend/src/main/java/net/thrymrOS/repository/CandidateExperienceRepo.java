package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.CandidateExperience;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  10:58 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface CandidateExperienceRepo extends JpaRepository<CandidateExperience,String> {
    List<CandidateExperience> findAllByCandidateId(String id);
}
