package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskProjectDto {
    private String projectId;
    private String task;
    private List<String> fileIds;
    private String text;

}
