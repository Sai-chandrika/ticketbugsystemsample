package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  19/04/23
 * @Time >>  10:53 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CountOfDto {
    private String id;
    private String name;
    private long count;
    private List<AssetTypeDto> type;
    private Long typeCount;
    private String recentTransaction;
    private List<EmployeeDto> employeeList;
    private List<AssetTypeCountDto> typeCountList;

    private CountOfDto countOfDto;
    private List<CountOfDto> countOfDtoList;
    private LocalDate forDate;


    public CountOfDto(String name, long count) {
        this.name = name;
        this.count = count;
    }

    public CountOfDto(String id,String name, long count, List<AssetTypeCountDto> TypeCountList) {
        this.id=id;
        this.name = name;
        this.count = count;
        this.typeCountList = TypeCountList;
    }


    public CountOfDto(String recentTransaction) {
        this.recentTransaction = recentTransaction;
    }


}
