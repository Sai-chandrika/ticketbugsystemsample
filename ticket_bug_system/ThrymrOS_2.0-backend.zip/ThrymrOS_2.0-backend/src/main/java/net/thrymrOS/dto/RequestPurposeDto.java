package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.masterdata.dashboard.RequestUseCaseDto;

import java.util.List;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  28/04/23
 * @Time >>  2:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class RequestPurposeDto {
    private String id;
    private String name;
    private String departmentId;
//    private List<String> useCaseListIds;
    private List<RequestUseCaseDto> useCaseDtoList;
    private Boolean isActive;
}
