package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 3:59 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum GstTreatment {
    REGISTERED_BUSINESS_REGULAR,
    REGISTERED_BUSINESS_COMPOSITION,
    UN_REGISTERED_BUSINESS,
    CONSUMER,
    OVERSEAS,
    SPECIAL_ECONOMIC_ZONE,
    DEEMED_EXPORT,
    TAX_DEDUCTOR,
    SEZ_DEVELOPER;

}
