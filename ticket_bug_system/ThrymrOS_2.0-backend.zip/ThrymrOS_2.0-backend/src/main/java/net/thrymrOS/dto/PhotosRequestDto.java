package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  30/03/23
 * @Time >>  11:04 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class PhotosRequestDto {
    private List<String> fileIds;
    private String albumId;
}
