package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.ChangeStatus;
import net.thrymrOS.enums.CandidateStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  27/05/23
 * @Time >>  5:26 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ChangeStatusRepo extends JpaRepository<ChangeStatus,String> {
    List<ChangeStatus> findAllByCandidateIdOrderByCreatedOnDesc(String id);

    List<ChangeStatus> findByOldStatusAndNewStatus(CandidateStatus oldStatus, CandidateStatus newStatus);

    List<ChangeStatus> findByCandidateId(String id);
}
