package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AppUserDto {

    private String id;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String contact;
    private boolean isActive;
    private String fullName;
    private RoleTypeDto roleTypeDto;
    private Timestamp createdOn;
    private LocalDateTime updateOn;
    private EmpImageDto empImageDto;
    private Boolean firstLogin;

}
