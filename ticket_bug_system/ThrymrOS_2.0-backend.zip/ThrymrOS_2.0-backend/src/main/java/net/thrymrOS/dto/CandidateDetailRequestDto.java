package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.NoticePeriod;
import net.thrymrOS.enums.Source;

import javax.validation.constraints.NotBlank;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  22/08/23
 * @Time >>  9:51 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CandidateDetailRequestDto {
    private String candidateId;
    private LocalDate dateOfContact;
    private Source source;
    @NotBlank(message = "Email can't be Null/Empty")
    private String emailId;
    @NotBlank(message = "Phone Number can't be Null/Empty")
    private String phoneNumber;
    private String linkedId;
    private String currentLocation;
    private String nativeLocation;
    private String preferredLocationId;
    private String aadharNumber;


    private String currencyExpectedCtcId;
    private double expectedCtc;
    private String currencyCurrentCtcId;
    private double currentCtc;


    private String currentCompany;
    private String currentJobTitle;
    private String totalExperience;
    private String relevantExperience;
    private LocalDate lastWorkingDate;
    private NoticePeriod noticePeriod;
    private String nativeNoticePeriod;
    private String nativeExpectedCtcId;
    private double nativeCtc;
}
