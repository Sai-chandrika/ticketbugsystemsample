package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.AssetTransactionStatus;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  30/03/23
 * @Time >>  11:56 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class AssetDto {
    private String id;
    private String assetName;
    private String brandName;
    private String assetCode;
    private float prize;
    private String invoice;
    private double quantity;
    private LocalDate createdDate;
    private LocalDate purchaseDate;
    private boolean isActive;
    private OrganizationUnitDto organizationUni;
    private LocationDto location;
    private AssetTypeDto assetType;
    private AssetStatusDto assetStatus;
    private AssetTransactionStatus status;
    private CurrencyDto currencyDto;
    private VendorDto vendor;
}
