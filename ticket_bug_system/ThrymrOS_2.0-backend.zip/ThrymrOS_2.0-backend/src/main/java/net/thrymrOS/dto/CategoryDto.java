package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Mamatha
 * @Date >>  09/03/23
 * @Time >>  11:39 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CategoryDto {
    private String id;
    private String name;
    private boolean isActive;
}
