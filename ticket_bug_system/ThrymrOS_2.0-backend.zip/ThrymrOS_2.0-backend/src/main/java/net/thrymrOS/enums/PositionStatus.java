package net.thrymrOS.enums;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  21/04/23
 * @Time >>  4:08 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum PositionStatus {
    NEW,//0
    DRAFT,//1
    OPEN,//2
    IN_PROGRESS,//3
    HOLD,//4
    CLOSED,//5
}
