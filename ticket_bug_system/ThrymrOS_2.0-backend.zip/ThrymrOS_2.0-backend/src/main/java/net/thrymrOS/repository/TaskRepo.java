package net.thrymrOS.repository;

import net.thrymrOS.dto.TaskDto;
import net.thrymrOS.entity.pm.Task;
import net.thrymrOS.enums.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  06/03/23
 * @Time >>  04:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface TaskRepo extends JpaRepository<Task, String> {
    List<Task> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<Task> findAllByAssignedToIdOrderByCreatedOnDesc(String empId);

    List<Task> findAllByProjectId(String projectId);

    List<Task> findAllByIsActiveTrue();



    List<Task> findAllByParentTaskIdOrderByCreatedOnDesc(String id);

    List<Task> findAllByProjectIdAndIsParentOrderByCreatedOnDesc(String projectId, Boolean aTrue);
    List<Task> findAllByProjectIdAndIsParentTrueAndCreatedDateBetweenOrderByCreatedOnDesc(String projectId, LocalDate startDate,LocalDate endDate);
    List<Task> findAllByParentTaskIdAndStatus(String projectId, TaskStatus status);
    List<Task> findAllByParentTaskIdAndStatusNotOrderByCreatedOnDesc(String pTaskId, TaskStatus status);
    List<Task> findAllByProjectIdAndStatusNotOrderByCreatedOnDesc(String projectId, TaskStatus taskStatus);

    List<Task> findAllByIsParent(Boolean aTrue);

    List<Task> findAllByCreatedOnBetween(Timestamp startDate, Timestamp endDate);


    List<Task> findAllByStatusOrderByCreatedOnDesc(TaskStatus status);

    List<Task> findAllByCreateByIdOrderByCreatedOnDesc(String id);

    List<Task> findByProjectIdAndAssignedToId(String projectId, String assignId);

    List<Task> findByProjectIdAndStatus(String projectId, TaskStatus status);

    List<Task> findAllByProjectIdOrderByCreatedOnDesc(String projectId);

    List<Task> findAllByProjectIdAndAssignedToId(String projectId, String id);



    List<Task> findAllByIdOrderByCreatedOnDesc(String id);



    // List<Task> findAllByProjectIdAndTaskContainingIgnoreCaseOrProjectIdAndProjectIdAndAssignedToFirstNameContainingIgnoreCaseOrPTaskCodeContainingIgnoreCase(String projectId, String task, String project1, String code, String projectId2, String inputValue);
}
