package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  27/03/23
 * @Time >>  11:56 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TeamRole {
    BE_DEV,
    QA,
    BA,
    DESIGNER,
    MANAGER,
    FE_DEV,
    ANDROID_DEV,
    IOS_DEV,
    FLUTTER_DEV,
    CONSULTANT,
    ARCHITECT,
    TEAM_LEAD,
    WELL_BEING_COACH,
    CONTENT_WRITER,

 /*
  Manager, FE Dev , BE Dev, Android Dev, IOS Dev, Flutter Dev, Consultant, Architect
    team Lead, Architect, Well being coach, Content writer
      */
}
