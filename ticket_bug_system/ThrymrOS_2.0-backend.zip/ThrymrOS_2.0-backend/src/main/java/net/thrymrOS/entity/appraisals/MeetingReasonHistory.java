package net.thrymrOS.entity.appraisals;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.recruitment.ScheduleInterview;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 06-07-2023
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class MeetingReasonHistory extends BaseEntity {
    @OneToOne(targetEntity = AppraisalMeeting.class, cascade = {CascadeType.MERGE})
    private AppraisalMeeting meeting;
    private String reason;
}