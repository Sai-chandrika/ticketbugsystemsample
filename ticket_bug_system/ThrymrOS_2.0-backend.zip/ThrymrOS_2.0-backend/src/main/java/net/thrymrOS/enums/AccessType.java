package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  04/07/23
 * @Time >>  2:13 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum AccessType {
    READ, // 1
    WRITE, // 1
    DELETE, //2
}
