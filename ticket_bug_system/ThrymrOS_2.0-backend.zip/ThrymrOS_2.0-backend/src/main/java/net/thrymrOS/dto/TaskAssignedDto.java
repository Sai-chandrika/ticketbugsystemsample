package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  05/05/23
 * @Time >>  10:02 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class TaskAssignedDto {
    private String id;
    private String task;
    private String description;
    private String pTaskCode;
    private Boolean isParent;
    private Boolean isAssigned=Boolean.FALSE;
}
