package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.Screen;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 19-05-2023
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PermissionDto {
    private String id;
    private Screen screen;
    private Boolean readAccess;
    private Boolean writeAccess;
    private Boolean deleteAccess;
}