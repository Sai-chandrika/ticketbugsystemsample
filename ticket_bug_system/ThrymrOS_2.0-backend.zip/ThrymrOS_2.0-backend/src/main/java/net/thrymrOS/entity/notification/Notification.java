package net.thrymrOS.entity.notification;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.enums.NotificationOf;
import net.thrymrOS.enums.NotificationType;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  08/05/23
 * @Time >>  5:12 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notification extends BaseEntity {
    private String notificationText;
    private Boolean isRead = Boolean.FALSE;
    private NotificationType notificationType=NotificationType.STANDARD;
    @ManyToOne(cascade = {CascadeType.MERGE,CascadeType.DETACH}, fetch = FetchType.EAGER)
    private AppUser fromAppUser;
    @ManyToOne(cascade = {CascadeType.MERGE,CascadeType.DETACH}, fetch = FetchType.EAGER)
    private AppUser toAppUser;
    private NotificationOf notificationOf;
    private String notificationOfId;
}