package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @Author >> Mamatha
 * @Date >>  31/03/23
 * @Time >>  11:33 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AssetStatusDto {
    private String id;
    @NotBlank(message = "Asset Status can't be null/Empty")
    private String name;
    private boolean isActive;

}
