package net.thrymrOS.repository;


import net.thrymrOS.entity.md.md_corehr.LeaveBalance;

import net.thrymrOS.specification.GenericSearchSpecification;
import org.springframework.beans.PropertyValues;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 22-07-2023
 */
@Repository
public interface LeaveBalanceRepo extends JpaRepository<LeaveBalance ,String> , JpaSpecificationExecutor<LeaveBalance> {
      List<LeaveBalance> findByOrderByIsActiveDescCreatedOnDesc(PageRequest request);
      List<LeaveBalance> findByOrderByIsActiveDescCreatedOnDesc();
      Optional<LeaveBalance> findByEmployeeId(String empId);
      List<LeaveBalance> findByEmployeeIdOrderByCreatedOnDesc(String empId);

    //List<LeaveBalance> findAllOrderByCreatedOnDesc();
}