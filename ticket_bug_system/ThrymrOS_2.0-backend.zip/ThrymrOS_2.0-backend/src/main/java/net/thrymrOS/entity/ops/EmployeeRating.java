package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;

import javax.persistence.*;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/07/23
 * @Time ➤➤➤ 3:24 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmployeeRating extends BaseEntity {
    @ManyToOne(targetEntity = Employee.class,cascade = {CascadeType.MERGE,CascadeType.REFRESH})
    private Employee employee;
    @OneToMany(targetEntity = Rating.class,cascade = CascadeType.ALL)
    @JoinColumn(name = "emp_rating_id",referencedColumnName = "id")
    private List<Rating> ratings;
    @Column(columnDefinition = "Text")
    private String feedBack;
    private Float avgRating;
    private Boolean isSubmitted;
}
