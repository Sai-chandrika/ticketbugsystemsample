package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  05/04/23
 * @Time >>  5:32 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TicketPriority {
    LOW,//1
    MEDIUM,//2
    HIGH,//3
    NONE//4
}