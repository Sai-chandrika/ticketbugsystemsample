package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Mamatha
 * @Date >>  25/05/23
 * @Time >>  2:42 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AppUserRequestDto {
    private String id;
    private String firstName;
    private String lastName;
    //private Role role;
    private String email;
    private String password;
    private String contact;
    private boolean isActive;
    private String fullName;
    private String roleId;
}
