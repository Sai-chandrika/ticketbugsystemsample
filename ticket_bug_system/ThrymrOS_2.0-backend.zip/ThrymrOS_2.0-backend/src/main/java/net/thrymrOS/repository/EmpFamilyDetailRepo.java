package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpChildren;
import net.thrymrOS.entity.corehr.EmpFamilyDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  25/02/23
 * @Time >>  3:25 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface EmpFamilyDetailRepo extends JpaRepository<EmpFamilyDetail, String> {
    Optional<EmpFamilyDetail> findByEmployeeId(String empId);
    List<EmpFamilyDetail>findAllByOrderByCreatedOnDesc();
    List<EmpChildren> findEmpChildrenListByEmployeeId(String id);
}
