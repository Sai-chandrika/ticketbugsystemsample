package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 02-06-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InterviewReasonHistoryDto {
    private String id;
    private String scheduleInterviewId;
    private String reason;
    private String createdBy;
    private Timestamp createdOn;
    private String createdOnTime;
    private String createdByImage;

}