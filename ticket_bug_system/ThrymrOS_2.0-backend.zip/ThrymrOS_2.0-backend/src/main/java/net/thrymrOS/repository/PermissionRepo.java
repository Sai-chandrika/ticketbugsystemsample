package net.thrymrOS.repository;

import net.thrymrOS.dto.PermissionDto;
import net.thrymrOS.entity.Permission;
import net.thrymrOS.enums.Screen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 19-05-2023
 */

@Repository
public interface PermissionRepo extends JpaRepository<Permission,String> {
    List<Permission> findAllByOrderByIsActiveDescScreenAsc();

    List<Permission> findByIdNotIn(List<String> list);

   // List<Permission> findByIdIn(List<String> list);

   // List<Permission> findAllByRoleTypeId(String id);
}