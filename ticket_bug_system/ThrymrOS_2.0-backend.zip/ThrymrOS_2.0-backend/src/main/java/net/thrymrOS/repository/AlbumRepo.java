package net.thrymrOS.repository;

import net.thrymrOS.entity.asset.AssetStatus;
import net.thrymrOS.entity.employee_engagement.Album;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  29/03/23
 * @Time >>  11:59 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface AlbumRepo extends JpaRepository<Album, String> {
    List<Album> findAllByIsActive(Boolean value);

    Optional<Album> findByNameIgnoreCase(String name);
}
