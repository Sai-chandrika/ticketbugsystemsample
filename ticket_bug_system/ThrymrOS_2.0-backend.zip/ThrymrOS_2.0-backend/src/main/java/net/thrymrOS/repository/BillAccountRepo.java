package net.thrymrOS.repository;

import net.thrymrOS.entity.finance.BillAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 01/08/23
 * @Time ➤➤➤ 2:16 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface BillAccountRepo  extends JpaRepository<BillAccount,String> {
    List<BillAccount> findByAccountCategoryEqualsIgnoreCase(String accountCategory);
}
