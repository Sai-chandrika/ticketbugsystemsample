package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Giridhar
 * @Date >>  14/04/23
 * @Time >>  03:33 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HolidayDto {
    private String id;
    private String name;
    private List<LocationDto> location=new ArrayList<>();
    private LocalDate fromDate;
    private LocalDate toDate;
    private boolean isActive;
    private String locationId;
}
