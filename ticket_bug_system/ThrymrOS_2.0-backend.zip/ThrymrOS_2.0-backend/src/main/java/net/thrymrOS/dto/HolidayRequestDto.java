package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Giridhar
 * @Date >>  14/04/23
 * @Time >>  03:33 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class HolidayRequestDto {
    private String id;
    private String name;
    private List<String> locationId;
    private LocalDate fromDate;
    private LocalDate toDate;
}