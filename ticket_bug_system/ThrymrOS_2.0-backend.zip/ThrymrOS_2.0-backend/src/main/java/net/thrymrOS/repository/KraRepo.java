package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.Kra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 12-06-2023
 */
@Repository
public interface KraRepo extends JpaRepository<Kra,String> {
    List<Kra> findAllByOrderByIsActiveDescNameAsc();

    List<Kra> findAllByIsActiveOrderByNameAsc(boolean b);
}