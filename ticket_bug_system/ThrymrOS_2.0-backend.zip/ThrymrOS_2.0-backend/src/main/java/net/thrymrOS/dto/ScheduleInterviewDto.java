package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.InterviewStatus;
import net.thrymrOS.enums.ModeOfInterview;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 17-05-2023
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class ScheduleInterviewDto {
    private String id;
    private String interviewRound;
    private InterviewTypeDto interviewType;
    private ModeOfInterview modeOfInterview;
    private InterviewStatus interviewStatus;
    private LocationDto location;
    private LocalDate interviewDate;
    private LocalTime interviewTime;
    private String duration;
    private CandidateDto candidate;
    private String description;
    private EmployeeDto contactPerson;
    private EmployeeDto interviewer;
    private  String reasonForReschedule;
    private String createdBy;
    private Timestamp createdOn;
    private String createdOnTime;
    private String createdByImage;
    private List<CandidateFeedBackDto> feedBackList;
    private List<InterviewReasonHistoryDto> historyList;

}

