package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.masterdata.dashboard.BankDetailDto;
import net.thrymrOS.enums.*;



/**
 * @Author >> Giridhar Kommu
 * @Date >> 24/06/23
 * @Time >> 10:55 am
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class VendorDto {
    private String id;
    private VendorType vendorType;
    private boolean isActive;
    private String companyName;
    private String vendorDisplayName;
    private LocationType locationType;
    private String vendorCode;
    private BusinessVerticalDto businessVertical;
    private Salutation salutation;
    private String firstName;
    private String lastName;
    private String vendorEmail;
    private String phoneNumber;
    private GstTreatment gstTreatment;
    private String pan;
    private CityDto placeOfSupply;
    private CurrencyDto currency;
    private Double openingBalance;
    private int paymentTerms;
    private TaxPreference taxPreference;
    private AddressDto billingAddress;
    private AddressDto shippingAddress;
    private BankDetailDto bankDetail;

    private String gstNumber;
    private String businessLegalName;

}
