package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.finance.Currency;
import net.thrymrOS.enums.CandidateType;
import net.thrymrOS.enums.NoticePeriod;
import net.thrymrOS.enums.Source;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  5:38 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CandidateDetailDto {
    @NotNull(message = "Date of contact can't be Null/Empty")
    private LocalDate dateOfContact;
    @NotNull(message = "source can't be Null/Empty")
    private Source source;
    @NotBlank(message = "Email can't be Null/Empty")
    private String emailId;
    @NotBlank(message = "Phone Number can't be Null/Empty")
    private String phoneNumber;
    private String linkedId;
    @NotBlank(message = "Current Location can't be Null/Empty")
    private String currentLocation;
    @NotBlank(message = "Native Location can't be Null/Empty")
    private String nativeLocation;
    @NotBlank(message = "Preferred Location  can't be Null/Empty")
    private String preferredLocationId;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;

}
