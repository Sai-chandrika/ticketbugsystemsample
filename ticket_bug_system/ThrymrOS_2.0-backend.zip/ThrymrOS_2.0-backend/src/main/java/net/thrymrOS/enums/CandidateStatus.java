package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  9:32 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum CandidateStatus {
    NEW,//0
    IN_PROGRESS,//1
    HOLD,//2
    SELECTED,//4
    BGV_PROCESS,// 5
    OFFERED,// 6
    OFFERED_DECLINED, //7
    JOINED, // 8
    REJECTED,//9
}
