package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 05-07-2023
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MomMeetingDto {
    private String text;
    private String meetingId;
    private String interactionId;
}