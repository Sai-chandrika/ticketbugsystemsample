package net.thrymrOS.custom_exception;

/**
 * @Author >> Swetha
 * @Date >>  24/02/23
 * @Time >>  12:44 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public class DuplicateNameException extends RuntimeException{
    public DuplicateNameException(String message){
        super(message);
    }
}
