package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  24/02/23
 * @Time >>  3:56 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum BloodGroup {
    A_POSITIVE,//1
    B_POSITIVE,//2
    O_POSITIVE,//3
    AB_POSITIVE,//4
    A_NEGATIVE,//5
    B_NEGATIVE,//6
    O_NEGATIVE,//7
    AB_NEGATIVE //8

}
