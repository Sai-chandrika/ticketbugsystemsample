package net.thrymrOS.repository;

import net.thrymrOS.entity.MultiLeaveOption;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  24/08/23
 * @Time >>  4:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public interface LeaveMultiSaveRepo extends JpaRepository<MultiLeaveOption,String> {
}
