package net.thrymrOS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import net.thrymrOS.entity.md.Country;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Repository
public interface CountryRepo extends JpaRepository<Country,String> {
    //List<Country> findAllByOrderByIdAsc();
    Country findByStatesCitiesId(String cityId);
    List<Country> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<Country> findByNameEqualsIgnoreCase(String countryName);

    List<Country> findAllByOrderByIsActiveDescNameAsc();
    List<Country>  findAllByIsActiveEquals(Boolean value);

    List<Country> findAllByIsActiveOrderByNameAsc(Boolean aTrue);

}
