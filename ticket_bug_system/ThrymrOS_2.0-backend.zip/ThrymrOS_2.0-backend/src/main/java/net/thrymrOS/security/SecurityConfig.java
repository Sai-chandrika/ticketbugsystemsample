package net.thrymrOS.security;

import net.thrymrOS.repository.SessionTimeRepo;
import net.thrymrOS.security.security_service.JwtToken;
import net.thrymrOS.service.implementation.AppUserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;



@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

//    @Autowired
//    private AppUserRepo repository;
    @Autowired
    private JwtToken token;
    @Autowired
    private AppUserServiceImpl userService;

    @Autowired
    SessionTimeRepo sessionTimeRepo;

    @Value("${session.time}")
    private Integer sessionTime;


    private final String[] PUBLIC_RESOURCE_AND_URL = {"/",
            "/thrymr-os/api/app-user/login",
            "/thrymr-os/api/app-user/logout",
            "/thrymr-os/api/file-upload/get/{fileId}",
            "/thrymr-os/api/app-user/first-login",
            "/thrymr-os/api/ops/attendance/automatic-checkout",
            "/thrymr-os/api/app-user/get/first-login/false/{id}",
            "/thrymr-os/api/core-hr/emp-image/download/{imageId}",
            "/thrymr-os/api/file-upload/save",
            "/thrymr-os/api/file-upload/get/{fileId}",
            "/thrymr-os/api/file-upload/delete-by-file-id/{fileId}",
            "/thrymr-os/api/file-upload/view-file/{fileId}"
            , "/v2/api-docs"
            , "/configuration/ui"
            , "/swagger-resources"
            , "/configuration/security"
            , "/swagger-ui.html"
            , "/webjars/**"
            , "/thrymr-os/api/pm/project-task/excel/{id}"
            , "/swagger-resources/configuration/ui"
            , "/swagger-resources/configuration/security"
    };

    @Bean
    public SecurityFilterChain configure(HttpSecurity http) throws Exception {
        http.csrf()
                .disable()
                .authorizeHttpRequests()
                .anyRequest()
                .authenticated()
                .and()
                .exceptionHandling()
                .accessDeniedHandler(accessDeniedHandler())
                .and()
                .addFilterBefore(new JwtAuthenticationFilter(token, userService,sessionTime,sessionTimeRepo), BasicAuthenticationFilter.class).
                addFilterBefore(new CustomCORSFilter(), ChannelProcessingFilter.class);
        return http.build();
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.debug(true)
                .ignoring()
                .antMatchers(PUBLIC_RESOURCE_AND_URL);
    }

    @Bean
    public AccessDeniedHandler accessDeniedHandler() {
        return new CustomAccessDeniedHandler();
    }

}
