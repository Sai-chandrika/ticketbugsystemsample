package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;


/**
 * @Author >> Mamatha
 * @Date >>  20/02/23
 * @Time >>  11:34 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LeadDto {
    private String id;
    private String sequenceNo;
    @NotNull(message = "lead name can't be null!!")
    private String name;
    private String createdBy;
    private String createdByImage;
    private String description;
    private LeadStatusDto status;
    private LeadSourceTypeDto sourceType;
    private String source;
    private boolean isActive;
    private ChannelDto channelDto;
    private AccountDto accountDto;
    private EmployeeDto assignedTo;
    private Set<ContactDto> contactDto;
}
