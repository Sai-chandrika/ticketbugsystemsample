package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  04/03/23
 * @Time >>  9:50 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ClientRepo extends JpaRepository<Client, String> {
    List<Client> findAllByOrderByIsActiveDescCreatedOnDesc();
//    Optional<Client> findByNameEqualsIgnoreCase(String name);
    Optional<Client> findByClientCode(String clientCode);
    List<Client> findAllByIsActive(boolean b);

    List<Client> findAllByIsActiveOrderByFirstNameAsc(boolean b);

    Optional<Client> findByEmail(String email);
}
