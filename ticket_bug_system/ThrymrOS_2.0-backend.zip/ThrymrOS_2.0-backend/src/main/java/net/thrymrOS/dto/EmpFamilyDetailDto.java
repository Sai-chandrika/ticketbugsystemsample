package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


/**
 * @Author >> Swetha
 * @Date >>  25/02/23
 * @Time >>  2:48 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmpFamilyDetailDto {
    private String id;
    private String fatherName;
    private String motherName;
    private String spouse;
    private List<EmpChildrenDto> childrenDtoList;
    private EmployeeDto employeeDto;
}
