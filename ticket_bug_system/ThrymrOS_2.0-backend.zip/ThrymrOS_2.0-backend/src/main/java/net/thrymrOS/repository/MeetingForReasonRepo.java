package net.thrymrOS.repository;

import net.thrymrOS.entity.appraisals.MeetingReasonHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 06-07-2023
 */
@Repository
public interface MeetingForReasonRepo extends JpaRepository<MeetingReasonHistory, String> {
}