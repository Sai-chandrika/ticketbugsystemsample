package net.thrymrOS.repository;

import net.thrymrOS.entity.ops.DSR;
import net.thrymrOS.enums.DSRStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  5:46 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface DSRRepo extends JpaRepository<DSR,String> {
    List<DSR> findBySubmittedById(String submittedById);
    DSR findByForDate(Date forDate);
   // DSR findBYForDateAndDsrStatus(Date current, DSRStatus dsrStatus);
    DSR findBySubmittedByIdAndForDate(String submittedById, LocalDate forDate);
    DSR findByDSROfIdAndForDate(String empId, LocalDate forDate);

    List<DSR> findAllBySubmittedById(String id);;
}
