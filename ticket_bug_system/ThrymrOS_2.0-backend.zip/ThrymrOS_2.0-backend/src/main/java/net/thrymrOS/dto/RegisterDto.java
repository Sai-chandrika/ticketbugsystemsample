package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Giridhar
 * @Date >>  20/04/23
 * @Time >>  2:38 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterDto {
    private String id;
    private LocalDate forDate;
    private EmployeeDto employeeDto;
    private String checkIn;
    private String checkOut;
    private String workingHours;
    private boolean isActive;
}
