package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import net.thrymrOS.enums.TeamRole;

import java.util.List;
import java.util.Map;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 19/05/23
 * @Time ➤➤➤ 12:07 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CountOfProjectDto {
    private String projectName;
    private Long totalMembers;
    private CountOfRole roleCount;

}
