package net.thrymrOS.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TaskStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  20/04/23
 * @Time >>  12:06 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MilestoneDto {
    private String id;
    private String name;
    private String mileStoneCode;
    private LocalDate forDate;
    private LocalDate startDate;
    private LocalDate targetDate;
    private LocalDate actualCloseDate;
    private ProjectDto project;
    private TaskStatus status;
    private List<TaskDto> task=new ArrayList<>();
    private EmployeeDto assignedTo;
    private boolean isActive;
}
