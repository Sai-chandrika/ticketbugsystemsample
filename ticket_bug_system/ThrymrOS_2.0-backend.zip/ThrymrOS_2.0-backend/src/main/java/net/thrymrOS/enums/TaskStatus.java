package net.thrymrOS.enums;


/**
 * @Author >> Giridhar
 * @Date >>  06/03/23
 * @Time >>  02:25 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TaskStatus {
    DRAFT,
    NEW,
    COMPLETED,
    ON_HOLD,
    IN_PROGRESS;
}
