package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  15/03/23
 * @Time >>  4:52 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum DSRStatus {
    DRAFT,
    SUBMITTED,
}
