package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.recruitment.InterviewType;
import net.thrymrOS.enums.InterviewStatus;
import net.thrymrOS.enums.ModeOfInterview;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 18-05-2023
 */
@NoArgsConstructor
@Data
@AllArgsConstructor
public class ScheduleInterviewRequestDto {
    private String id;
    @NotBlank(message = "Interview Round  can't be Null/Empty")
    private String interviewRound;
    @NotBlank(message = "Interview Type id can't be Null/Empty")
    private String interviewType;
    @NotNull(message = "Mode Of Interview Date can't be Null/Empty")
    private ModeOfInterview modeOfInterview;
    @NotNull(message = "Interview Date  can't be Null/Empty")
    private LocalDate interviewDate;
    @NotBlank(message = "Interview Time  can't be Null/Empty")
    private String interviewTime;
    @NotBlank(message = "Duration can't be Null/Empty")
    private String duration;
    @NotBlank(message = "Description  can't be Null/Empty")
    private String description;
    @NotBlank(message = "Location id can't be Null/Empty")
    private String locationId;
    @NotBlank(message = "Contact Person id can't be Null/Empty")
    private String contactPersonId;
    @NotBlank(message = "Interviewer id can't be Null/Empty")
    private String interviewerId;
    private  String reasonForReschedule;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;


}