package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.entity.md.OrganizationUnit;
import net.thrymrOS.entity.md.finance.Currency;
import net.thrymrOS.entity.md.md_corehr.Location;
import net.thrymrOS.entity.pm.Client;
import net.thrymrOS.enums.PositionStatus;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  23/03/23
 * @Time >>  10:09 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Position extends BaseEntity {
    private String name;
    private int positionCount;
    private String positionCode;
    private LocalDate createdDate;
    private LocalDate kickOffDate;
    private LocalDate closureDate;
    private PositionStatus positionStatus;
    @ManyToOne(targetEntity = OrganizationUnit.class, cascade = {CascadeType.MERGE })
    private OrganizationUnit organizationUnit;
    @ManyToOne(targetEntity = Client.class, cascade = {CascadeType.MERGE })
    private Client client;
    @ManyToOne(targetEntity = Location.class, cascade = {CascadeType.MERGE })
    private Location location;
    @ManyToOne(targetEntity = Employee.class, cascade = {CascadeType.MERGE })
    private Employee hiringManager;
    @ManyToMany(targetEntity = Employee.class, cascade = {CascadeType.MERGE })
    private List<Employee> recruiterList = new ArrayList<Employee>();
    private Integer minExperience;
    private Integer maxExperience;
    @ManyToOne(targetEntity = Currency.class, cascade = {CascadeType.MERGE })
    private Currency currency;
    private Long budget;
    @Column(columnDefinition = "TEXT")
    private String jobDescription;
    @ElementCollection
    private List<String> referenceDocument = new ArrayList<String>();
    @Column(columnDefinition = "TEXT")
    private String reason;

}
