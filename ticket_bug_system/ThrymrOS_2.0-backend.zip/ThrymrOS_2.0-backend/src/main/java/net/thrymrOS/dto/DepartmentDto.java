package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * @Author >> Dasta
 * @Date >>  20/02/23
 * @Time >>  11:17 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class DepartmentDto {
    private String id;
    @NotNull(message = "department name can't be null!!")
    private String name;
    private boolean isActive;
    private Integer sequenceNo;

}
