package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TaskStatus;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  04/05/23
 * @Time >>  1:56 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
public class UpdateStatusDto {
    private String id;
    private TaskStatus status;
}
