package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TaskPriorityType;
import net.thrymrOS.enums.TaskSeverityType;
import net.thrymrOS.enums.TaskStatus;
import net.thrymrOS.enums.TaskType;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


/**
 * @Author >> Giridhar
 * @Date >>  06/03/23
 * @Time >>  04:45 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class TaskDto {
    private String id;
    private String task;
    private String description;
    private String pTaskCode;
    private TaskPriorityType priority;
    private TaskSeverityType severity;
    private TaskStatus status;
    private TaskType taskType;
    private LocalDate startDate;
    private LocalDate estimateDate;
    private LocalDate createdDate;
    private LocalDate assignDate;
    private Timestamp createdOn;
    private LocalDate actualCloserDate;
    private int plannedEfforts;
    private int actualEfforts;
    private boolean isComplete;
    private boolean isActive;
    private boolean isParent;
    private ProjectDto project;
    private EmployeeDto createBy;
    private EmployeeDto assignedTo;
    private MilestoneDto milestoneDto;
    private TaskDto parentTask;
    private List<FileUploadDto> fileUploadDtos;
    private List<TaskDto> subTask = new ArrayList<TaskDto>();
    private long noOfSubTasks;

}
