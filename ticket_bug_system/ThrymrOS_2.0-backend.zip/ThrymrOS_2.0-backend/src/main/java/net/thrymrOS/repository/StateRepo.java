package net.thrymrOS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import net.thrymrOS.entity.md.State;

import java.util.List;
import java.util.Optional;


@Repository
public interface StateRepo extends JpaRepository<State,String> {

    Optional<State> findByNameAndCountryId(String stateName, String countryName);

    List<State> findAllByIsActiveEquals(Boolean value);
    List<State> findByCountryIdAndIsActiveIsTrue(String countryId);
    List<State> findAllByOrderByIsActiveDescNameAsc();

    List<State> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}
