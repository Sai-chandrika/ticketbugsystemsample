package net.thrymrOS.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import net.thrymrOS.entity.md.Department;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DepartmentRepo extends JpaRepository<Department, String> {
    //List<Department> findAllByOrderByIdAsc();
    List<Department> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<Department> findByNameEqualsIgnoreCase(String department);

    List<Department> findAllByOrderByIsActiveDescNameAsc();


    List<Department> findAllByUpdatedOnIsNotNull();

    List<Department> findAllByUpdatedOnIsNull();

    List<Department> findAllByOrderByIsActiveDescUpdatedOnDesc();

    List<Department> findAllByIsActiveEquals(Boolean aTrue);
    List<Department> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}