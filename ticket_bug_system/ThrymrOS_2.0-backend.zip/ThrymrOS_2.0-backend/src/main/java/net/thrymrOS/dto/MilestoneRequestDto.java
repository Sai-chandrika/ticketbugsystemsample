package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  20/04/23
 * @Time >>  12:07 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class MilestoneRequestDto {
    private String id;
    private String projectId;
    private String name;
    private LocalDate startDate;
    private LocalDate targetDate;
    private LocalDate actualCloseDate;
    private boolean isActive;

}
