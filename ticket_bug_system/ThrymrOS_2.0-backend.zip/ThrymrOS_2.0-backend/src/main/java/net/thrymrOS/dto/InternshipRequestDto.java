package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  06/05/23
 * @Time >>  9:22 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data

public class InternshipRequestDto {

    private String id;
    @NotBlank(message = "Employer can't be Null/Empty")
    private String employer;
    @NotBlank(message = "Position can't be Null/Empty")
    private String position;
    @NotBlank(message = "Location id can't be Null/Empty")
    private String location;
    @NotNull(message = "Form Year can't be Null/Empty")
    private LocalDate fromYear;
    @NotNull(message = "To Year can't be Null/Empty")
    private LocalDate toYear;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;
}
