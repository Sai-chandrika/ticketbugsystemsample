package net.thrymrOS.repository;

import net.thrymrOS.entity.asset.AssetTransactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  31/03/23
 * @Time >>  2:11 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface AssetTransactionTypeRepo extends JpaRepository<AssetTransactionType,String> {
    List<AssetTransactionType> findAllByOrderByCreatedOnDesc();

    Optional<AssetTransactionType> findByNameIgnoreCase(String name);

    List<AssetTransactionType> findAllByOrderByIsActiveDescNameAsc();

    List<AssetTransactionType> findAllByIsActiveOrderByNameAsc(boolean b);
}
