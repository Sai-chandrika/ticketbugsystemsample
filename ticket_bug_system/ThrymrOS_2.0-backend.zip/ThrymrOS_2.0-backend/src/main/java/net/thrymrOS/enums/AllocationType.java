package net.thrymrOS.enums;

/**
 * @Author >> Giridhar
 * @Date >>  14/03/23
 * @Time >>  5:51 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum AllocationType {
    FULL,       //0
    HALF,       //1
    QUARTER,    //2
    SUPPORT,    //3
    NA          //4
}
