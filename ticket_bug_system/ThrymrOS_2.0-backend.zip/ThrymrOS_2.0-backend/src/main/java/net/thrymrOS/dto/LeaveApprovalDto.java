package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.LeaveStatus;


/**
 * @Author >> Swetha
 * @Date >>  11/04/23
 * @Time >>  2:39 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)

public class LeaveApprovalDto {
    private LeaveStatus status;
    private String approvedBy;
    private String approvedById;
    private String leave;
    private String comment;
}
