package net.thrymrOS.repository;

import net.thrymrOS.entity.finance.Tax;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 01/08/23
 * @Time ➤➤➤ 4:49 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface TaxRepo extends JpaRepository<Tax,String> {
    Optional<Tax> findByTaxIgnoreCase(String tax);
}
