package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 01-08-2023
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TaskCountDto {
    private long totalTask;
    private long assignedCount;
    private long unAssignedCount;

}