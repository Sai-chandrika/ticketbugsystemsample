package net.thrymrOS.repository;

import net.thrymrOS.entity.md.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  09/03/23
 * @Time >>  11:40 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface CategoryRepo extends JpaRepository<Category,String> {
    boolean existsByNameIgnoreCase(String name);
    List<Category> findAllByOrderByIsActiveDescCreatedOnDesc();
    List<Category>findAllByIsActiveOrderByNameAsc(boolean b);

    Optional<Category> findByNameIgnoreCase(String s);

    List<Category> findAllByOrderByIsActiveDescNameAsc();
}
