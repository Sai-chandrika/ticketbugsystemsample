package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  4:14 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum CandidateType {
    FRESHER, //0
    EXPERIENCED, //1
}
