package net.thrymrOS.repository;

import net.thrymrOS.entity.RequestUseCase;
import net.thrymrOS.entity.md.ticketing_system.RequestPurpose;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  28/04/23
 * @Time >>  2:18 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface RequestPurposeRepo extends JpaRepository<RequestPurpose, String> {
    Optional<RequestPurpose> findByNameEqualsIgnoreCase(String name);

    List<RequestUseCase> findAllByIdIn(List<String> useCaseListIds);

    List<RequestPurpose> findByOrderByIsActiveDescCreatedOnDesc();

    List<RequestPurpose> findAllByIsActiveTrue();

    List<RequestPurpose> findByOrderByIsActiveDescNameAsc();
}
