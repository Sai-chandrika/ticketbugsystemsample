package net.thrymrOS.repository;

import net.thrymrOS.entity.learnignAndDevelopmet.Session;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  05/08/23
 * @Time >>  12:11 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface SessionRepo extends JpaRepository<Session, String> {
    List<Session> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<Session> findAllByIsActiveTrueOrderByCreatedOnDesc();

    List<Session> findAllByTargetAudienceIdOrderByCreatedOnDescIsActiveDesc(String employeeId);

    List<Session> findAllByTrainedByOrderByCreatedOnDescIsActiveDesc(String employeeId);

    List<Session> findAllByLocationIdOrderByCreatedOnDescIsActiveDesc(String locationId);

}
