package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  21/07/23
 * @Time >>  5:42 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TaxType {
    TDS,// 0
    TCS, //1
}
