package net.thrymrOS.repository;

import net.thrymrOS.entity.Comment;
import net.thrymrOS.enums.CommentOf;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface CommentRepo extends JpaRepository<Comment, String> {
    List<Comment> findAllByOrderByIdDesc();
    List<Comment> findAllByCommentOfIdEqualsOrderByCreatedOnDesc(String id);
    List<Comment> findAllByCommentOfOrderByCreatedOnDesc(CommentOf commentOf);
    List<Comment> findAllByCommentOfAndCommentedOnOrderByCreatedOnDesc(CommentOf commentOf, Timestamp timestamp);

    List<Comment> findAllByCommentOfIdOrderByCreatedOnDesc(String id);
}
