package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  25/02/23
 * @Time >>  1:45 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum Gender {
    MALE,
    FEMALE,
    OTHERS;
}
