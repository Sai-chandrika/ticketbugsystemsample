package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TimeSheetStatus;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  18/04/23
 * @Time >>  6:05 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TimeSheetResponseDto {
    private ProjectDto projectDto;
    private String id;
    private String workingHours;
    private String workingMinutes;
    private LocalDate forDate;
    private TimeSheetStatus timeSheetStatus;
    private EmployeeDto employeeDto;

}
