package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 04-09-2023
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EmojiDto {
    private String id;
    private String emojiId;
}
