package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  15/05/23
 * @Time >>  2:20 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TimeSheetStatus {
    PENDING , // 0
    SUBMITTED, //1
    APPROVED, //2
    DIS_APPROVED, //3
}
