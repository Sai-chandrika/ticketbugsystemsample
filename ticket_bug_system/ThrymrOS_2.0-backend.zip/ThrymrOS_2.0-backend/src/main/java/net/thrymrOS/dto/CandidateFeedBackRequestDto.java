package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  20/05/23
 * @Time >>  10:37 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CandidateFeedBackRequestDto {
    private String id;
    @NotBlank(message = "FeedBack can't be Null/Empty")
    private String feedBack;
    private List<String> uploadFiles=new ArrayList<String>();
    @NotBlank(message = "Schedule Interview id can't be Null/Empty")
    private String scheduleInterviewId;

}
