package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  23/02/23
 * @Time >>  10:56 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContactRequestDto {
    private String id;
    @NotBlank(message = "Contact name can't be null!!")
    private String name;
    @NotBlank(message = "Email can't be null!!")
    @Email(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "Invalid email...")
    private String email;
    @Email(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", message = "Invalid email...")
    private String alternativeEmail;
    @NotBlank(message = "Phone Number can't be null!!")
    private String phoneNumber;
    private String alternativePhoneNumber1;
    private String alternativePhoneNumber2;
    private String notes;
    private String monthOfBirth;
    private String activeAccount;
    @NotBlank(message = "Account can't be null!!")
    private String accountId;
    @NotBlank(message = "City can't be null!!")
    private String cityId;
    private boolean isActive;
}
