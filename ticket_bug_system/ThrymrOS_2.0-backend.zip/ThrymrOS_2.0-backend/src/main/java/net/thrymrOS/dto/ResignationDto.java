package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  11/04/23
 * @Time >>  2:14 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ResignationDto {
    private String id;
    private EmployeeDto employee;
    private String reasonForLeaving;
    private LocalDate dateOfResignation;
    private LocalDate dateOfExit;
    private LocalDate dateOfRelieving;
    private LocalDate dateOfSettlement;
}
