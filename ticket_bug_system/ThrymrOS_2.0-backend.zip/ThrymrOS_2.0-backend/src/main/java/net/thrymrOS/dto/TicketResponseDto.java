package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.enums.TicketPriority;
import net.thrymrOS.enums.TicketStatus;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  28/04/23
 * @Time >>  2:09 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TicketResponseDto  {
    private String id;
    private String ticketName;

    private String description;
    private String descriptionForRequest;
    private TicketPriority priority;
    private LocalDate dueDate;
    private String ticketNumber;
    private RequestPurposeResponseDto requestPurpose;
    private TicketStatus status;
    private LocationDto location;
    private String response;
    private String reason;
    private EmployeeDto raisedBy;
    private LocalDate raisedOn;
    private List<EmployeeDto> assignTo = new ArrayList<EmployeeDto>();
    private EmployeeDto requestPermissionTo;
    private List<FileUploadDto> fileIds = new ArrayList<FileUploadDto>();
    private AppUserDto createdBy;
    private Timestamp createdOn;
    private LocalDateTime updatedOn;
    private Boolean isActive;
}
