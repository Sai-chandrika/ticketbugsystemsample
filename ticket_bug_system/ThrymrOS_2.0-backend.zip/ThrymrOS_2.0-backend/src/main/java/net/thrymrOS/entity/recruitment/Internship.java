package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.md.md_corehr.Location;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  4:43 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Internship extends BaseEntity {
    @ManyToOne(targetEntity = Candidate.class, cascade = {CascadeType.MERGE})
    private Candidate candidate;
    private String employer;
    private String position;
    private String location;
    private LocalDate fromYear;
    private LocalDate toYear;
}
