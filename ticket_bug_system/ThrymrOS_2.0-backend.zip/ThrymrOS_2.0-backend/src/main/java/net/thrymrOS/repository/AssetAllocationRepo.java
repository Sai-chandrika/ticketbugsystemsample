package net.thrymrOS.repository;

import net.thrymrOS.entity.asset.AssetAllocation;
import net.thrymrOS.entity.asset.AssetTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  01/04/23
 * @Time >>  11:32 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public interface AssetAllocationRepo extends JpaRepository<AssetAllocation, String> {

    List<AssetAllocation> findAllByTransactionDateBetween(LocalDate startDate, LocalDate endDate);

    List<AssetAllocation> findAllByTransactionTypeNameAndEmployeeLocationNameAndAssetAssetTypeAssetCategoryNameAndTransactionDateBetween(String type, String location, String categoryName, LocalDate startDate, LocalDate endDate);

    List<AssetAllocation> findByEmployeeId(String employeeId);

    List<AssetAllocation> findAllByOrderByIsActiveDescAssetAssetCodeNumberAsc();

    List<AssetAllocation> findAllByAssetId(String id);

    List<AssetAllocation> findAllByAssetIdAndTransactionTypeRemoveFromListFalse(String id);

    List<AssetAllocation> findAllByTransactionTypeId(String id);

    List<AssetAllocation> findAllByTransactionTypeRemoveFromListTrue();




   /*     List<AssetAllocation> findAllByTransactionTypeNameAndEmployeeLocationNameAndTransactionDateBetween(String type, String location, LocalDate startDate, LocalDate endDate);
    List<AssetAllocation> findAllByTransactionTypeNameAndEmployeeLocationNameAndAssetAndTransactionDateBetween(String type, String location, LocalDate startDate, LocalDate endDate);
        List<AssetAllocation> findAllByOrderByIsActiveDescTransactionDateAsc();
      Optional<AssetAllocation> findAllByAssetId(String assetId);
    List<AssetAllocation> findAllByAssetId(String assetId);
    List<AssetAllocation> findAllByTransactionTypeNameAndTransactionDateBetween(String type, LocalDate startDate, LocalDate endDate);*/
}
