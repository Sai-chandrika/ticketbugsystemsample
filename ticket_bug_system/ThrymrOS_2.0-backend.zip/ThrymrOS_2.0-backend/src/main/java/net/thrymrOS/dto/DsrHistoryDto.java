package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/08/23
 * @Time ➤➤➤ 11:52 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DsrHistoryDto {
    private LocalDate forDate;
    private String totalEfforts;
    List<DsrTaskHistoryDto> dsrHistory;
}
