package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.entity.md.md_corehr.Location;
import net.thrymrOS.entity.md.recruitment.InterviewType;
import net.thrymrOS.enums.InterviewStatus;
import net.thrymrOS.enums.ModeOfInterview;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 17-05-2023
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class ScheduleInterview extends BaseEntity {
    private String interviewRound;
    @ManyToOne(targetEntity = InterviewType.class, cascade = {CascadeType.MERGE })
    private InterviewType interviewType;
    private ModeOfInterview modeOfInterview;
    private InterviewStatus interviewStatus;
    @ManyToOne(targetEntity = Location.class, cascade = {CascadeType.MERGE })
    private Location location;
    private LocalDate interviewDate;
    private LocalTime interviewTime;
    private String duration;
    @ManyToOne(targetEntity = Candidate.class, cascade = {CascadeType.MERGE })
    private Candidate candidate;
    @Column(columnDefinition = "TEXT")
    private String description;
    @ManyToOne(targetEntity = Employee.class, cascade = {CascadeType.MERGE })
    private Employee contactPerson;
    @ManyToOne(targetEntity = Employee.class, cascade = {CascadeType.MERGE })
    private Employee interviewer;
    private  String reasonForReschedule;

}