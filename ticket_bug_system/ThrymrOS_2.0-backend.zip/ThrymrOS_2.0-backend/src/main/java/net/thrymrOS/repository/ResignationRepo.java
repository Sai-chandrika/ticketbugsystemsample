package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.Resignation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  11/04/23
 * @Time >>  2:28 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ResignationRepo extends JpaRepository<Resignation,String> {
    List<Resignation> findAllByDateOfResignationBetween(LocalDate startDate , LocalDate endDate);
    List<Resignation>findAllByOrderByDateOfResignationDesc();
    Optional<Resignation> findAllByEmployeeId(String empId);

    List<Resignation> findAllByOrderByDateOfExitDesc();
    List<Resignation> findAllByOrderByCreatedOnDesc();

}
