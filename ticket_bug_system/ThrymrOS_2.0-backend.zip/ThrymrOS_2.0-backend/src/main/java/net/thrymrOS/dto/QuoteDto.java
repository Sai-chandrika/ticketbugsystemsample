package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.thrymrOS.entity.md.md_corehr.Emoji;

import java.sql.Timestamp;
import java.time.LocalDateTime;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 29-08-2023*/


@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class QuoteDto {
    private String id;
    private String quote;
    private String emojiId;
    private EmojiDto existedEmojiId;
    private Timestamp createdOn;
    private LocalDateTime updateOn;
}
