package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.md.finance.Currency;
import net.thrymrOS.enums.NoticePeriod;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  11:17 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class CandidateExperience extends BaseEntity {
    @OneToOne(targetEntity = Candidate.class,  cascade = {CascadeType.MERGE })
    private Candidate candidate;
    private String employer;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String role;
    private String lastWorkingDay;
    private String noticePeriod;
    private NoticePeriod noticePeriodTime;

   }
