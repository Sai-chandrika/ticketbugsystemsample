package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CandidateStatus;

import java.sql.Timestamp;



/**
 * @Author >> Mamatha
 * @Date >>  27/05/23
 * @Time >>  5:24 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateStatusChangeDto {
    private String id;
    private CandidateDto candidate;
    private CandidateStatus oldStatus;
    private CandidateStatus newStatus;
    private String reason;
    private String createdBy;
    private Timestamp createdOn;
    private String createdOnTime;
    private String createdByImage;
}
