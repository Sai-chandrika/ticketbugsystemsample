package net.thrymrOS.dto.masterdata.dashboard;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.CityDto;
import net.thrymrOS.dto.CountryDto;
import net.thrymrOS.dto.StateDto;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 23/06/23
 * @Time ➤➤➤ 11:28 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class BankDetailDto {
    private String id;
    private String bankName;
    private String beneficiaryName;
    private String bankAccountNumber;
    private String bankSwiftCode;
    private String bankBranchAddress;
    private String ifsc;
    private String iec;
    private String pan;
    private String zipCode;
    private String description;
    private boolean isActive;
    private  boolean isDefault;
    private CityDto city;
    private StateDto state;
    private CountryDto country;

}
