package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.LeaveStatus;

/**
 * @Author >> Swetha
 * @Date >>  11/04/23
 * @Time >>  12:35 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@NoArgsConstructor
public class LeaveApproveRequest {
    private String leaveId;
    private String commentId;
    private LeaveStatus status;
}
