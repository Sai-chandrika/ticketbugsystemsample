package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.ProjectStatus;
import net.thrymrOS.enums.ProjectType;

/**
 * @Author >> Swetha
 * @Date >>  09/03/23
 * @Time >>  12:49 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ActiveProjectDto {
    private String id;
    private String name;
    private String projectCode;
    private ProjectType projectType;
    private String managerId;
    private String managerName;
    private String leadId;
    private String leadName;
    private String clientId;
    private String clientName;
    private ProjectStatus status;
    private Integer teamSize;

}
