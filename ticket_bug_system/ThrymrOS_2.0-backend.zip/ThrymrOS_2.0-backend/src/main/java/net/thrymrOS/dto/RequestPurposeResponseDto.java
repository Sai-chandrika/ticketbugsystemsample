package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.dto.masterdata.dashboard.RequestUseCaseDto;
import net.thrymrOS.entity.md.Department;

import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 08/06/23
 * @Time ➤➤➤ 11:16 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class RequestPurposeResponseDto {
    private String id;
    private String name;
    private DepartmentDto departmentDto;
    private List<RequestUseCaseDto> useCaseList;
    private Boolean isActive;


}
