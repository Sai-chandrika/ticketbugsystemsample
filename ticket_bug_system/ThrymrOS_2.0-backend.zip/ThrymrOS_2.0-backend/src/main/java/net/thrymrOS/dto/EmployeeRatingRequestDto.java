package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/07/23
 * @Time ➤➤➤ 3:28 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmployeeRatingRequestDto {
    private String id;
    private String employeeId;
    private List<RatingDto> ratings;
    private String feedBack;
    private Float avgRating;
}
