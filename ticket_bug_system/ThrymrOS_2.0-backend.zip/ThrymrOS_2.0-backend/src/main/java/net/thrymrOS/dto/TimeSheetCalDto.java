package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TimeSheetStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  26/04/23
 * @Time >>  4:23 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class TimeSheetCalDto {
    private EmployeeDto employeeDto;
    private ProjectDto project;
    private TimeSheetStatus sheetStatus;
    private List<CalculationDto> calDtoList=new ArrayList<>();
    private double total;
    private String totalHours;
}
