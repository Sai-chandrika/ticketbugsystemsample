package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 02/08/23
 * @Time ➤➤➤ 2:39 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum PaymentType {
    PARTIAL,FULL_AMOUNT
}

