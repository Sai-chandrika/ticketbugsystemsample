package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 10/07/23
 * @Time ➤➤➤ 3:09 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CountOfInvoice {
    private Long totalInvoice;
    private Long planned;
    private Long received;
    private Long raised;
    private Long due;
    private CurrencyDto currencyDto;
    private Long totalAmount;
}
