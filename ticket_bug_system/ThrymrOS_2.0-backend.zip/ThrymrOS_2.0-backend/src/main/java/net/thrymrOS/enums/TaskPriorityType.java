package net.thrymrOS.enums;
/**
 * @Author >> Giridhar
 * @Date >>  06/03/23
 * @Time >>  02:29 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum TaskPriorityType {
    P0,
    P1,
    P2,
    P3,
    P4;
}
