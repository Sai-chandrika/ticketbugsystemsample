package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  14/03/23
 * @Time >>  5:58 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MonthlyAppraisalDto {
    private String id;
    private EmployeeDto employeeDto;
    private LocalDate fromDate;
    private LocalDate toDate;
    private boolean isActive;
}
