package net.thrymrOS.enums;

/**
 * @Author >> Swetha
 * @Date >>  03/03/23
 * @Time >>  2:10 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum ProjectStatus {
    NEW,//0
    INPROGRESS,//1
    HOLD,//2
    SUPPORT,//3
    CLOSED//4

}
