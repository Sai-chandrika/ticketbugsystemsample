package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  31/07/23
 * @Time >>  11:42 am
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum PaymentTerms {
    NET_1, //0
    NET_5, //1
    NET_10, //2
    NET_15, //3
    NET_20, //4
    NET_30, //5
}
