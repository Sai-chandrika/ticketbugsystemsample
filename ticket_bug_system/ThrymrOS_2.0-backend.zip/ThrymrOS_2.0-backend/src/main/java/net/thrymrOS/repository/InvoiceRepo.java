package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Invoice;
import net.thrymrOS.enums.InvoiceStatus;
import net.thrymrOS.enums.InvoiceType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  23/06/23
 * @Time >>  12:29 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface InvoiceRepo extends JpaRepository<Invoice,String> {
    List<Invoice> findByProjectId(String projectId);
    List<Invoice> findByProjectIdOrderBySaveAsDraftAscCreatedOnDesc(String projectId);
    List<Invoice> findByProjectIdOrderByIsCancelAscCreatedOnDesc(String projectId);
    List<Invoice> findByProjectIdAndSaveAsDraft(String projectId,Boolean draft);
    Optional<Invoice> findByMilestoneListId(String milestoneId);

    Optional<Invoice> findByInvoiceNumber(String invoiceNumber);

    List<Invoice> findByInvoiceTypeAndProjectId(InvoiceType invoiceType,String projectId);

    List<Invoice> findByInvoiceStatusAndProjectId(InvoiceStatus status,String projectId);

    List<Invoice> findByInvoiceStatus(InvoiceStatus invoiceStatus);
}
