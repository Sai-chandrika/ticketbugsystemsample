package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.corehr.ExpertiseLevel;
import net.thrymrOS.entity.corehr.Skill;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 23/05/23
 * @Time ➤➤➤ 11:38 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CandidateSkill extends BaseEntity {
    @ManyToOne(targetEntity = Skill.class,cascade = {CascadeType.MERGE})
    private Skill skill;
    @ManyToOne(targetEntity = ExpertiseLevel.class, cascade = {CascadeType.MERGE })
    ExpertiseLevel expertiseLevel;
    @ManyToOne(targetEntity = Candidate.class,cascade = {CascadeType.MERGE})
    private Candidate candidate;
}
