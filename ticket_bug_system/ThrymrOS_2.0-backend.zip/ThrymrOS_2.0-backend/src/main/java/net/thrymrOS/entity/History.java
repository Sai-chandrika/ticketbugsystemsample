package net.thrymrOS.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.thrymrOS.enums.CommentOf;
import net.thrymrOS.enums.HistoryAction;
import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Entity;
import java.sql.Timestamp;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  13/07/23
 * @Time >>  12:32 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class History extends BaseEntity{
    @CreationTimestamp
    @JsonIgnore
    private Timestamp historyOn;
    private String historyOfId;
    private CommentOf historyOf;
    private String assignedToId;
    private String assignedById;
    private HistoryAction HistoryAction;
}
