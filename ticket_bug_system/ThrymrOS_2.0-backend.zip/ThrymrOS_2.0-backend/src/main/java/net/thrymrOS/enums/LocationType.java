package net.thrymrOS.enums;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 3:57 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
public enum LocationType {
    DOMESTIC,
    INTERNATIONAL;
}
