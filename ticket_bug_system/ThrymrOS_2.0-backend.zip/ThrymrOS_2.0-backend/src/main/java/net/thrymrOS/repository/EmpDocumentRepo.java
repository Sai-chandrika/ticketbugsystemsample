package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpDocument;
import net.thrymrOS.responseEntity.GenericResponse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Swetha
 * @Date >>  21/03/23
 * @Time >>  5:14 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface EmpDocumentRepo extends JpaRepository<EmpDocument, String > {
    List<EmpDocument> findAllByEmployeeId(String empId);
    Optional<EmpDocument> findByDocumentIdAndEmployeeId(String documentId, String employeeId);
    List<EmpDocument>findAllByOrderByCreatedOnDesc();
}
