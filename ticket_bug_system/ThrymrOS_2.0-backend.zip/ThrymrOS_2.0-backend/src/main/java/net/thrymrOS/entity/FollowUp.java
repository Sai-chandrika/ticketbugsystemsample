package net.thrymrOS.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.crm.Lead;
import net.thrymrOS.enums.FollowUpType;
import net.thrymrOS.enums.Status;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  04/04/23
 * @Time >>  11:36 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class FollowUp extends BaseEntity {

    private LocalDate followUpDate;
    private FollowUpType followUpType;
    @Column(columnDefinition = "TEXT")
    private String comment;
    @ManyToOne(targetEntity = Lead.class, cascade = {CascadeType.MERGE})
    private Lead lead;
    private boolean isCompleted;

}
