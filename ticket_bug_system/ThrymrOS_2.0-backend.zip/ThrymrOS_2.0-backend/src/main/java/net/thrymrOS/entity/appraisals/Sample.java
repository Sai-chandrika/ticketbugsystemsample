package net.thrymrOS.entity.appraisals;

import jdk.jfr.Enabled;
import net.thrymrOS.entity.BaseEntity;

import javax.persistence.Entity;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 03-10-2023
 */
@Entity
public class Sample  extends BaseEntity {
      private String name;
      private AppraisalMeeting appraisalMeeting;
}
