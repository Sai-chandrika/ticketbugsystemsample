package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import java.util.Set;


/**
 * @Author >> Mamatha
 * @Date >>  24/04/23
 * @Time >>  11:22 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class LeadRequestDto {
    private String id;
    @NotBlank(message = "Lead name can't be null!!")
    private String name;
    private String description;
    private String source;
    @NotBlank(message = "Account can't be null!!")
    private String accountId;
    private String channelId;
    private Set<String> contactId;
    private String assignedTo;
    @NotBlank(message = "Lead Status can't be null!!")
    private String statusId;
    private String sourceTypeId;
    private boolean isActive;
}
