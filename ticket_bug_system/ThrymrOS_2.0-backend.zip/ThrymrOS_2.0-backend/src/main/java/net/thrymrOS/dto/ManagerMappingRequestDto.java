package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
/**
 * @Author >> Giridhar
 * @Date >>  11/04/23
 * @Time >>  11:15 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ManagerMappingRequestDto {
    private String id;
    @NotBlank(message = "Employee is required.")
    private String employeeId;
    @NotBlank(message = "Manager is required.")
    private String managerId;
    @NotNull(message = "From Date is required.")
    private LocalDate fromDate;
    @NotNull(message = "To Date is required.")
    private LocalDate toDate;
    private boolean isActive;
}
