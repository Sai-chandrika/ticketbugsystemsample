package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Allocation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  14/03/23
 * @Time >>  5:54 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public interface AllocationRepo extends JpaRepository<Allocation, String> {
    List<Allocation> findAllByEmployeeId(String empId);

    Optional<Allocation> findByEmployeeId(String empId);

    List<Allocation> findAllByProjectIdOrderByEmployeeFirstNameAsc(String projectId);

    List<Allocation> findAllByForDateBetween(LocalDate startDate, LocalDate endDate);

    List<Allocation> findAllByEmployeeIdAndProjectId(String empId, String projectId);

    List<Allocation> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<Allocation> findAllByEmployeeIdAndProjectIdOrderByCreatedOnDesc(String empId, String projectId);

    List<Allocation> findAllByProjectIdAndEmployeeIdAndForDateBetween(String projectId, String employeeId, LocalDate startDate, LocalDate endDate);
    Optional<Allocation> findAllByProjectIdAndEmployeeIdAndForDateEquals(String projectId,String employeeId, LocalDate forDate);

    List<Allocation> findAllByIsActiveTrue();
    //@Query("select project.id from Allocation  where employee.id = ?1 and forDate between ?2 and ?3 group by project.id")
    List<Allocation> findAllByEmployeeIdAndForDateBetween(String employeeId, LocalDate startDate, LocalDate endDate);
    @Query("select employee.id from Allocation  where project.id = ?1 and forDate between ?2 and ?3 group by employee.id")
    List<String> findDistinctByProjectIdAndForDateBetween(String projectId, LocalDate startDate, LocalDate endDate);

     Long countByForDate(LocalDate localDate);

    List<Allocation> findAllByForDate(LocalDate now);



    Allocation findByEmployeeIdAndProjectIdAndForDate(String id, String projectId, LocalDate now);

    List<Allocation> findByEmployeeIdAndProjectId(String id, String projectId);
}
