package net.thrymrOS.entity.token;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/09/23
 * @Time ➤➤➤ 5:19 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SessionTime {
    @Id
    @Column(columnDefinition = "Text")
    private String id;
    private LocalDateTime lastActiveTime;
}
