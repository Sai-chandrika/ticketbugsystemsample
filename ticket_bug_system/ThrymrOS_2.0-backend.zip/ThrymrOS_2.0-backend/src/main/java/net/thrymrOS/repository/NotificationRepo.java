package net.thrymrOS.repository;

import net.thrymrOS.entity.notification.Notification;
import net.thrymrOS.enums.NotificationOf;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  08/05/23
 * @Time >>  5:40 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface NotificationRepo extends JpaRepository<Notification, String> {
    List<Notification> findAllByToAppUserIdAndNotificationOfOrderByCreatedOnDesc(String id, NotificationOf notificationOf);
}
