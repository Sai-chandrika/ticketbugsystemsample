package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 10/07/23
 * @Time ➤➤➤ 3:47 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CountOfAllStatus {
    private Long planned;
    private Long raised;
    private Long sent;
    private Long due;
    private Long paid;
    private Long overDue;
    private Long writtenOff;
    private Long toBeRaised;
}
