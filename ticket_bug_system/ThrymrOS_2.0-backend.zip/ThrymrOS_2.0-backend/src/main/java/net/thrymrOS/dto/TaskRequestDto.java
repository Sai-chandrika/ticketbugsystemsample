package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.TaskPriorityType;
import net.thrymrOS.enums.TaskSeverityType;
import net.thrymrOS.enums.TaskStatus;
import net.thrymrOS.enums.TaskType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @Author >> Giridhar
 * @Date >>  07/03/23
 * @Time >>  09:50 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TaskRequestDto {
    private String id;
    private String task;
    private String projectId;
    private String description;
    private TaskPriorityType priority;
    private TaskSeverityType severity;
    private TaskType taskType;
    private LocalDate startDate;
    private LocalDate estimationDate;
    private int plannedEfforts;
    private int actualEfforts;
    private boolean isActive;
    private List<String> fileIds;

}
