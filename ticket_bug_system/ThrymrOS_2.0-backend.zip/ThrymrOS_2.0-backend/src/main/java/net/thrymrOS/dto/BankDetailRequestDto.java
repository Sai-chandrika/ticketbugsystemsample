package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 24/06/23
 * @Time ➤➤➤ 11:12 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BankDetailRequestDto {
    private String id;
    @NotBlank(message = "Bank Name can't be Null/Empty")
    private String bankName;
    @NotBlank(message = "Beneficiary Name can't be Null/Empty")
    private String beneficiaryName;
    @NotBlank(message = "Bank Account Number can't be Null/Empty")
    @Pattern(regexp = "[0-9]*", message = "Account Number can only have digits")
    private String bankAccountNumber;
    @NotBlank(message = "Bank Swift Code can't be Null/Empty")
    private String bankSwiftCode;
    @NotBlank(message = "Bank Branch Address can't be Null/Empty")
    private String bankBranchAddress;
    @NotBlank(message = "Ifsc can't be Null/Empty")
    private String ifsc;
    @NotBlank(message = "Ice can't be Null/Empty")
    private String iec;
    @NotBlank(message = "Pan can't be Null/Empty")
    private String pan;
    @NotBlank(message = "ZipCode can't be Null/Empty")
    private String zipCode;
    private String description;
    private boolean isActive;
    private  boolean isDefault;
    @NotBlank(message = "City id can't be Null/Empty")
    private String cityId;
   // @NotBlank(message = "Country id can't be Null/Empty")
    private String countryId;
  //  @NotBlank(message = "State id can't be Null/Empty")
    private String stateId;
}
