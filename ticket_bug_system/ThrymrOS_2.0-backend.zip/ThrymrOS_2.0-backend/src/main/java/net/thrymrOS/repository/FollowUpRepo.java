package net.thrymrOS.repository;

import net.thrymrOS.entity.FollowUp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  04/04/23
 * @Time >>  11:57 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface FollowUpRepo extends JpaRepository<FollowUp,String> {
    List<FollowUp> findAllByLeadIdOrderByCreatedOnDesc(String id);
    List<FollowUp> findAllByOrderByCreatedOnDesc();
    List<FollowUp> findAllByLeadIdOrderByFollowUpDateDesc(String leadId);
    List<FollowUp> findAllByLeadId(String leadId);
   // List<FollowUp> findAllByLeadIdAndFollowUpDate(String leadId, LocalDate date);
    List<FollowUp> findAllByFollowUpDate(LocalDate date);
    List<FollowUp> findAllByFollowUpDateAndIsCompleted(LocalDate date ,boolean b);
    List<FollowUp> findAllByFollowUpDateBetween(LocalDate startDate , LocalDate endDate);
    List<FollowUp> findByLeadCreatedBy(String id);
    List<FollowUp> findByLeadAssignedToId(String id);

    List<FollowUp> findAllByFollowUpDateGreaterThanEqualAndFollowUpDateLessThanEqual(LocalDate startDate , LocalDate endDate);
    List<FollowUp> findAllByLeadIsActive(boolean b);

}
