package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  27/04/23
 * @Time >>  5:17 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum HolidayType {
    PH,
    SUNDAY
}
