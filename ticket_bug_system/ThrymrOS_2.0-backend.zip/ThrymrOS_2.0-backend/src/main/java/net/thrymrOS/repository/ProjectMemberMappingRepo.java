package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Project;
import net.thrymrOS.entity.pm.ProjectMemberMapping;
import net.thrymrOS.enums.TeamRole;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  27/03/23
 * @Time >>  12:03 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ProjectMemberMappingRepo extends JpaRepository<ProjectMemberMapping,String> {
    List<ProjectMemberMapping> findAllByOrderByIsActiveDescCreatedOnDesc();
    Optional<ProjectMemberMapping> findByProjectIdAndTeamMemberIdAndRoleList(String projectId, String empId, TeamRole teamRole);
    List<ProjectMemberMapping> findAllByProjectId(String projectId);
    List<ProjectMemberMapping> findAllByProjectIdOrderByTeamMemberFirstNameAsc(String projectId);
    List<ProjectMemberMapping> findAllByProjectIdOrderByIsActiveDescTeamMemberFirstNameAsc(String projectId);
    List<ProjectMemberMapping> findAllByTeamMemberId(String empId);
    List<ProjectMemberMapping> findAllByTeamMemberIdOrderByProjectIsActiveDescProjectNameAsc(String empId);
    Optional<ProjectMemberMapping> findByProjectIdAndTeamMemberId(String projectId, String empId);

    List<ProjectMemberMapping> findAllByProjectIdAndIsActive(String id, boolean b);
}
