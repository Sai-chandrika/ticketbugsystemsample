package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.PositionStatus;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  23/03/23
 * @Time >>  11:48 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PositionRequestDto {
    // MANDATORY
    private String id;
    @NotBlank(message = "Name can't be Null/Empty")
    private String name;
    @NotNull(message = "Position Status can't be Null/Empty")
    private PositionStatus positionStatus;
    private int positionCount;
    @NotNull(message = "Kick Off Date can't be Null/Empty")
    private LocalDate kickOffDate;
    private LocalDate closureDate;
    @NotBlank(message = "OrgUnit Id can't be Null/Empty")
    private String orgUnitId;
    @NotBlank(message = "Client Id can't be Null/Empty")
    private String clientId;
    @NotBlank(message = "Location Id can't be Null/Empty")
    private String LocationId;
    @NotBlank(message = "Hiring Manager Id can't be Null/Empty")
    private String hiringManagerId;
    private List<String> recruiterIds=new ArrayList<String>();
    @NotBlank(message = "job Description can't be Null/Empty")
    private String jobDescription;

    // NOT MANDATORY
    private List<String> referenceDocument =new ArrayList<String>();
    private Integer minExperience;
    private Integer maxExperience;
    private String currencyId;
    private Long budget;
    private boolean isActive;
}
