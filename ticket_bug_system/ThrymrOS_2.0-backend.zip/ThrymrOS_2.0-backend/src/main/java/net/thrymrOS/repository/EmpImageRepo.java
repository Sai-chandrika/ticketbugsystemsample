package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.EmpImage;
import net.thrymrOS.entity.corehr.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  28/02/23
 * @Time >>  11:49 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface EmpImageRepo extends JpaRepository<EmpImage,String> {
   Optional<EmpImage> findByEmployeeId(String empId);
   List<EmpImage>findAllByOrderByCreatedOnDesc();
   Optional<EmpImage> findByEmployeeEmailId(String email);

    Optional<EmpImage> findByEmployeeIdAndCreatedOn(String employeeId, String createdBy);
}
