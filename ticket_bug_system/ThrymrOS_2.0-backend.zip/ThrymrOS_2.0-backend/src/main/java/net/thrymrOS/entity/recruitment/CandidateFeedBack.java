package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  20/05/23
 * @Time >>  9:57 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class CandidateFeedBack extends BaseEntity {

    @ManyToOne(targetEntity = ScheduleInterview.class, cascade = {CascadeType.MERGE })
    private ScheduleInterview scheduleInterview;
    @Column(columnDefinition = "TEXT")
    private String feedBack;
    @ElementCollection
    private List<String> uploadFiles=new ArrayList<String>();

}
