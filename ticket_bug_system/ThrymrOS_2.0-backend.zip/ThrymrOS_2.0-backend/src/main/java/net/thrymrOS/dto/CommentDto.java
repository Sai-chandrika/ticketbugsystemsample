package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CommentOf;
import net.thrymrOS.enums.CommentType;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CommentDto {
    private String id;
    private String commentedBy;
    private String description;
    private CommentType type;
    private CommentOf commentOf;
    private String commentOfId;
    private List<String> fileIds=new ArrayList<String>();
}
