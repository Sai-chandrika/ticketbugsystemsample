package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 23/05/23
 * @Time ➤➤➤ 11:42 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CandidateSkillRequestDto {
    private String id;
    @NotBlank(message = "Skill id can't be Null/Empty")
    private String skillId;
    @NotBlank(message = "Expertise Level id can't be Null/Empty")
    private String expertiseLevelId;
    @NotBlank(message = "Candidate id can't be Null/Empty")
    private String candidateId;
}
