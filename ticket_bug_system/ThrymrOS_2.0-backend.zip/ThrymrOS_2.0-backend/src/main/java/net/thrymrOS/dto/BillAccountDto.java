package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 01/08/23
 * @Time ➤➤➤ 2:06 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BillAccountDto {
    private String id;
    @NotBlank(message = "account category should not be null/Empty")
    private String accountCategory;
    private List<String> subCategory;

}
