package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.entity.pm.Project;
import net.thrymrOS.entity.pm.ProjectMemberMapping;

import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 16/05/23
 * @Time >> 9:43 am
 * @Project >> ThrymrOS_2.0-backend
 **/
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectTeamResponse {
    private EmployeeDto member;
    private LeaveResponseDto leaveDto;
    private List<String> projectList;
}
