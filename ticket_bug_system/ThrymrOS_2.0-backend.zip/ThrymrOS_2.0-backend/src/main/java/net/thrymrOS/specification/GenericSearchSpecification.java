package net.thrymrOS.specification;


import lombok.Data;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.Entity;
import javax.persistence.criteria.*;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;


/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 20/07/23
 * @Time ➤➤➤ 5:04 pm
 * @Project ➤➤➤ springBootAssignment-2
 */
@Data
public class GenericSearchSpecification<T> implements Specification<T> {

    private final String searchValue;

    public GenericSearchSpecification(String searchValue) {
        this.searchValue = searchValue;
    }

    @Override
    public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
        if (searchValue == null || searchValue.isEmpty()) {
            return criteriaBuilder.conjunction();
        }

        String likePattern = "%" + searchValue.toLowerCase() + "%";
        List<Predicate> predicates = new ArrayList<>();

        Class<? extends T> entityType = root.getJavaType();
        Field[] fields = entityType.getDeclaredFields();
        addPredicatesForFields(root, root, criteriaBuilder, likePattern, predicates, fields);
        return criteriaBuilder.or(predicates.toArray(new Predicate[0]));
    }

    private void addPredicatesForFields(Root<T> root, Path<?> path, CriteriaBuilder criteriaBuilder, String likePattern, List<Predicate> predicates, Field[] fields) {
        for (Field field : fields) {
            if (field.getType().equals(String.class)) {
                List<Predicate> predicates1 = new ArrayList<>();
                predicates1.add(criteriaBuilder.like(criteriaBuilder.lower(path.get(field.getName())), likePattern));
                predicates1.add(criteriaBuilder.equal(criteriaBuilder.lower(path.get(field.getName())), likePattern));
                predicates.addAll(predicates1);
            } else if (field.getType() == LocalDate.class) {
                try {
                    if (searchValue.matches("\\d{2}-\\d{2}-\\d{4}")) {
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                        LocalDate searchDate = LocalDate.parse(searchValue, formatter);
                        predicates.add(criteriaBuilder.equal(path.get(field.getName()), searchDate));
                    }
                } catch (DateTimeParseException e) {
                    // Handle the exception if the searchValue cannot be parsed as LocalDate
                }
            } else if (field.getType().equals(LocalDateTime.class)) {
                try {
                    LocalDateTime searchLocalDateTime = LocalDateTime.parse(searchValue);
                    predicates.add(criteriaBuilder.equal(path.get(field.getName()), searchLocalDateTime));
                } catch (DateTimeParseException e) {
                    // Handle the exception if the searchValue cannot be parsed as LocalDateTime
                }
            } else if (field.getType().equals(Timestamp.class)) {
                try {
                    Timestamp searchLocalDateTime = Timestamp.valueOf(searchValue);
                    predicates.add(criteriaBuilder.equal(path.get(field.getName()), searchLocalDateTime));
                } catch (DateTimeParseException e) {
                    // Handle the exception if the searchValue cannot be parsed as Timestamp
                }
            } else if (field.getType().isEnum()) {
                try {
                    Class<? extends Enum> enumClass = (Class<? extends Enum>) field.getType();
                    Enum<?> enumValue = Enum.valueOf(enumClass, searchValue);
                    predicates.add(criteriaBuilder.equal(path.get(field.getName()), enumValue));

                } catch (Exception e) {
                    // Handle the exception if the searchValue cannot be parsed as Enum
                }
            } else if (field.getType().isAnnotationPresent(Entity.class)) {
                addPredicatesForFields(root, path.get(field.getName()), criteriaBuilder, likePattern, predicates, field.getType().getDeclaredFields());
            }
        }
    }
}










