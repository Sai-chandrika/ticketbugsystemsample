package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import net.thrymrOS.enums.AllocationType;
import net.thrymrOS.enums.TeamRole;

import javax.websocket.server.ServerEndpoint;
import java.util.List;

/**
 * @author chandrika
 * user
 * @ProjectName ThrymrOS_2.0-backend
 * @since 31-07-2023
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TeamMembersDto {
    private ProjectMemberMappingDto dto;
    private AllocationType allocation;
    private long taskAssigned;
    private long completed;
    private long inProgress;
    private long onHold;

}