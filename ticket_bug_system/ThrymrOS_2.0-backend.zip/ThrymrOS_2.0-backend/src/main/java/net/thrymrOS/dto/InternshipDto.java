package net.thrymrOS.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.recruitment.Candidate;

import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  5:36 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class InternshipDto {
    private Candidate candidate;
    private String id;
    private String employer;
    private String position;
    private String location;
    private LocalDate fromYear;
    private LocalDate toYear;
}
