package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Milestone;
import net.thrymrOS.enums.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  20/04/23
 * @Time >>  12:09 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface MilestoneRepo extends JpaRepository<Milestone,String> {
    Optional<Milestone> findByNameIgnoreCase(String name);
    Optional<Milestone> findByNameIgnoreCaseAndProjectId(String name, String projectId);
    List<Milestone> findAllByProjectIdOrderByCreatedOnDesc(String projectId);
    List<Milestone> findAllByProjectIdOrderByIsActiveDescNameAsc(String projectId);
    List<Milestone> findAllByIdAndTaskStatus(String id, TaskStatus taskStatus);
    List<Milestone> findAllByIsActive(boolean b);
    Optional<Milestone> findByTaskId(String taskId);
    List<Milestone> findAllByIsActiveOrderByNameAsc(boolean b);
    List<Milestone> findAllByProjectId(String projectId);
    List<Milestone> findAllByProjectIdAndStatus(String projectId, TaskStatus status);

    List<Milestone> findAllByOrderByCreatedOnDesc();

    List<Milestone> findAllByIdNotInAndProjectId(List<String> milestones,String projectId);
}
