package net.thrymrOS.custom_exception;

public class NullValueException extends RuntimeException{
    public NullValueException(String message) {
        super(message);
    }
}
