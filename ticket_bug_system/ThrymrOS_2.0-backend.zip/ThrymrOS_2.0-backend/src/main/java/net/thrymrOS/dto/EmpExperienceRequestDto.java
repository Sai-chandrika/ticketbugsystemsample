package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;

/**
 * @Author >> Mamatha
 * @Date >>  01/03/23
 * @Time >>  2:17 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class EmpExperienceRequestDto {
    private String id;
    private String employerName;
    private String address;
    private String natureOfBusiness;
    private String designationHeld;
    private LocalDate fromDate;
    private LocalDate toDate;
    private String reasonForLeaving;
    private String referenceId;
}
