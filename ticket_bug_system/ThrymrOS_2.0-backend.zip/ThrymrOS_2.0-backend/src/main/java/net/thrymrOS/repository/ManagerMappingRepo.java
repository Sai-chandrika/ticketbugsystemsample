package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.ManagerMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar
 * @Date >>  11/04/23
 * @Time >>  11:22 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ManagerMappingRepo extends JpaRepository<ManagerMapping, String> {
    List<ManagerMapping> findAllByManagerId(String managerId);

    Optional<ManagerMapping> findByEmployeeIdAndManagerId(String employeeId, String managerId);

    List<ManagerMapping> findAllByOrderByIsActiveDescCreatedOnDesc();

    Optional<ManagerMapping> findAllByManagerIdAndEmployeeIdAndFromDateGreaterThanEqualAndToDateLessThanEqual(String managerId, String employeeId, LocalDate fromDate, LocalDate toDate);

    Optional<ManagerMapping> findAllByEmployeeIdAndFromDateLessThanEqualAndToDateGreaterThanEqual( String employeeId, LocalDate fromDate, LocalDate toDate);

    List<ManagerMapping> findAllByManagerIdAndFromDateLessThanEqualAndToDateGreaterThanEqual(String managerId, LocalDate fromDate, LocalDate toDate);

    List<ManagerMapping> findAllByIsActiveEquals(Boolean aTrue);

    List<ManagerMapping> findAllByEmployeeId(String id);

    List<ManagerMapping> findByEmployeeId(String empId);

}
