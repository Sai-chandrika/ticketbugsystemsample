package net.thrymrOS.repository;

import net.thrymrOS.entity.md.crm.Channel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Giridhar Kommu
 * @Date >>  06/07/23
 * @Time >>  10:31 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ChannelRepo extends JpaRepository<Channel, String> {

    Optional<Channel> findByNameIgnoreCase(String name);

    List<Channel> findAllByOrderByIsActiveDescCreatedOnDesc();

    List<Channel> findAllByIsActiveOrderByNameAsc(boolean b);
}
