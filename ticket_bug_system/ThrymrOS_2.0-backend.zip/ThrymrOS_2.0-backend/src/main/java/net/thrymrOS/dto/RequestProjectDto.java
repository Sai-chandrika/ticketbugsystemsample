package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 25/04/23
 * @Time >> 12:02 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@NoArgsConstructor
@Data
public class RequestProjectDto {
    private String projectId;
    private LocalDate fromDate;
    private LocalDate toDate;
}
