package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.Type;

import java.sql.Timestamp;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:35 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class AttendanceResponseDto {
    private String id;
    private String totalHoursInOffice;
    private String totalBreakHours;
    private String ActualWorkingHours;
    private Type type;
    private Timestamp dateTime;
    private WorkLocationDto workLocation;
    private String employeeName;
    private Boolean systemLogOut;
}
