package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 5:15 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AddressDto {
    private String id;
    private String address;
    private CountryDto country;
    private StateDto state;
    private CityDto city;
    private String zipCode;
//    private String fax;
    private boolean isActive;
}
