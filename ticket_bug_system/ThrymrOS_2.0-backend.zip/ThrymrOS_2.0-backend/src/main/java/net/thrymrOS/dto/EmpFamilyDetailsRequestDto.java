package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  03/03/23
 * @Time >>  1:11 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmpFamilyDetailsRequestDto {
    private String id;
    private String fatherName;
    private String motherName;
    private String spouse;
    private String employeeId;
}
