package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 26/06/23
 * @Time ➤➤➤ 5:49 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface AddressRepo extends JpaRepository<Address,String> {
}
