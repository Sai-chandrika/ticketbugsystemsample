package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.ops.Leave;
import net.thrymrOS.enums.HolidayType;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 05/05/23
 * @Time >> 4:56 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterReportDto {
    private Long actualWorkingDays;
    private Long totalWorkingDays;
    private String totalWorkingHours;
    private String avgCheckIn;
    private String avgCheckOut;
    private String avgWorkingHours;
    private EmployeeDto employeeDto;
    private List<RegisterDto> registerList;
    private CountBalanceDto leaveCount;
    private int leave;
    private boolean isActive;
}
