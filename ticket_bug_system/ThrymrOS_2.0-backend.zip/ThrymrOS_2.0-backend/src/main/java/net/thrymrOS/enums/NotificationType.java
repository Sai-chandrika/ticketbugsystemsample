package net.thrymrOS.enums;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  08/05/23
 * @Time >>  5:17 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum NotificationType {
    STANDARD,
    IMPORTANT,
    URGENT
}
