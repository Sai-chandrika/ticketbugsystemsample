package net.thrymrOS.enums;

/**
 * @author chandrika
 * @ProjectName ThrymrOS_2.0-backend
 * @since 12-06-2023
 */
public enum ImportanceType {
    HIGH_IMPORTANT,
    IMPORTANT,
    LOW_IMPORTANT;

}