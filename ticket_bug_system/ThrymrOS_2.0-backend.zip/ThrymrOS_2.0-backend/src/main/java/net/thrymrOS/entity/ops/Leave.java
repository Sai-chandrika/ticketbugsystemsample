package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.entity.MultiLeaveOption;
import net.thrymrOS.entity.corehr.Employee;
import net.thrymrOS.enums.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  06/03/23
 * @Time >>  3:21 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Leave extends BaseEntity {
    private LocalDate dateApplied = LocalDate.now();
    private LeaveType leaveType;
    private LeaveStatus status;
    private LocalDate fromDate;
    private LocalDate toDate;
    private LeaveBalanceType leaveBalanceType;
    private LeaveDuration leaveDuration;
    @Column(columnDefinition = "TEXT")
    private String description;
    private Boolean cancelLeave = Boolean.FALSE;
    @Column(name = "file_ids")
    @ElementCollection(targetClass = String.class)
    private List<String> fileIds = new ArrayList<>();
    @ManyToMany(targetEntity = Employee.class, cascade = {CascadeType.MERGE, CascadeType.DETACH})
    private List<Employee> appliedTo = new ArrayList<Employee>();
    @ManyToMany(targetEntity = Employee.class, cascade = {CascadeType.MERGE, CascadeType.DETACH})
    private List<Employee> cc = new ArrayList<Employee>();
    @ManyToOne(cascade = {CascadeType.PERSIST}, fetch = FetchType.EAGER)
    private Employee employee;
    @Column(columnDefinition = "TEXT")
    private String cancelReason;
    @OneToMany(targetEntity = MultiLeaveOption.class, cascade = {CascadeType.MERGE, CascadeType.DETACH})
    private List<MultiLeaveOption> multiLeaveOptions = new ArrayList<>();
    private Integer hours;
}
