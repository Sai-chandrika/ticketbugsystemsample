package net.thrymrOS.enums;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  4:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum EducationLevel {
    SSC, //0
    INTERMEDIATE, // 1
    GRADUATE, //2
    POST_GRADUATE, //3
}
