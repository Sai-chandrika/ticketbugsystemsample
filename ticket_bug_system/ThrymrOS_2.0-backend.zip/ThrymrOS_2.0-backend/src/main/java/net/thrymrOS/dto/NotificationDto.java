package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.enums.NotificationType;

import javax.persistence.ManyToOne;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  08/05/23
 * @Time >>  5:44 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor

public class NotificationDto {
    private String id;
    private String notificationText;
    private Boolean isRead;
    private NotificationType notificationType=NotificationType.STANDARD;
    private AppUserDto fromAppUser;
    private AppUserDto toAppUser;
    private String notificationOfId;

}
