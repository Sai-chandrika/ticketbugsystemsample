package net.thrymrOS.repository;

import net.thrymrOS.entity.pm.ChangeInvoiceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 10/07/23
 * @Time ➤➤➤ 12:57 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface ChangeInvoiceStatusRepo extends JpaRepository<ChangeInvoiceStatus,String> {
}
