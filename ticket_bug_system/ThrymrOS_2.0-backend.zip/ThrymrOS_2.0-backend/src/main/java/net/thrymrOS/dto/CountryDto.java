package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.Set;


/**
 * @Author >> Giridhar
 * @Date >>  21/02/23
 * @Time >>  12:20 pm
 * @Project >>  ThrymrOS_2.0-backend
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CountryDto {
    private String id;
    @NotNull(message = "country name can't be null!!")
    private String name;
    private Set<StateDto> states;
    private boolean isActive;
    private Integer sequenceNo;
}
