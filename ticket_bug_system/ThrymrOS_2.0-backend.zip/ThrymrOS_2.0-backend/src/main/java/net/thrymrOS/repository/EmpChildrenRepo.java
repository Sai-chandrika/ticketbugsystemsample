package net.thrymrOS.repository;

import net.thrymrOS.dto.EmpChildrenDto;
import net.thrymrOS.entity.corehr.EmpChildren;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author >> Swetha
 * @Date >>  25/02/23
 * @Time >>  3:29 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface EmpChildrenRepo extends JpaRepository<EmpChildren, String> {
    List<EmpChildren> findAllByEmployeeId(String id);
    List<EmpChildren>findAllByOrderByCreatedOnDesc();
}
