package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.KpiAndKraMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 13/06/23
 * @Time ➤➤➤ 10:25 am
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface KpiAndKraMappingRepo extends JpaRepository<KpiAndKraMapping,String> {

    List<KpiAndKraMapping> findAllByIsActiveTrue();

    Optional<KpiAndKraMapping> findByKpiIdAndKraIdAndDepartmentIdAndDesignationIdAndLevelId(String kpiId, String kraId, String departmentId, String designationId, String levelId);
    List<KpiAndKraMapping> findAllByOrderByIsActiveDesc();
}
