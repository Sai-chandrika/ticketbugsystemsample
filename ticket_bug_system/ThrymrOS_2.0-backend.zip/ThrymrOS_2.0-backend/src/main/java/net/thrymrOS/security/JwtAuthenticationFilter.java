package net.thrymrOS.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import net.thrymrOS.entity.token.SessionTime;
import net.thrymrOS.repository.SessionTimeRepo;
import net.thrymrOS.responseEntity.GenericResponse;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.security.security_service.JwtToken;
import net.thrymrOS.service.implementation.AppUserServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.AccessDeniedException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;

public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtToken token;


    private final AppUserServiceImpl appUserService;
    private final SessionTimeRepo sessionTimeRepo;
    private Integer sessionTime;


    JwtAuthenticationFilter(JwtToken jwtTokenUtil, AppUserServiceImpl appUserService, Integer sessionTime,SessionTimeRepo sessionTimeRepo) {
        this.token = jwtTokenUtil;
        this.appUserService = appUserService;
        this.sessionTime=sessionTime;
        this.sessionTimeRepo=sessionTimeRepo;
    }

    public static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filter)
            throws IOException {

        try {

            logger.info("request getPathInfo " + request.getRequestURI() + ", setting security context");

            String authToken = request.getHeader("Authorization");

            Optional<SessionTime> time=sessionTimeRepo.findById(authToken);
            if(time.isEmpty()|| Duration.between(time.get().getLastActiveTime(), LocalDateTime.now()).toSeconds()>sessionTime * 60 ){
                throw new AccessDeniedException("access denied");
            }



//            if( Duration.between(DynamicToken.lastActiveTime, LocalDateTime.now()).toSeconds()>sessionTime * 60){
//                throw new AccessDeniedException("access denied");
//            }

            String userName = token.parseToken(authToken).get("email");

            if (userName == null) {
                filter.doFilter(request, response);
            }

            AppUser userOpt = appUserService.findByEmail(userName);

            if (userOpt != null) {
           //     DynamicToken.lastActiveTime=LocalDateTime.now();
                time.get().setLastActiveTime(LocalDateTime.now());
                sessionTimeRepo.save(time.get());
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userOpt, null, Arrays.asList(
                        new SimpleGrantedAuthority(userOpt.getRoleType().getName())));
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                logger.info("authenticated user " + userName + ", setting security context");

                SecurityContextHolder.getContext().setAuthentication(authentication);

                filter.doFilter(request, response);

            } else {
                throw new NoSuchElementException();
            }
        } catch (Exception e) {
            generateUnauthorisedAccess(response);
        }

    }

/*    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filter)
            throws IOException {

        try {

            logger.info("request getPathInfo " + request.getRequestURI() + ", setting security context");


            String authToken = request.getHeader("Authorization");
            AppUser userOpt;
            String userName;
            if (authToken.equals(DynamicToken.originalToken) ) {

                userName = token.parseToken(DynamicToken.copyToken).get("email");

            }else {
                userName= token.parseToken(authToken).get("email");
                if (userName!=null) DynamicToken.originalToken=authToken;
            }
            userOpt = appUserService.findByEmail(userName);

            if (userName == null) {
                generateUnauthorisedAccess(response);
            } else {
                DynamicToken.fromFilter = true;
                DynamicToken.copyToken = token.getToken(userOpt);
            }
//            String userName = token.parseToken(authToken).get("email");
//
//            if (userName == null) {
//                filter.doFilter(request, response);
//            }
//
//            AppUser userOpt = appUserService.findByEmail(userName);
            if (userOpt != null) {

                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userOpt, null, Arrays.asList(
                        new SimpleGrantedAuthority(userOpt.getRoleType().getName())));
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                logger.info("authenticated user " + userName + ", setting security context");

                SecurityContextHolder.getContext().setAuthentication(authentication);

//
//                if (DynamicToken.tokenExpirationTime.plusMinutes(45).isBefore(LocalDateTime.now())) {
//                    response.setHeader("Authorization", token.getToken(userOpt));
//                }


                filter.doFilter(request, response);

            } else {
                throw new NoSuchElementException();
            }
        } catch (Exception e) {
            generateUnauthorisedAccess(response);
        }

    }*/

    public void generateUnauthorisedAccess(HttpServletResponse res) throws IOException {
        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        res.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        GenericResponse resp = new GenericResponse(HttpStatus.UNAUTHORIZED.value(), "UNAUTHORISED");
        String jsonRespString = ow.writeValueAsString(resp);
        res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        PrintWriter writer = res.getWriter();
        writer.write(jsonRespString);
        System.out.println("***********************");
    }

}