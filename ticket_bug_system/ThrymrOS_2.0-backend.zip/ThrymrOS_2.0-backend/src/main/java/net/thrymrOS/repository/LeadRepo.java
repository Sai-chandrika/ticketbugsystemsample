package net.thrymrOS.repository;

import net.thrymrOS.entity.crm.Lead;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Dasta
 * @Date >>  16/02/23
 * @Time >>  3:47 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface LeadRepo extends JpaRepository<Lead,String> {
    List<Lead> findAllByOrderByIdAsc();
    List<Lead>findAllByOrderByIsActiveDescCreatedOnDesc();
    List<Lead> findAllByOrderByNameAsc();
    Lead findByNameIgnoreCaseAndAccountId(String id, String AccountId);
    Optional<Lead> findByNameIgnoreCase(String leadName);
    boolean existsByNameIgnoreCase(String name);

    List<Lead> findAllByStatusName(String name);
    List<Lead> findAllByIsActive(boolean b);
    List<Lead> findAllByOrderByIsActiveDescNameAsc();

    List<Lead> findAllByIsActiveOrderByNameAsc(boolean b);

    List<Lead> findAllByCreatedByOrderByIsActiveDesc(String createdBy);

    List<Lead> findAllByAssignedToIdOrderByIsActiveDesc(String assignedId);
}
