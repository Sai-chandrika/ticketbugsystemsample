package net.thrymrOS.repository;

import net.thrymrOS.entity.finance.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 02/08/23
 * @Time ➤➤➤ 2:41 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Repository
public interface ExpenseRepo extends JpaRepository<Expense,String> {
    List<Expense> findAllByOrderByCreatedOnDescIsActiveDesc();

    Optional<Expense> findByVendorId(String vendorId);

    Optional<Expense> findByBillNumber(String billNumber);

    List<Expense> findAllByOrderByIsActiveDescCreatedOnDesc();
}
