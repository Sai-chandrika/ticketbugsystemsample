package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import net.thrymrOS.enums.AmountType;
import net.thrymrOS.enums.PaymentTerms;
import net.thrymrOS.enums.TaxType;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 01/08/23
 * @Time ➤➤➤ 2:54 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BillRequestDto {

    private String id;
    @NotBlank(message = "vendor Id should not be blank/Empty")
    private String vendorId;
    @NotBlank(message = "bill number should not be blank/Empty")
    private String billNumber;
    private String orderNumber;
    @NotNull(message = "Bill Date Should not be null")
    private LocalDate billDate;
    private LocalDate dueDate;
    private PaymentTerms paymentTerms;
    private Boolean reverseCharge;

    // BILL ITEAMS
    private List<BillItemRequestDto> billItemDtoList=new ArrayList<>();

    private String note;

    // subtotal-calculation
    private double subTotal;
    private TaxType taxType;
    private AmountType amountType;
    private String discount;
    private double total;
    private String typeOfAdjust;
    private double amountOfAdjust;
    private String tdsValue;
    private double paid;
    private double balance;

    // FILES
    private List<String> uploadFileids=new ArrayList<>();
}
