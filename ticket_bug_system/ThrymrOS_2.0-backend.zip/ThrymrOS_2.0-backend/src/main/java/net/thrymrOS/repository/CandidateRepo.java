package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.Candidate;
import net.thrymrOS.entity.recruitment.Position;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  9:41 am
 * @Project >>  ThrymrOS_2.0-backend
 */

@Repository
public interface CandidateRepo extends JpaRepository<Candidate,String> {

    List<Candidate> findAllByPositionIdOrderByCreatedOnDesc(String positionId);
    List<Candidate> findAllByOrderByCreatedOnDesc();
    List<Candidate> findAllByIsActive(boolean b);
    List<Candidate> findAllByPositionIdOrderByIsActiveDescNameAsc(String positionId);
    List<Candidate> findAllByOrderByIsActiveDescNameAsc();
    //Optional<Candidate> findByAadhaarNumber(String id);
    boolean existsByAadhaarNumber(String id);
    List<Candidate> findAllByIsActiveOrderByNameAsc(boolean b);
}
