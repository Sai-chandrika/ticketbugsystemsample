package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

/**
 * @Author >> Giridhar Kommu
 * @Date >> 13/05/23
 * @Time >> 5:07 pm
 * @Project >> ThrymrOS_2.0-backend
 **/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LocationRequestDto {
    List<String> stringList;
    LocalDate forDate;
}
