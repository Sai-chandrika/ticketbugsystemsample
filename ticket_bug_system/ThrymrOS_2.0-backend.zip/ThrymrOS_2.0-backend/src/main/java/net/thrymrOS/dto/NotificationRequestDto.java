package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.AppUser;
import net.thrymrOS.enums.NotificationOf;
import net.thrymrOS.enums.NotificationType;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  09/05/23
 * @Time >>  11:37 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class NotificationRequestDto {
    private String id;
    private String notificationText;
    private Boolean isRead = Boolean.FALSE;
    private NotificationType notificationType=NotificationType.STANDARD;
    private NotificationOf notificationOf;
    private AppUser fromAppUser;
    private AppUser toAppUser;
    private String notificationOfId;

}
