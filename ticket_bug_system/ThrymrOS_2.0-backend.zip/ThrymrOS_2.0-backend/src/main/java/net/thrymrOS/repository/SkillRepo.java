package net.thrymrOS.repository;

import net.thrymrOS.dto.SkillDto;
import net.thrymrOS.entity.corehr.Skill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  03/03/23
 * @Time >>  2:57 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface SkillRepo extends JpaRepository<Skill, String> {
    List<Skill> findAllByOrderByIdAsc();

    boolean existsByNameIgnoreCase(String name);

    List<Skill> findAllByOrderByIsActiveDescNameAsc();

    //findAllByOrderByIsActiveDescNameAsc
    Optional<Skill> findByNameIgnoreCase(String name);

    List<Skill> findAllByIsActiveEquals(Boolean aTrue);

    List<Skill> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}
