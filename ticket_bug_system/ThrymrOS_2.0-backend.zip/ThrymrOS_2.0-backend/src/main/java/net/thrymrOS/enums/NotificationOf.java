package net.thrymrOS.enums;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  09/05/23
 * @Time >>  12:01 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
public enum NotificationOf {
    LEAD,//0
    LEAVE//1

}
