package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.HolidayType;

import java.time.LocalDate;

/**
 * @Author >> Swetha
 * @Date >>  20/04/23
 * @Time >>  11:41 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class DSRTaskReportDto {
    private LocalDate date;
    private Integer tasks;
    private String totalHours;
    private Boolean onLeave=Boolean.FALSE;
    private Boolean isHoliday=Boolean.FALSE;
    private String holidayType;
    private String leaveType;
}
