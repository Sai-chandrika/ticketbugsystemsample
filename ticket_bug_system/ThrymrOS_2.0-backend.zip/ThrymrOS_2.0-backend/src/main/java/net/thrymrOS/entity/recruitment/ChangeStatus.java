package net.thrymrOS.entity.recruitment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.enums.CandidateStatus;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 * @Author >> Mamatha
 * @Date >>  27/05/23
 * @Time >>  5:22 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class ChangeStatus  extends BaseEntity {
    @ManyToOne(targetEntity = Candidate.class,  cascade = {CascadeType.MERGE })
    private Candidate candidate;
    private CandidateStatus oldStatus;
    private CandidateStatus newStatus;
    private String reason;
}
