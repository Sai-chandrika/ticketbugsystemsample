package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.CandidateStatus;
import net.thrymrOS.enums.CandidateType;

import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  24/07/23
 * @Time >>  6:42 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateFileDto {
    private String id;
    private String name;
    private CandidateStatus candidateStatus;
    private String candidateCode;
    private CandidateType candidateType;
    private boolean isActive;
    private FileUploadDto candidateImage;
    private FileUploadDto resume;
    private String aadharNumber;
    private FileUploadDto aadharFile;
    private List<FileUploadDto> otherAttachments;

}
