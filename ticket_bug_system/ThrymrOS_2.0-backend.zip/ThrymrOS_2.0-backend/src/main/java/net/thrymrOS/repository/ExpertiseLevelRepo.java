package net.thrymrOS.repository;

import net.thrymrOS.entity.corehr.ExpertiseLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  03/03/23
 * @Time >>  2:58 pm
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface ExpertiseLevelRepo extends JpaRepository<ExpertiseLevel, String> {
    List<ExpertiseLevel> findAllByOrderByIdAsc();

    List<ExpertiseLevel> findAllByOrderByIsActiveDescNameAsc();

    boolean existsByNameIgnoreCase(String name);

    Optional<ExpertiseLevel> findByNameIgnoreCase(String name);

    List<ExpertiseLevel> findAllByIsActiveEquals(Boolean aTrue);

    List<ExpertiseLevel> findAllByIsActiveOrderByNameAsc(Boolean aTrue);
}
