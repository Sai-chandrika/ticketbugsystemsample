package net.thrymrOS.entity.ops;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.BaseEntity;
import net.thrymrOS.enums.RatingType;

import javax.persistence.Entity;

/**
 * @Author ➤➤➤ Rajeswari
 * @Date ➤➤➤ 04/07/23
 * @Time ➤➤➤ 3:19 pm
 * @Project ➤➤➤ ThrymrOS_2.0-backend
 */
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Rating extends BaseEntity {
    private RatingType ratingType;
    private Float rating;
}
