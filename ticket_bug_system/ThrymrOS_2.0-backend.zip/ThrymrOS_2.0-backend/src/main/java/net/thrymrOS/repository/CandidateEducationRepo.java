package net.thrymrOS.repository;

import net.thrymrOS.entity.recruitment.CandidateEducation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * @Author >> Mamatha
 * @Date >>  05/05/23
 * @Time >>  10:57 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Repository
public interface CandidateEducationRepo extends JpaRepository<CandidateEducation,String> {
    List<CandidateEducation> findAllByCandidateId(String id);
    Optional<CandidateEducation> findByCandidateIdAndQualificationId(String id, String qualificationId );

}
