package net.thrymrOS.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.enums.DSRStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  29/04/23
 * @Time >>  10:30 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class DSRTaskResponseDto {
    private DSRStatus dsrStatus;
    private List<DSRTaskDto> dsrTaskDtoList=new ArrayList<>();

}
