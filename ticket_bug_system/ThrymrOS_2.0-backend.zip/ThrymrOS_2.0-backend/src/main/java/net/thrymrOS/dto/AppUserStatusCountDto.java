package net.thrymrOS.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author >> Swetha Kumari Misa
 * @Date >>  27/04/23
 * @Time >>  11:17 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@Data
@NoArgsConstructor
public class AppUserStatusCountDto {
    private Long activeCount;
    private Long inActiveCount;
    private Integer totalCount;
}
