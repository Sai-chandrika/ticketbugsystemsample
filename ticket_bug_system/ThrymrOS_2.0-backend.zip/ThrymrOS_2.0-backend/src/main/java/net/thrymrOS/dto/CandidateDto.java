package net.thrymrOS.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.thrymrOS.entity.md.finance.Currency;
import net.thrymrOS.enums.CandidateStatus;
import net.thrymrOS.enums.CandidateType;
import net.thrymrOS.enums.NoticePeriod;
import net.thrymrOS.enums.Source;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ManyToOne;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author >> Mamatha
 * @Date >>  04/05/23
 * @Time >>  9:38 am
 * @Project >>  ThrymrOS_2.0-backend
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)

public class CandidateDto {
    private String id;
    private String name;
    private CandidateStatus candidateStatus;
    private String candidateCode;
    private LocalDate createdDate;
    private PositionDto positionDto;
    private LocalDate dateOfContact;
    private Source source;
    private CandidateType candidateType;
    private String emailId;
    private String phoneNumber;
    private String linkedId;
    private String currentLocation;
    private String nativeLocation;
    private LocationDto preferredLocation;

    private boolean isActive;
    private List<CandidateSkillDto> skillList=new ArrayList<CandidateSkillDto>();
    private List<CandidateEducationDto> educationList=new ArrayList<CandidateEducationDto>();
    private List<CandidateCertificateDto> certificateList=new ArrayList<CandidateCertificateDto>();
    private List<InternshipDto> internshipList=new ArrayList<InternshipDto>();
    private List<CandidateExperienceDto> experienceList =new ArrayList<CandidateExperienceDto>();


    private FileUploadDto candidateImage;
    private FileUploadDto resume;
    private String aadharNumber;
    private FileUploadDto aadharFile;
    private List<FileUploadDto> otherAttachments=new ArrayList<FileUploadDto>();


    //  NEW FIELDS
    private String currentCompany;
    private String currentJobTitle;
    private String totalExperience;
    private String relevantExperience;
    private LocalDate lastWorkingDate;
    private NoticePeriod noticePeriod;
    private String nativeNoticePeriod;
    private CurrencyDto nativeExpectedCtc;
    private double nativeCtc;




}
